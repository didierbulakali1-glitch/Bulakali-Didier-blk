# DIDI — gestion commerciale et caisse pour boutique de téléphones (Android)

Application Android native (Kotlin, Jetpack Compose, Room/SQLite), **100 % hors ligne**, sans serveur, sans abonnement, sans permission Android. Interface en français, devises USD et CDF avec taux de change saisi à la main.

## État réel du projet (honnêteté)

- **Tout le code est écrit, mais il n'a jamais été compilé ni exécuté.** L'environnement où il a été créé n'avait ni le SDK Android ni l'accès aux dépôts Google/Gradle. Aucun APK n'a donc été construit et aucun test n'a tourné.
- Attendez-vous à **quelques erreurs de compilation** à la première tentative (fautes de type, import manquant). C'est normal pour du code jamais compilé : voir `docs/GUIDE_INSTALLATION.md`, section « Si la compilation échoue ».
- Des tests unitaires existent (`FinanceCalculatorTest`, `ServicesTest`) mais n'ont **pas** été exécutés. Tant qu'ils ne passent pas chez vous, considérez la logique financière comme non validée.
- Ne vendez pas et n'utilisez pas en production avant d'avoir : compilé, passé les tests, puis fait un essai complet avec de petits montants réels (voir `docs/GUIDE_UTILISATION.md`, « Essai avant mise en service »).

## Fonctions

| Module | Contenu |
|---|---|
| Accueil | Ventes, bénéfice, dépenses, trésorerie, dettes, valeur du stock, ruptures ; graphique jours/semaines/mois |
| Produits et catégories | Fiche produit, photo, stock minimum, archivage ; catégories de produits et de dépenses |
| Téléphones (IMEI) | Un appareil = une ligne ; recherche par IMEI/série ; statuts ; garantie |
| Caisse | Panier, remise (plafond vendeur), client, USD/CDF, crédit avec échéance, reçu PDF (voir, partager, imprimer) |
| Ventes | Historique, détail, retour partiel/total, annulation (droit « opérations sensibles ») |
| Clients et dettes | Fiche, relevé PDF, paiements partiels, retards |
| Fournisseurs et achats | Réception de stock, coût moyen pondéré, IMEI, dette fournisseur |
| Dépenses | Par catégorie et période, justificatif photo, export CSV |
| Réparations | Dossier, vérification de garantie par IMEI, historique d'états |
| Rapports | Résultats, trésorerie, meilleurs produits, vendeurs, stock ; CSV et PDF |
| Utilisateurs | Rôles Administrateur/Vendeur/Stock, code PIN, droits détaillés, verrouillage automatique |
| Sauvegarde | Création et restauration d'un fichier, vérification d'intégrité |
| Fonctionnalités | Masquer les modules inutiles |

## Obtenir l'APK sans rien installer (gratuit)

1. Créez un compte GitHub et un dépôt vide, puis envoyez-y tout le contenu de ce dossier (bouton « Add file → Upload files », y compris le dossier caché `.github`).
2. Onglet **Actions** → « Compiler l'APK DIDI » → **Run workflow**.
3. Quand c'est vert, ouvrez l'exécution et téléchargez l'artefact **DIDI-debug-apk** (fichier zip contenant l'APK).
4. Copiez l'APK sur le téléphone, autorisez l'installation depuis cette source, installez.

Détails et dépannage : `docs/GUIDE_INSTALLATION.md`.

## Limites connues

- Les frais de réparation ne sont pas inclus dans le chiffre d'affaires ni les rapports.
- Les paiements fournisseurs et les prix sont gérés dans la devise principale uniquement.
- Les sauvegardes ne sont **pas chiffrées** et n'incluent pas les photos.
- Plafond de remise des vendeurs : appliqué dans l'écran de caisse (non revérifié côté base).
- La base est en version 1 sans migration : si vous aviez installé une ancienne version de développement, **désinstallez-la d'abord** (cela efface ses données).
- Pas de synchronisation entre téléphones, pas de connexion directe à une imprimante (impression via le système Android).

## Guides

`docs/GUIDE_INSTALLATION.md` · `docs/GUIDE_UTILISATION.md` · `docs/GUIDE_MODIFICATION.md` · `docs/GUIDE_SAUVEGARDE.md` · `docs/DOCUMENTATION_TECHNIQUE.md`
