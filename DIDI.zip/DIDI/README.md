# DIDI — gestion commerciale Android (boutique de téléphones)

Application Android native (Kotlin, Jetpack Compose, Room/SQLite), 100 % hors ligne, sans permission Android.

## État réel du projet (version 0.1)

**Écrit, mais NON compilé ni testé** : l'environnement de création n'avait pas le SDK Android ni l'accès réseau nécessaire.
Il est donc possible que la première compilation signale des erreurs à corriger. Ne considérez pas ce projet comme validé tant que les tests n'ont pas tourné (voir plus bas).

| Module | État |
|---|---|
| Configuration Gradle, manifeste, thème | Écrit |
| Base de données Room (14 tables, contraintes, schéma exporté, migrations prévues) | Écrite |
| Calculs financiers (centièmes en Long, remises, bénéfice, dette, conversion USD/CDF, IMEI Luhn) | Écrits + tests unitaires |
| Vente transactionnelle (stock, IMEI, anti-doublon par jeton, crédit, paiement converti) | Écrite, sans interface |
| Caisse (recherche, panier, remise, client avec alerte doublon, mode de paiement, USD/CDF, crédit, validation) | Écrite |
| Reçu PDF + partage Android | Écrit |
| Réglages du commerce (nom, contact, devise, taux, texte du reçu) | Écrits |
| Paiement d'une dette | Écrit, sans interface |
| Écran Accueil (indicateurs lus dans la base) | Écrit |
| Écran Produits (ajout, liste, archivage avec confirmation) | Écrit |
| Saisie de téléphones avec IMEI (la caisse sait les vendre, mais aucun écran ne permet encore de les créer), liste clients et dettes, fournisseurs/achats, dépenses, retours, garanties/réparations, rapports/CSV, utilisateurs/PIN, sauvegarde/restauration | **Pas encore faits** (tables prêtes pour la plupart) |

## Obtenir l'APK sans rien installer (gratuit)

1. Créez un compte sur github.com et un nouveau dépôt privé nommé `DIDI`.
2. Envoyez-y tout le contenu de ce dossier (bouton « Add file » > « Upload files »).
3. Onglet **Actions** > « Compiler l'APK DIDI » > **Run workflow**.
4. Quand c'est vert, ouvrez l'exécution et téléchargez l'artefact `DIDI-debug-apk`. Les tests unitaires tournent avant la compilation ; s'ils échouent, copiez le message d'erreur et envoyez-le-moi.

## Installer sur le téléphone

Copiez le fichier `.apk` sur le téléphone, ouvrez-le, autorisez « installer des applications inconnues » pour votre gestionnaire de fichiers quand Android le demande.

## Choix techniques

- Montants stockés en centièmes (Long) pour éviter les erreurs d'arrondi.
- Valorisation du stock : coût d'achat enregistré par produit (par appareil pour les téléphones à IMEI).
- Bénéfice brut = chiffre d'affaires − coût des marchandises vendues (coût copié sur chaque ligne de vente).
- Le taux USD/CDF est saisi à la main ; il est enregistré avec chaque paiement converti.
- Une vente n'est jamais supprimée : elle est annulée avec trace (module à compléter).
- Limite actuelle : prix et coûts des produits sont dans la devise principale ; seul l'encaissement peut se faire en USD ou CDF.

## Pour modifier

Ouvrez le dossier dans Android Studio (Android Studio crée lui-même le wrapper Gradle). Un changement de tables = augmenter `version` dans `DidiDatabase.kt` et ajouter une `Migration` pour conserver les données.
