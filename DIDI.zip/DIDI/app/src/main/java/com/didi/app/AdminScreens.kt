package com.didi.app

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.didi.app.data.AppSetting
import com.didi.app.data.AppUser
import com.didi.app.data.Category
import com.didi.app.data.ExpenseCategory
import com.didi.app.data.SettingKeys
import com.didi.app.domain.BackupService
import com.didi.app.domain.CsvExport
import com.didi.app.domain.PinHasher
import com.didi.app.domain.Perm
import com.didi.app.domain.Roles
import com.didi.app.domain.Session
import com.didi.app.domain.formatDateTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ======================= CATÉGORIES =======================

@Composable
fun CategoriesScreen(app: DidiApp) {
    val db = app.db
    val scope = rememberCoroutineScope()
    val productCats by remember(db) { db.categories().observeAll() }.collectAsState(emptyList())
    val expenseCats by remember(db) { db.expenses().observeCategories() }.collectAsState(emptyList())
    var kind by remember { mutableStateOf("produits") }
    var adding by remember { mutableStateOf(false) }
    var editProduct by remember { mutableStateOf<Category?>(null) }
    var editExpense by remember { mutableStateOf<ExpenseCategory?>(null) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            ChipRow(listOf("produits" to "Produits", "depenses" to "Dépenses"), kind) { kind = it }
            Text(
                "Une catégorie utilisée ne peut pas être supprimée : désactivez-la, elle ne sera plus proposée mais l'historique reste intact.",
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 6.dp)
            )
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (kind == "produits") {
                    items(productCats, key = { it.id }) { c ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(c.name, style = MaterialTheme.typography.titleSmall)
                                    Text((if (c.isPhone) "Suivi par IMEI · " else "") + if (c.active) "Active" else "Désactivée", style = MaterialTheme.typography.bodySmall)
                                }
                                TextButton({ editProduct = c }) { Text("Modifier") }
                            }
                        }
                    }
                } else {
                    items(expenseCats, key = { it.id }) { c ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(c.name, style = MaterialTheme.typography.titleSmall)
                                    Text(if (c.active) "Active" else "Désactivée", style = MaterialTheme.typography.bodySmall)
                                }
                                TextButton({ editExpense = c }) { Text("Modifier") }
                            }
                        }
                    }
                }
                item { Box(Modifier.heightIn(min = 80.dp)) }
            }
        }
        FloatingActionButton({ adding = true }, Modifier.align(Alignment.BottomEnd).padding(16.dp)) { Text("+") }
    }

    if (adding) CategoryDialog(null, true, kind == "produits", { adding = false }) { name, isPhone, active ->
        if (kind == "produits") db.categories().insert(Category(name = name, isPhone = isPhone, active = active))
        else db.expenses().insertCategory(ExpenseCategory(name = name, active = active))
    }
    editProduct?.let { c ->
        CategoryDialog(CatForm(c.name, c.isPhone, c.active), false, true, { editProduct = null }) { name, isPhone, active ->
            db.categories().update(c.copy(name = name, isPhone = isPhone, active = active))
        }
    }
    editExpense?.let { c ->
        CategoryDialog(CatForm(c.name, false, c.active), false, false, { editExpense = null }) { name, _, active ->
            db.expenses().updateCategory(c.copy(name = name, active = active))
        }
    }
}

private data class CatForm(val name: String, val isPhone: Boolean, val active: Boolean)

@Composable
private fun CategoryDialog(
    initial: CatForm?, isNew: Boolean, showPhoneFlag: Boolean, onClose: () -> Unit,
    save: suspend (name: String, isPhone: Boolean, active: Boolean) -> Unit
) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    var isPhone by remember { mutableStateOf(initial?.isPhone ?: false) }
    var active by remember { mutableStateOf(initial?.active ?: true) }
    var error by remember { mutableStateOf<String?>(null) }
    FormDialog(
        title = if (isNew) "Nouvelle catégorie" else "Modifier la catégorie", error = error, onDismiss = onClose,
        onConfirm = {
            if (name.isBlank()) error = "Le nom est obligatoire."
            else scope.launch {
                try {
                    save(name.trim(), isPhone, active)
                    onClose()
                } catch (e: Exception) {
                    error = "Enregistrement impossible : ce nom existe peut-être déjà."
                }
            }
        }
    ) {
        TextField1(name, "Nom", { name = it })
        if (showPhoneFlag) SwitchRow("Appareils suivis par IMEI (téléphones)", isPhone) { isPhone = it }
        if (!isNew) SwitchRow("Active", active) { active = it }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, onChange)
    }
}

// ======================= UTILISATEURS =======================

@Composable
fun UsersScreen(app: DidiApp) {
    val db = app.db
    val scope = rememberCoroutineScope()
    val users by remember(db) { db.users().observeAll() }.collectAsState(emptyList())
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<AppUser?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            if (users.isEmpty()) {
                Text(
                    "Aucun utilisateur : l'application s'ouvre sans code PIN. Créez d'abord un administrateur pour activer la protection.",
                    Modifier.padding(vertical = 8.dp)
                )
            }
            message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(users, key = { it.id }) { u ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(u.name, style = MaterialTheme.typography.titleSmall)
                                Text(Roles.label(u.role) + if (u.active) "" else " · désactivé", style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton({ editing = u }) { Text("Gérer") }
                        }
                    }
                }
                item { Box(Modifier.heightIn(min = 80.dp)) }
            }
        }
        FloatingActionButton({ adding = true }, Modifier.align(Alignment.BottomEnd).padding(16.dp)) { Text("+") }
    }

    if (adding) UserFormDialog(app, null, users.isEmpty()) { adding = false }
    editing?.let { u ->
        UserFormDialog(app, users.firstOrNull { it.id == u.id } ?: u, false) { editing = null }
    }
}

@Composable
private fun UserFormDialog(app: DidiApp, existing: AppUser?, firstUser: Boolean, onClose: () -> Unit) {
    val db = app.db
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(existing?.name.orEmpty()) }
    var role by remember { mutableStateOf(if (firstUser) Roles.ADMIN else existing?.role ?: Roles.SELLER) }
    var perms by remember { mutableStateOf(existing?.let { Perm.parse(it.permissions) } ?: Perm.defaultsFor(role)) }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var active by remember { mutableStateOf(existing?.active ?: true) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    FormDialog(
        title = if (existing == null) "Nouvel utilisateur" else "Gérer ${existing.name}", error = error, onDismiss = onClose,
        onConfirm = {
            if (busy) return@FormDialog
            val pinGiven = pin.isNotEmpty() || pin2.isNotEmpty() || existing == null
            when {
                name.isBlank() -> error = "Le nom est obligatoire."
                pinGiven && !PinHasher.isValidPin(pin) -> error = "Le code PIN doit contenir 4 à 8 chiffres."
                pinGiven && pin != pin2 -> error = "Les deux codes PIN ne sont pas identiques."
                else -> scope.launch {
                    busy = true
                    try {
                        val allPerms = if (role == Roles.ADMIN) Perm.ALL.map { it.first }.toSet() else perms
                        if (existing != null && existing.role == Roles.ADMIN && existing.active &&
                            (role != Roles.ADMIN || !active) && db.users().activeAdminCount() <= 1
                        ) {
                            error = "Impossible : c'est le dernier administrateur actif."
                            return@launch
                        }
                        val salt = if (pinGiven) PinHasher.newSalt() else existing!!.pinSalt
                        val hash = if (pinGiven) withContext(Dispatchers.Default) { PinHasher.hash(pin, salt) } else existing!!.pinHash
                        if (existing == null) {
                            val id = db.users().insert(
                                AppUser(name = name.trim(), role = role, pinHash = hash, pinSalt = salt, permissions = Perm.serialize(allPerms))
                            )
                            if (firstUser) {
                                Session.user = db.users().active().firstOrNull { it.id == id }
                                Session.usersExist = true
                            }
                        } else {
                            val updated = existing.copy(
                                name = name.trim(), role = role, pinHash = hash, pinSalt = salt,
                                permissions = Perm.serialize(allPerms), active = active
                            )
                            db.users().update(updated)
                            if (Session.user?.id == updated.id) Session.user = updated
                        }
                        onClose()
                    } catch (e: Exception) {
                        error = "Enregistrement impossible : ce nom est peut-être déjà utilisé."
                    } finally {
                        busy = false
                    }
                }
            }
        }
    ) {
        TextField1(name, "Nom", { name = it })
        if (firstUser) {
            Text("Le premier utilisateur est obligatoirement administrateur.", style = MaterialTheme.typography.bodySmall)
        } else {
            Text("Rôle")
            ChipRow(Roles.ALL.map { it to Roles.label(it) }, role) {
                role = it
                perms = Perm.defaultsFor(it)
            }
        }
        androidx.compose.material3.OutlinedTextField(
            pin, { pin = it.filter(Char::isDigit).take(8) }, label = { Text(if (existing == null) "Code PIN (4 à 8 chiffres)" else "Nouveau PIN (laisser vide pour garder)") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        androidx.compose.material3.OutlinedTextField(
            pin2, { pin2 = it.filter(Char::isDigit).take(8) }, label = { Text("Confirmer le PIN") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        if (existing != null) SwitchRow("Compte actif", active) { active = it }
        if (role != Roles.ADMIN) {
            Text("Droits d'accès", style = MaterialTheme.typography.titleSmall)
            Perm.ALL.forEach { (key, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(key in perms, { on -> perms = if (on) perms + key else perms - key })
                    Text(label)
                }
            }
        } else {
            Text("Un administrateur a tous les droits.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

// ======================= SAUVEGARDE =======================

@Composable
fun BackupScreen(app: DidiApp) {
    val db = app.db
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by remember(db) { db.settings().observeAll() }.collectAsState(emptyList())
    val last = settings.firstOrNull { it.key == SettingKeys.LAST_BACKUP }?.value?.toLongOrNull()
    var message by remember { mutableStateOf<String?>(null) }
    var verified by remember { mutableStateOf<File?>(null) }
    var restored by remember { mutableStateOf(false) }
    val csv = rememberFileSaver("text/csv")

    val create = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) scope.launch {
            try {
                BackupService.backupTo(context, db, uri)
                db.settings().put(AppSetting(SettingKeys.LAST_BACKUP, System.currentTimeMillis().toString()))
                message = "Sauvegarde enregistrée. Gardez-en une copie hors du téléphone (clé USB, ordinateur)."
            } catch (e: Exception) {
                message = "La sauvegarde a échoué : ${e.message}"
            }
        }
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                verified = BackupService.verify(context, uri)
            } catch (e: Exception) {
                message = e.message ?: "Fichier invalide."
            }
        }
    }

    Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        InfoCard(
            "Sauvegarde",
            listOf(
                "Dernière sauvegarde : " + (last?.let { formatDateTime(it) } ?: "aucune"),
                "Elle contient toutes vos données (produits, ventes, clients…). Le fichier n'est pas chiffré : rangez-le en lieu sûr.",
                "Les photos (produits, justificatifs, logo) ne sont pas incluses."
            )
        )
        OutlinedButton({
            val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
            create.launch("didi-sauvegarde-$stamp.db")
        }) { Text("Créer une sauvegarde") }
        OutlinedButton({ pick.launch(arrayOf("*/*")) }) { Text("Restaurer une sauvegarde") }
        message?.let { Text(it) }
        Text("Exports pour tableur (CSV)", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ scope.launch { csv("didi-produits.csv", CsvExport.products(db)) } }) { Text("Produits") }
            OutlinedButton({ scope.launch { csv("didi-clients.csv", CsvExport.customers(db)) } }) { Text("Clients") }
        }
    }

    verified?.let { f ->
        ConfirmDialog(
            "Remplacer toutes les données ?",
            "Le fichier est valide. La restauration REMPLACE toutes les données actuelles par celles de la sauvegarde. Une copie de sécurité de l'état actuel est gardée automatiquement dans l'application. Continuer ?",
            "Restaurer",
            {
                scope.launch {
                    try {
                        BackupService.restore(context, f)
                        verified = null
                        restored = true
                    } catch (e: Exception) {
                        verified = null
                        message = "La restauration a échoué : ${e.message}"
                    }
                }
            },
            { f.delete(); verified = null }
        )
    }
    if (restored) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Restauration terminée") },
            text = { Text("Fermez complètement DIDI puis rouvrez-la pour charger les données restaurées.") },
            confirmButton = { TextButton({ (context as? Activity)?.finishAffinity() }) { Text("Fermer DIDI") } }
        )
    }
}

// ======================= FONCTIONNALITÉS =======================

@Composable
fun FeaturesScreen(app: DidiApp) {
    val db = app.db
    val scope = rememberCoroutineScope()
    val settings by remember(db) { db.settings().observeAll() }.collectAsState(emptyList())
    val map = settings.associate { it.key to it.value }
    Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Activez seulement ce dont votre commerce a besoin. Désactiver un module le masque du menu ; vos données restent conservées.")
        OPTIONAL_FEATURES.forEach { (key, label) ->
            val on = map[SettingKeys.feature(key)] != "false"
            SwitchRow(label, on) { v ->
                scope.launch { db.settings().put(AppSetting(SettingKeys.feature(key), v.toString())) }
            }
        }
    }
}
