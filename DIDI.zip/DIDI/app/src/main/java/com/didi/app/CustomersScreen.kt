package com.didi.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.didi.app.data.Customer
import com.didi.app.data.DidiDatabase
import com.didi.app.data.SaleStatus
import com.didi.app.data.SettingKeys
import com.didi.app.domain.FinanceCalculator
import com.didi.app.domain.PdfText
import com.didi.app.domain.ReceiptPdf
import com.didi.app.domain.Session
import com.didi.app.domain.formatDate
import com.didi.app.domain.formatDateTime
import com.didi.app.domain.startOfDay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Lignes du relevé de compte d'un client (toutes les opérations, dans l'ordre). */
suspend fun customerStatementLines(db: DidiDatabase, c: Customer): List<String> {
    val sales = db.sales().observeSalesOfCustomer(c.id).first().sortedBy { it.createdAt }
    val payments = db.sales().observePaymentsOfCustomer(c.id).first().sortedBy { it.createdAt }
    val shop = db.settings().get(SettingKeys.SHOP_NAME).orEmpty()
    val cur = db.settings().get(SettingKeys.MAIN_CURRENCY) ?: "USD"
    val out = mutableListOf<String>()
    out += shop
    out += "Client : ${c.fullName}" + if (c.phone.isNotBlank()) " · ${c.phone}" else ""
    out += "Édité le ${formatDateTime(System.currentTimeMillis())} · montants en $cur"
    out += ""
    out += "VENTES"
    val valid = sales.filter { it.status == SaleStatus.VALIDATED }
    if (sales.isEmpty()) out += "Aucune vente."
    sales.forEach { s ->
        out += "${formatDate(s.createdAt)} · ${s.number} · total ${fmt(s.total)}" +
            (if (s.returnedAmount > 0) " · retours ${fmt(s.returnedAmount)}" else "") +
            " · payé ${fmt(s.paidAmount)}" +
            (if (s.status != SaleStatus.VALIDATED) " · ANNULÉE"
            else " · solde ${fmt(FinanceCalculator.balance(s.total - s.returnedAmount, s.paidAmount))}")
    }
    out += ""
    out += "PAIEMENTS ET REMBOURSEMENTS"
    if (payments.isEmpty()) out += "Aucun paiement."
    payments.forEach { p ->
        out += "${formatDate(p.createdAt)} · ${methodLabel(p.method)} · ${fmt(p.amountInMain)}" +
            (if (p.amountInMain < 0) " (remboursement)" else "") + (if (p.reference.isNotBlank()) " · ${p.reference}" else "")
    }
    out += ""
    out += "TOTAL DES ACHATS : ${fmt(valid.sumOf { it.total })}"
    out += "TOTAL PAYÉ : ${fmt(valid.sumOf { it.paidAmount })}"
    out += "SOLDE RESTANT DÛ : ${fmt(valid.sumOf { FinanceCalculator.balance(it.total - it.returnedAmount, it.paidAmount) })}"
    return out
}

@Composable
fun CustomersScreen(app: DidiApp) {
    val db = app.db
    val customers by remember(db) { db.customers().observeAll() }.collectAsState(emptyList())
    var query by remember { mutableStateOf("") }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var showAdd by remember { mutableStateOf(false) }

    selectedId?.let { id ->
        CustomerDetail(app, id) { selectedId = null }
        return
    }

    val shown = customers.filter { query.isBlank() || it.fullName.contains(query, true) || it.phone.contains(query) }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            TextField1(query, "Rechercher (nom ou téléphone)", { query = it }, Modifier.fillMaxWidth().padding(vertical = 8.dp))
            if (shown.isEmpty()) Text(if (customers.isEmpty()) "Aucun client. Touchez + pour en ajouter." else "Aucun client ne correspond.")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.id }) { c ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(c.fullName, style = MaterialTheme.typography.titleMedium)
                                if (c.phone.isNotBlank()) Text(c.phone)
                            }
                            TextButton({ selectedId = c.id }) { Text("Fiche") }
                        }
                    }
                }
                item { Box(Modifier.heightIn(min = 80.dp)) }
            }
        }
        FloatingActionButton({ showAdd = true }, Modifier.align(Alignment.BottomEnd).padding(16.dp)) { Text("+") }
    }
    if (showAdd) CustomerEditDialog(app, null) { showAdd = false }
}

@Composable
fun CustomerEditDialog(app: DidiApp, existing: Customer?, onClose: () -> Unit) {
    val db = app.db
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(existing?.fullName.orEmpty()) }
    var phone by remember { mutableStateOf(existing?.phone.orEmpty()) }
    var address by remember { mutableStateOf(existing?.address.orEmpty()) }
    var notes by remember { mutableStateOf(existing?.notes.orEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }
    var warned by remember { mutableStateOf(false) }
    FormDialog(
        title = if (existing == null) "Nouveau client" else "Modifier le client", error = error, onDismiss = onClose,
        onConfirm = {
            if (name.isBlank()) error = "Le nom est obligatoire."
            else scope.launch {
                val dup = if (phone.isBlank()) null else db.customers().findByPhone(phone.trim())
                if (dup != null && dup.id != existing?.id && !warned) {
                    warned = true
                    error = "Un client avec ce numéro existe déjà : ${dup.fullName}. Touchez Enregistrer de nouveau pour créer quand même."
                } else {
                    if (existing == null) db.customers().insert(Customer(fullName = name.trim(), phone = phone.trim(), address = address.trim(), notes = notes.trim()))
                    else db.customers().update(existing.copy(fullName = name.trim(), phone = phone.trim(), address = address.trim(), notes = notes.trim()))
                    onClose()
                }
            }
        }
    ) {
        TextField1(name, "Nom complet", { name = it })
        TextField1(phone, "Téléphone", { phone = it; warned = false })
        TextField1(address, "Adresse (facultatif)", { address = it })
        TextField1(notes, "Notes", { notes = it })
    }
}

@Composable
private fun CustomerDetail(app: DidiApp, id: Long, onBack: () -> Unit) {
    val db = app.db
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    BackHandler(onBack = onBack)
    val cur by rememberMainCurrency(app)
    val customers by remember(db) { db.customers().observeAll() }.collectAsState(emptyList())
    val sales by remember(id) { db.sales().observeSalesOfCustomer(id) }.collectAsState(emptyList())
    val payments by remember(id) { db.sales().observePaymentsOfCustomer(id) }.collectAsState(emptyList())
    var showEdit by remember { mutableStateOf(false) }
    var showPay by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }

    val c = customers.firstOrNull { it.id == id } ?: run {
        Text("Client introuvable.", Modifier.padding(16.dp)); return
    }
    val valid = sales.filter { it.status == SaleStatus.VALIDATED }
    val balance = valid.sumOf { FinanceCalculator.balance(it.total - it.returnedAmount, it.paidAmount) }
    val refunds = payments.filter { it.amountInMain < 0 }.sumOf { -it.amountInMain }
    val credit = valid.filter { FinanceCalculator.balance(it.total - it.returnedAmount, it.paidAmount) > 0 }

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { TextButton(onBack) { Text("← Retour aux clients") } }
        item { Text(c.fullName, style = MaterialTheme.typography.titleLarge) }
        msg?.let { m -> item { Text(m, color = MaterialTheme.colorScheme.primary) } }
        item {
            InfoCard(
                "Fiche client",
                listOfNotNull(
                    if (c.phone.isNotBlank()) "Téléphone : ${c.phone}" else null,
                    if (c.address.isNotBlank()) "Adresse : ${c.address}" else null,
                    if (c.notes.isNotBlank()) "Notes : ${c.notes}" else null,
                    "Client depuis le ${formatDate(c.createdAt)}"
                )
            )
        }
        item {
            InfoCard(
                "Situation ($cur)",
                listOf(
                    "Total des achats : ${fmt(valid.sumOf { it.total })}",
                    "Total payé (net) : ${fmt(valid.sumOf { it.paidAmount })}",
                    "Retours acceptés : ${fmt(valid.sumOf { it.returnedAmount })}",
                    "Remboursements effectués : ${fmt(refunds)}",
                    "Solde restant dû : ${fmt(balance)}",
                    "Ventes à crédit en cours : ${credit.size}"
                )
            )
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton({ showEdit = true }) { Text("Modifier") }
                if (balance > 0 && Session.can("debts")) Button({ showPay = true }) { Text("Encaisser un paiement") }
                OutlinedButton({
                    scope.launch {
                        val f = PdfText.create(context, "releve-${c.fullName.filter { it.isLetterOrDigit() }.ifBlank { "client" }}.pdf", "Relevé de compte", customerStatementLines(db, c))
                        ReceiptPdf.share(context, f)
                    }
                }) { Text("Relevé PDF") }
                OutlinedButton({
                    scope.launch {
                        val f = PdfText.create(context, "releve-${c.fullName.filter { it.isLetterOrDigit() }.ifBlank { "client" }}.pdf", "Relevé de compte", customerStatementLines(db, c))
                        ReceiptPdf.print(context, f)
                    }
                }) { Text("Imprimer") }
            }
        }
        item { Text("Historique des achats", style = MaterialTheme.typography.titleMedium) }
        if (sales.isEmpty()) item { Text("Aucun achat.") }
        items(sales, key = { "s${it.id}" }) { s ->
            Text(
                "${formatDate(s.createdAt)} · ${s.number} · ${fmt(s.total)} · payé ${fmt(s.paidAmount)}" +
                    (if (s.status != SaleStatus.VALIDATED) " · ANNULÉE" else "") +
                    (if (s.returnedAmount > 0) " · retours ${fmt(s.returnedAmount)}" else "")
            )
        }
        item { Text("Historique des paiements", style = MaterialTheme.typography.titleMedium) }
        if (payments.isEmpty()) item { Text("Aucun paiement.") }
        items(payments, key = { "p${it.id}" }) { p ->
            Text("${formatDate(p.createdAt)} · ${methodLabel(p.method)} · ${fmt(p.amountInMain)}" + (if (p.amountInMain < 0) " (remboursement)" else ""))
        }
    }

    if (showEdit) CustomerEditDialog(app, c) { showEdit = false }
    if (showPay) PayDialog("Paiement de ${c.fullName}", balance, cur, { showPay = false }) { amount, method, ref ->
        val n = app.afterSale.payCustomerDebt(c.id, amount, method, ref)
        msg = "Paiement de ${fmt(amount)} $cur enregistré sur $n vente(s)."
    }
}

@Composable
fun DebtsScreen(app: DidiApp) {
    val db = app.db
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cur by rememberMainCurrency(app)
    val debts by remember(db) { db.sales().observeOpenDebts() }.collectAsState(emptyList())
    val customers by remember(db) { db.customers().observeAll() }.collectAsState(emptyList())
    val names = customers.associateBy { it.id }
    var selected by remember { mutableStateOf<Long?>(null) }
    var showPay by remember { mutableStateOf(false) }
    val today = startOfDay(0)

    fun due(s: com.didi.app.data.Sale) = s.total - s.returnedAmount - s.paidAmount
    val groups = debts.filter { it.customerId != null }.groupBy { it.customerId!! }
    val total = debts.sumOf { due(it) }
    val overdue = debts.filter { (it.dueDate ?: Long.MAX_VALUE) < today }

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            InfoCard(
                "Créances clients",
                listOf(
                    "Total dû : ${fmt(total)} $cur",
                    "Clients endettés : ${groups.size}",
                    "Dettes en retard : ${overdue.size} (${fmt(overdue.sumOf { due(it) })} $cur)"
                )
            )
        }
        if (groups.isEmpty()) item { Text("Aucune dette en cours.") }
        items(groups.entries.sortedByDescending { e -> e.value.sumOf { due(it) } }.toList(), key = { it.key }) { e ->
            val late = e.value.any { (it.dueDate ?: Long.MAX_VALUE) < today }
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(names[e.key]?.fullName ?: "Client supprimé", style = MaterialTheme.typography.titleMedium)
                        Text("${e.value.size} vente(s) · dû ${fmt(e.value.sumOf { due(it) })} $cur" + if (late) " · EN RETARD" else "",
                            color = if (late) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                    }
                    TextButton({ selected = e.key }) { Text("Détail") }
                }
            }
        }
    }

    selected?.let { cid ->
        val c = names[cid]
        val list = debts.filter { it.customerId == cid }
        val sum = list.sumOf { due(it) }
        if (c != null && list.isNotEmpty()) {
            if (showPay) {
                PayDialog("Paiement de ${c.fullName}", sum, cur, { showPay = false }) { amount, method, ref ->
                    app.afterSale.payCustomerDebt(cid, amount, method, ref)
                }
            } else {
                InfoDialog(c.fullName, { selected = null }) {
                    Text("Total dû : ${fmt(sum)} $cur" + if (c.phone.isNotBlank()) " · ${c.phone}" else "")
                    list.forEach { s ->
                        Text(
                            "${s.number} · ${formatDate(s.createdAt)} · reste ${fmt(due(s))}" +
                                (s.dueDate?.let { " · échéance ${formatDate(it)}" + if (it < today) " (en retard)" else "" } ?: "")
                        )
                    }
                    Text("Le paiement est imputé d'abord sur la dette la plus ancienne.", style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button({ showPay = true }) { Text("Encaisser") }
                        OutlinedButton({
                            scope.launch {
                                val f = PdfText.create(context, "releve-${c.fullName.filter { it.isLetterOrDigit() }.ifBlank { "client" }}.pdf", "Relevé de compte", customerStatementLines(db, c))
                                ReceiptPdf.share(context, f)
                            }
                        }) { Text("Relevé PDF") }
                    }
                }
            }
        }
    }
}
