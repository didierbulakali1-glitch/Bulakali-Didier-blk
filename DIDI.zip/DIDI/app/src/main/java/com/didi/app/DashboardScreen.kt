package com.didi.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import com.didi.app.domain.ChartMode
import com.didi.app.domain.Summary
import com.didi.app.domain.chartBars
import com.didi.app.domain.chartStart
import com.didi.app.domain.endOfDay
import com.didi.app.domain.formatDateTime
import com.didi.app.domain.startOfDay
import com.didi.app.domain.startOfMonth
import com.didi.app.domain.summaryFlow

private enum class StatPeriod(val label: String) { DAY("Aujourd'hui"), WEEK("7 jours"), MONTH("Ce mois") }

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Text(value, style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
private fun BarChart(bars: List<com.didi.app.domain.Bar>) {
    val max = (bars.maxOfOrNull { it.value } ?: 0L).coerceAtLeast(1L)
    val barColor = MaterialTheme.colorScheme.primary
    val textColor = MaterialTheme.colorScheme.onSurface
    Canvas(Modifier.fillMaxWidth().height(160.dp)) {
        val n = bars.size.coerceAtLeast(1)
        val slot = size.width / n
        val chartH = size.height - 36f
        val paint = android.graphics.Paint().apply {
            color = textColor.toArgb(); textSize = 26f; isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
        }
        bars.forEachIndexed { i, b ->
            val h = chartH * (b.value.toFloat() / max.toFloat())
            drawRect(barColor, Offset(i * slot + slot * 0.15f, chartH - h), Size(slot * 0.7f, h.coerceAtLeast(2f)))
            drawContext.canvas.nativeCanvas.drawText(b.label, i * slot + slot / 2, size.height - 6f, paint)
        }
    }
}

@Composable
fun DashboardScreen(app: DidiApp, shopName: String) {
    val db = app.db
    val currency by rememberMainCurrency(app)
    var period by remember { mutableStateOf(StatPeriod.DAY) }
    var chartMode by remember { mutableStateOf(ChartMode.DAYS) }

    val from = when (period) {
        StatPeriod.DAY -> startOfDay(0); StatPeriod.WEEK -> startOfDay(6); StatPeriod.MONTH -> startOfMonth()
    }
    val to = endOfDay(System.currentTimeMillis())
    val summary by remember(from, to) { summaryFlow(db, from, to) }.collectAsState(Summary(0, 0, 0, 0, 0, 0, 0, 0))
    val receivables by db.reports().receivables().collectAsState(0L)
    val supplierDebts by db.reports().supplierDebts().collectAsState(0L)
    val stockValue by db.products().observeStockValue().collectAsState(0L)
    val units by db.products().observeUnitsInStock().collectAsState(0)
    val out by db.products().observeOutOfStockCount().collectAsState(0)
    val low by db.products().observeLowStockCount().collectAsState(0)
    val latest by db.sales().observeLatest(5).collectAsState(emptyList())
    val top by remember(from, to) { db.reports().productsSold(from, to) }.collectAsState(emptyList())
    val chartSales by remember(chartMode) { db.sales().observeBetween(chartStart(chartMode), to) }.collectAsState(emptyList())

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text(if (shopName.isBlank()) "Bienvenue sur DIDI" else shopName, style = MaterialTheme.typography.titleLarge)
            Text("Montants en $currency", style = MaterialTheme.typography.bodySmall)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                StatPeriod.values().forEach { p -> FilterChip(period == p, { period = p }, { Text(p.label) }) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Chiffre d'affaires", fmt(summary.revenue), Modifier.weight(1f))
                StatCard("Nombre de ventes", summary.salesCount.toString(), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Bénéfice brut estimé", fmt(summary.gross), Modifier.weight(1f))
                StatCard("Bénéfice net estimé", fmt(summary.net), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Dépenses", fmt(summary.expenses), Modifier.weight(1f))
                StatCard("Argent encaissé", fmt(summary.cash), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Valeur du stock", fmt(stockValue), Modifier.weight(1f))
                StatCard("Articles en stock", units.toString(), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("En rupture", out.toString(), Modifier.weight(1f))
                StatCard("Stock faible", low.toString(), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Dettes des clients", fmt(receivables), Modifier.weight(1f))
                StatCard("Dû aux fournisseurs", fmt(supplierDebts), Modifier.weight(1f))
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Ventes", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ChartMode.values().forEach { m -> FilterChip(chartMode == m, { chartMode = m }, { Text(m.label) }) }
                    }
                    BarChart(chartBars(chartSales, chartMode))
                }
            }
        }
        item { Text("Produits les plus vendus", style = MaterialTheme.typography.titleMedium) }
        if (top.isEmpty()) item { Text("Aucune vente sur cette période.") }
        items(top.take(5)) { t -> Text("${t.productName} : ${t.qty} vendu(s) · ${fmt(t.revenue)}") }
        item { Text("Dernières ventes", style = MaterialTheme.typography.titleMedium) }
        if (latest.isEmpty()) item { Text("Aucune vente enregistrée.") }
        items(latest, key = { it.id }) { s ->
            Text("${s.number} · ${formatDateTime(s.createdAt)} · ${fmt(s.total)} ${s.currency}" + if (s.status != "VALIDEE") " · annulée" else "")
        }
    }
}
