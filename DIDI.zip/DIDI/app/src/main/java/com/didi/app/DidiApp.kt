package com.didi.app

import android.app.Application
import com.didi.app.data.DidiDatabase
import com.didi.app.data.seedDefaultsIfNeeded
import com.didi.app.domain.SaleService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DidiApp : Application() {
    val db: DidiDatabase by lazy { DidiDatabase.get(this) }
    val saleService: SaleService by lazy { SaleService(db) }

    override fun onCreate() {
        super.onCreate()
        CoroutineScope(Dispatchers.IO).launch { db.seedDefaultsIfNeeded() }
    }
}
