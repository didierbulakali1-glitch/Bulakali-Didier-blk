package com.didi.app

import android.app.Application
import com.didi.app.data.DidiDatabase
import com.didi.app.data.seedDefaultsIfNeeded
import com.didi.app.domain.AfterSaleService
import com.didi.app.domain.PurchaseService
import com.didi.app.domain.SaleService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DidiApp : Application() {
    // Accesseurs (et non lazy) : après une restauration la base est rouverte proprement.
    val db: DidiDatabase get() = DidiDatabase.get(this)
    val saleService: SaleService get() = SaleService(db)
    val afterSale: AfterSaleService get() = AfterSaleService(db)
    val purchaseService: PurchaseService get() = PurchaseService(db)

    override fun onCreate() {
        super.onCreate()
        CoroutineScope(Dispatchers.IO).launch { db.seedDefaultsIfNeeded() }
    }
}
