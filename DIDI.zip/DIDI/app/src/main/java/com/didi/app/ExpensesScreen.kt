package com.didi.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.didi.app.data.Expense
import com.didi.app.data.ExpenseCategory
import com.didi.app.data.SettingKeys
import com.didi.app.domain.CsvExport
import com.didi.app.domain.Currency
import com.didi.app.domain.FinanceCalculator
import com.didi.app.domain.formatDate
import com.didi.app.domain.parseDate
import kotlinx.coroutines.launch

@Composable
fun ExpensesScreen(app: DidiApp) {
    val db = app.db
    val scope = rememberCoroutineScope()
    val cur by rememberMainCurrency(app)
    var range by remember { mutableStateOf(DateRange.presets()[2]) }
    var catFilter by remember { mutableStateOf<Long?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Expense?>(null) }
    val categories by remember(db) { db.expenses().observeCategories() }.collectAsState(emptyList())
    val expenses by remember(range) { db.expenses().observeBetween(range.from, range.to) }.collectAsState(emptyList())
    val saver = rememberFileSaver("text/csv")
    val catNames = categories.associate { it.id to it.name }
    val shown = expenses.filter { catFilter == null || it.categoryId == catFilter }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            RangePicker(range) { range = it }
            ChipRow(listOf("all" to "Toutes") + categories.map { it.id.toString() to it.name }, catFilter?.toString() ?: "all") {
                catFilter = if (it == "all") null else it.toLong()
            }
            Text("Total : ${fmt(shown.sumOf { it.amountInMain })} $cur · ${shown.size} dépense(s)", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(vertical = 6.dp))
            Text("Les dépenses professionnelles ne comprennent pas les achats de marchandises (voir Achats).", style = MaterialTheme.typography.bodySmall)
            OutlinedButton({ scope.launch { saver("didi-depenses.csv", CsvExport.expenses(db, range.from, range.to)) } }) { Text("Exporter en CSV") }
            if (shown.isEmpty()) Text("Aucune dépense sur cette période.", Modifier.padding(vertical = 12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                items(shown, key = { it.id }) { e ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${formatDate(e.date)} · ${catNames[e.categoryId] ?: "-"}", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "${fmt(e.amount)} ${e.currency}" + (if (e.currency != cur) " (= ${fmt(e.amountInMain)} $cur)" else "") +
                                        (if (e.description.isNotBlank()) " · ${e.description}" else "") + " · ${methodLabel(e.method)}"
                                )
                                Thumbnail(e.attachmentPath, 40)
                            }
                            TextButton({ editing = e }) { Text("Modifier") }
                        }
                    }
                }
                item { Box(Modifier.heightIn(min = 80.dp)) }
            }
        }
        FloatingActionButton({ showForm = true }, Modifier.align(Alignment.BottomEnd).padding(16.dp)) { Text("+") }
    }
    if (showForm) ExpenseDialog(app, null, categories) { showForm = false }
    editing?.let { ExpenseDialog(app, it, categories) { editing = null } }
}

@Composable
private fun ExpenseDialog(app: DidiApp, existing: Expense?, categories: List<ExpenseCategory>, onClose: () -> Unit) {
    val db = app.db
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val main by rememberMainCurrency(app)
    var date by remember { mutableStateOf(formatDate(existing?.date ?: System.currentTimeMillis())) }
    var catId by remember { mutableStateOf(existing?.categoryId ?: categories.firstOrNull { it.active }?.id) }
    var desc by remember { mutableStateOf(existing?.description.orEmpty()) }
    var amount by remember { mutableStateOf(existing?.let { fmt(it.amount) }.orEmpty()) }
    var currency by remember { mutableStateOf(existing?.currency ?: main) }
    var method by remember { mutableStateOf(existing?.method ?: "ESPECES") }
    var ref by remember { mutableStateOf(existing?.reference.orEmpty()) }
    var attachment by remember { mutableStateOf(existing?.attachmentPath) }
    var error by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) copyIntoApp(context, uri, "justificatifs")?.let { attachment = it }
    }

    FormDialog(
        title = if (existing == null) "Nouvelle dépense" else "Modifier la dépense", error = error, onDismiss = onClose,
        onConfirm = {
            val d = parseDate(date)
            val a = FinanceCalculator.parseToMinor(amount)
            when {
                d == null -> error = "Date invalide (jj/mm/aaaa)."
                catId == null -> error = "Choisissez une catégorie."
                a == null || a <= 0 -> error = "Montant invalide."
                else -> scope.launch {
                    val rate = db.settings().get(SettingKeys.RATE_CDF_PER_USD)?.toLongOrNull()
                    if (currency != main && rate == null) {
                        error = "Renseignez d'abord le taux de change dans les paramètres."
                        return@launch
                    }
                    val inMain = if (currency == main) a else FinanceCalculator.convert(a, Currency.valueOf(currency), Currency.valueOf(main), rate!!)
                    val e = (existing ?: Expense(categoryId = catId!!, amount = a, currency = currency, amountInMain = inMain)).copy(
                        date = d, categoryId = catId!!, description = desc.trim(), amount = a, currency = currency,
                        amountInMain = inMain, method = method, reference = ref.trim(), attachmentPath = attachment
                    )
                    if (existing == null) db.expenses().insert(e) else db.expenses().update(e)
                    onClose()
                }
            }
        }
    ) {
        TextField1(date, "Date (jj/mm/aaaa)", { date = it })
        Text("Catégorie")
        ChipRow(categories.filter { it.active || it.id == catId }.map { it.id.toString() to it.name }, catId?.toString()) { catId = it.toLong() }
        TextField1(desc, "Description", { desc = it })
        MoneyField(amount, "Montant", { amount = it })
        ChipRow(listOf("USD" to "USD", "CDF" to "CDF"), currency) { currency = it }
        Text("Mode de paiement")
        ChipRow(PAY_METHODS, method) { method = it }
        TextField1(ref, "Référence (facultatif)", { ref = it })
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Thumbnail(attachment, 48)
            OutlinedButton({ picker.launch("image/*") }) { Text(if (attachment == null) "Joindre un justificatif (photo)" else "Changer le justificatif") }
        }
    }
}
