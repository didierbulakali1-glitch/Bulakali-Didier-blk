package com.didi.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.didi.app.data.AppUser
import com.didi.app.data.SettingKeys
import com.didi.app.domain.PinHasher
import com.didi.app.domain.Session
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Dest(val title: String) {
    HOME("Accueil"), POS("Caisse"), PRODUCTS("Produits"), MENU("Plus"),
    PHONES("Téléphones et IMEI"), CATEGORIES("Catégories"), SALES("Historique des ventes"),
    CUSTOMERS("Clients"), DEBTS("Dettes clients"), SUPPLIERS("Fournisseurs"), PURCHASES("Achats"),
    EXPENSES("Dépenses"), REPAIRS("Garanties et réparations"), REPORTS("Rapports"),
    USERS("Utilisateurs"), BACKUP("Sauvegardes et exports"), SETTINGS("Paramètres du commerce"),
    FEATURES("Gestion des fonctionnalités")
}

private val MAIN_TABS = setOf(Dest.HOME, Dest.POS, Dest.PRODUCTS, Dest.MENU)

private fun permKey(d: Dest): String? = when (d) {
    Dest.HOME -> "dashboard"; Dest.POS -> "pos"; Dest.PRODUCTS -> "products"; Dest.PHONES -> "phones"
    Dest.CATEGORIES -> "categories"; Dest.SALES -> "sales"; Dest.CUSTOMERS -> "customers"; Dest.DEBTS -> "debts"
    Dest.SUPPLIERS -> "suppliers"; Dest.PURCHASES -> "purchases"; Dest.EXPENSES -> "expenses"
    Dest.REPAIRS -> "repairs"; Dest.REPORTS -> "reports"; Dest.USERS -> "users"; Dest.BACKUP -> "backup"
    Dest.SETTINGS -> "settings"; Dest.FEATURES -> "features"; Dest.MENU -> null
}

/** Modules facultatifs que l'administrateur peut activer/désactiver (les données restent intactes). */
val OPTIONAL_FEATURES = listOf(
    "phones" to "Téléphones et IMEI", "suppliers" to "Fournisseurs", "purchases" to "Achats",
    "expenses" to "Dépenses", "repairs" to "Garanties et réparations", "reports" to "Rapports"
)

private val MENU_ITEMS = listOf(
    Dest.SALES, Dest.CUSTOMERS, Dest.DEBTS, Dest.PHONES, Dest.CATEGORIES, Dest.SUPPLIERS, Dest.PURCHASES,
    Dest.EXPENSES, Dest.REPAIRS, Dest.REPORTS, Dest.BACKUP, Dest.USERS, Dest.SETTINGS, Dest.FEATURES
)

private val DidiBlue = Color(0xFF0D2B52)

class MainActivity : ComponentActivity() {
    private var stoppedAt = 0L

    override fun onStop() { super.onStop(); stoppedAt = System.currentTimeMillis() }

    override fun onStart() {
        super.onStart()
        // Verrouillage automatique après 60 s en arrière-plan (si des utilisateurs avec PIN existent)
        if (stoppedAt > 0 && System.currentTimeMillis() - stoppedAt > 60_000 && Session.usersExist) Session.user = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as DidiApp
        setContent {
            val settings by app.db.settings().observeAll().collectAsState(emptyList())
            val map = settings.associate { it.key to it.value }
            val dark = when (map[SettingKeys.DARK_THEME]) {
                "dark" -> true; "light" -> false; else -> isSystemInDarkTheme()
            }
            val accent = when (map[SettingKeys.ACCENT]) {
                "vert" -> Color(0xFF2E9E6B); "rouge" -> Color(0xFFD64545); else -> Color(0xFFF2A900)
            }
            MaterialTheme(
                colorScheme = if (dark) darkColorScheme(primary = accent)
                else lightColorScheme(primary = DidiBlue, secondary = accent)
            ) { DidiRoot(app, map) }
        }
    }
}

@Composable
fun DidiRoot(app: DidiApp, settings: Map<String, String>) {
    val activeCount by app.db.users().observeActiveCount().collectAsState(null)
    val count = activeCount
    if (count == null) return
    Session.usersExist = count > 0
    if (Session.usersExist && Session.user == null) {
        LoginScreen(app)
    } else {
        MainShell(app, settings)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainShell(app: DidiApp, settings: Map<String, String>) {
    val first = remember(Session.user) {
        when {
            Session.can("dashboard") -> Dest.HOME
            Session.can("pos") -> Dest.POS
            else -> Dest.MENU
        }
    }
    var dest by remember(Session.user) { mutableStateOf(first) }
    fun featureOn(key: String) = settings[SettingKeys.feature(key)] != "false"

    BackHandler(enabled = dest != Dest.HOME && dest != first) {
        dest = if (dest in MAIN_TABS) first else Dest.MENU
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(if (dest == Dest.HOME) "DIDI" else dest.title) },
                navigationIcon = {
                    if (dest !in MAIN_TABS) IconButton({ dest = Dest.MENU }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    if (Session.usersExist) TextButton({ Session.user = null }) { Text("Verrouiller") }
                }
            )
        },
        bottomBar = {
            val sel = if (dest in MAIN_TABS) dest else Dest.MENU
            NavigationBar {
                NavigationBarItem(sel == Dest.HOME, { dest = Dest.HOME }, { Icon(Icons.Filled.Dashboard, null) }, label = { Text("Accueil") })
                NavigationBarItem(sel == Dest.POS, { dest = Dest.POS }, { Icon(Icons.Filled.ShoppingCart, null) }, label = { Text("Caisse") })
                NavigationBarItem(sel == Dest.PRODUCTS, { dest = Dest.PRODUCTS }, { Icon(Icons.Filled.Inventory, null) }, label = { Text("Produits") })
                NavigationBarItem(sel == Dest.MENU, { dest = Dest.MENU }, { Icon(Icons.Filled.Menu, null) }, label = { Text("Plus") })
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            val key = permKey(dest)
            if (key != null && !Session.can(key)) {
                Text("Vous n'avez pas accès à ce module. Demandez à l'administrateur.", Modifier.padding(16.dp))
            } else when (dest) {
                Dest.HOME -> DashboardScreen(app, settings[SettingKeys.SHOP_NAME].orEmpty())
                Dest.POS -> PosScreen(app)
                Dest.PRODUCTS -> ProductsScreen(app)
                Dest.MENU -> MenuScreen(settings, ::featureOn) { dest = it }
                Dest.PHONES -> PhonesScreen(app)
                Dest.CATEGORIES -> CategoriesScreen(app)
                Dest.SALES -> SalesScreen(app)
                Dest.CUSTOMERS -> CustomersScreen(app)
                Dest.DEBTS -> DebtsScreen(app)
                Dest.SUPPLIERS -> SuppliersScreen(app)
                Dest.PURCHASES -> PurchasesScreen(app)
                Dest.EXPENSES -> ExpensesScreen(app)
                Dest.REPAIRS -> RepairsScreen(app)
                Dest.REPORTS -> ReportsScreen(app)
                Dest.USERS -> UsersScreen(app)
                Dest.BACKUP -> BackupScreen(app)
                Dest.SETTINGS -> SettingsScreen(app)
                Dest.FEATURES -> FeaturesScreen(app)
            }
        }
    }
}

@Composable
private fun MenuScreen(settings: Map<String, String>, featureOn: (String) -> Boolean, go: (Dest) -> Unit) {
    val items = MENU_ITEMS.filter { d ->
        val k = permKey(d)
        (k == null || Session.can(k)) && (OPTIONAL_FEATURES.none { it.first == k } || featureOn(k!!))
    }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { d ->
            Card(Modifier.fillMaxWidth()) {
                TextButton({ go(d) }, Modifier.fillMaxWidth()) { Text(d.title, style = MaterialTheme.typography.titleMedium) }
            }
        }
    }
}

@Composable
fun LoginScreen(app: DidiApp) {
    val users by app.db.users().observeAll().collectAsState(emptyList())
    val active = users.filter { it.active }
    var selected by remember { mutableStateOf<AppUser?>(null) }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(active) { if (selected == null) selected = active.firstOrNull() }

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("DIDI", style = MaterialTheme.typography.displaySmall)
        Text("Entrez votre code PIN pour continuer")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 12.dp)) {
            active.forEach { u -> FilterChip(selected?.id == u.id, { selected = u; error = null }, { Text(u.name) }) }
        }
        OutlinedTextField(
            pin, { pin = it.filter(Char::isDigit).take(8); error = null }, label = { Text("Code PIN") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true,
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword),
            modifier = Modifier.fillMaxWidth()
        )
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            onClick = {
                val u = selected ?: return@Button
                scope.launch {
                    val ok = withContext(Dispatchers.Default) { PinHasher.verify(pin, u.pinSalt, u.pinHash) }
                    if (ok) { Session.user = u; pin = "" } else { error = "Code PIN incorrect."; pin = "" }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
        ) { Text("Déverrouiller") }
    }
}
