package com.didi.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.didi.app.data.Product
import com.didi.app.domain.FinanceCalculator
import kotlinx.coroutines.launch
import java.util.Calendar

private val DidiBlue = Color(0xFF0D2B52)
private val DidiAccent = Color(0xFFF2A900)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as DidiApp
        setContent {
            val dark = isSystemInDarkTheme()
            MaterialTheme(
                colorScheme = if (dark) darkColorScheme(primary = DidiAccent)
                else lightColorScheme(primary = DidiBlue, secondary = DidiAccent)
            ) { DidiRoot(app) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DidiRoot(app: DidiApp) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("DIDI") }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.Dashboard, null) }, label = { Text("Accueil") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.ShoppingCart, null) }, label = { Text("Caisse") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Filled.Inventory, null) }, label = { Text("Produits") })
                NavigationBarItem(tab == 3, { tab = 3 }, { Icon(Icons.Filled.Settings, null) }, label = { Text("Réglages") })
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> DashboardScreen(app)
                1 -> PosScreen(app)
                2 -> ProductsScreen(app)
                else -> SettingsScreen(app)
            }
        }
    }
}

private fun startOfToday(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

private fun startOfMonth(): Long = Calendar.getInstance().apply {
    set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Text(value, style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
fun DashboardScreen(app: DidiApp) {
    val db = app.db
    val dayFrom = remember { startOfToday() }
    val monthFrom = remember { startOfMonth() }
    val now = Long.MAX_VALUE

    val revenueDay by db.sales().observeRevenue(dayFrom, now).collectAsState(0L)
    val revenueMonth by db.sales().observeRevenue(monthFrom, now).collectAsState(0L)
    val cogsDay by db.sales().observeCogs(dayFrom, now).collectAsState(0L)
    val expensesDay by db.expenses().observeTotal(dayFrom, now).collectAsState(0L)
    val salesCount by db.sales().observeSalesCount(monthFrom, now).collectAsState(0)
    val receivables by db.sales().observeReceivables().collectAsState(0L)
    val stockValue by db.products().observeStockValue().collectAsState(0L)
    val units by db.products().observeUnitsInStock().collectAsState(0)
    val out by db.products().observeOutOfStockCount().collectAsState(0)
    val low by db.products().observeLowStockCount().collectAsState(0)

    val gross = FinanceCalculator.grossProfit(revenueDay, cogsDay)
    val net = FinanceCalculator.netProfit(gross, expensesDay)
    fun m(v: Long) = FinanceCalculator.formatMinor(v)

    LazyColumn(
        Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { Text("Montants dans la devise principale du commerce", style = MaterialTheme.typography.bodySmall) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Chiffre d'affaires du jour", m(revenueDay), Modifier.weight(1f))
                StatCard("Chiffre d'affaires du mois", m(revenueMonth), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Bénéfice brut (jour)", m(gross), Modifier.weight(1f))
                StatCard("Bénéfice net estimé (jour)", m(net), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Dépenses du jour", m(expensesDay), Modifier.weight(1f))
                StatCard("Ventes du mois", salesCount.toString(), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Valeur du stock", m(stockValue), Modifier.weight(1f))
                StatCard("Articles en stock", units.toString(), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("En rupture", out.toString(), Modifier.weight(1f))
                StatCard("Stock faible", low.toString(), Modifier.weight(1f))
            }
        }
        item { StatCard("Dettes des clients", m(receivables), Modifier.fillMaxWidth()) }
    }
}

@Composable
fun ProductsScreen(app: DidiApp) {
    val db = app.db
    val products by db.products().observeActive().collectAsState(emptyList())
    val categories by db.categories().observeAll().collectAsState(emptyList())
    var showAdd by remember { mutableStateOf(false) }
    var toArchive by remember { mutableStateOf<Product?>(null) }
    val scope = rememberCoroutineScope()

    androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
        if (products.isEmpty()) {
            Text("Aucun produit enregistré. Touchez + pour en ajouter.", Modifier.padding(16.dp))
        }
        LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(products, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium)
                            Text("Vente : ${FinanceCalculator.formatMinor(p.salePrice)} · Stock : ${p.stockQty}")
                        }
                        TextButton({ toArchive = p }) { Text("Archiver") }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { showAdd = true },
            modifier = Modifier.align(androidx.compose.ui.Alignment.BottomEnd).padding(16.dp)
        ) { Text("+") }
    }

    if (showAdd) {
        var name by remember { mutableStateOf("") }
        var cost by remember { mutableStateOf("") }
        var price by remember { mutableStateOf("") }
        var qty by remember { mutableStateOf("") }
        var minQty by remember { mutableStateOf("") }
        var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Nouveau produit") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Nom") })
                    OutlinedTextField(cost, { cost = it }, label = { Text("Prix d'achat") })
                    OutlinedTextField(price, { price = it }, label = { Text("Prix de vente") })
                    OutlinedTextField(qty, { qty = it }, label = { Text("Quantité en stock") })
                    OutlinedTextField(minQty, { minQty = it }, label = { Text("Seuil minimal") })
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton({
                    val c = FinanceCalculator.parseToMinor(cost)
                    val s = FinanceCalculator.parseToMinor(price)
                    val q = qty.toIntOrNull()
                    val mq = minQty.ifBlank { "0" }.toIntOrNull()
                    val catId = categories.firstOrNull { it.name == "Autres accessoires" }?.id
                        ?: categories.firstOrNull()?.id
                    when {
                        name.isBlank() -> error = "Le nom est obligatoire."
                        c == null || s == null -> error = "Prix invalide."
                        q == null || q < 0 || mq == null || mq < 0 -> error = "Quantité invalide."
                        catId == null -> error = "Aucune catégorie disponible."
                        else -> scope.launch {
                            db.products().insert(
                                Product(name = name.trim(), categoryId = catId, costPrice = c,
                                    salePrice = s, stockQty = q, minStock = mq)
                            )
                            showAdd = false
                        }
                    }
                }) { Text("Enregistrer") }
            },
            dismissButton = { TextButton({ showAdd = false }) { Text("Annuler") } }
        )
    }

    toArchive?.let { p ->
        AlertDialog(
            onDismissRequest = { toArchive = null },
            title = { Text("Archiver « ${p.name} » ?") },
            text = { Text("Le produit n'apparaîtra plus dans la liste, mais l'historique de ses ventes est conservé.") },
            confirmButton = {
                TextButton({ scope.launch { db.products().archive(p.id); toArchive = null } }) { Text("Archiver") }
            },
            dismissButton = { TextButton({ toArchive = null }) { Text("Annuler") } }
        )
    }
}
