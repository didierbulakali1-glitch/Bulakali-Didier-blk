package com.didi.app

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.room.withTransaction
import com.didi.app.data.PhoneUnit
import com.didi.app.data.Product
import com.didi.app.data.RepairCase
import com.didi.app.data.Sale
import com.didi.app.data.StockMovement
import com.didi.app.data.Supplier
import com.didi.app.data.UnitStatus
import com.didi.app.domain.CsvExport
import com.didi.app.domain.addMonths
import com.didi.app.domain.formatDate
import com.didi.app.domain.formatDateTime
import kotlinx.coroutines.launch

private val UNIT_STATUSES = listOf(
    UnitStatus.IN_STOCK to "En stock", UnitStatus.SOLD to "Vendu", UnitStatus.RETURNED to "Retourné",
    UnitStatus.IN_REPAIR to "En réparation", UnitStatus.DEFECTIVE to "Défectueux"
)

private fun unitStatusLabel(s: String) = UNIT_STATUSES.firstOrNull { it.first == s }?.second ?: s

/** Liste de tous les téléphones suivis par IMEI, avec recherche par IMEI, modèle ou numéro de série. */
@Composable
fun PhonesScreen(app: DidiApp) {
    val db = app.db
    val scope = rememberCoroutineScope()
    val units by remember(db) { db.phoneUnits().observeAll() }.collectAsState(emptyList())
    val products by remember(db) { db.products().observeAll() }.collectAsState(emptyList())
    val names = products.associate { it.id to it.name }
    var query by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("all") }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var showChoose by remember { mutableStateOf(false) }
    var addFor by remember { mutableStateOf<Product?>(null) }
    val saver = rememberFileSaver("text/csv")

    val shown = units.filter { u ->
        (status == "all" || u.status == status) &&
            (query.isBlank() || u.imei1.contains(query) || u.imei2?.contains(query) == true ||
                u.serial?.contains(query, true) == true || (names[u.productId] ?: "").contains(query, true))
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            TextField1(query, "Rechercher par IMEI, série ou modèle", { query = it }, Modifier.fillMaxWidth().padding(vertical = 6.dp))
            ChipRow(listOf("all" to "Tous") + UNIT_STATUSES, status) { status = it }
            Row(Modifier.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${shown.size} appareil(s)")
                OutlinedButton({ scope.launch { saver("didi-telephones.csv", CsvExport.units(db)) } }) { Text("Exporter CSV") }
            }
            if (units.isEmpty()) Text("Aucun téléphone enregistré. Touchez + pour en ajouter, ou réceptionnez un achat avec des IMEI.")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.id }) { u ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(names[u.productId] ?: "Téléphone", style = MaterialTheme.typography.titleSmall)
                                Text("IMEI ${u.imei1} · ${unitStatusLabel(u.status)} · ${fmt(u.salePrice)}")
                            }
                            TextButton({ selectedId = u.id }) { Text("Fiche") }
                        }
                    }
                }
                item { Box(Modifier.heightIn(min = 80.dp)) }
            }
        }
        FloatingActionButton({ showChoose = true }, Modifier.align(Alignment.BottomEnd).padding(16.dp)) { Text("+") }
    }

    if (showChoose) {
        val phoneProducts = products.filter { it.tracksImei && !it.archived }
        FormDialog(title = "Ajouter un téléphone", confirmLabel = "Fermer", onDismiss = { showChoose = false }, onConfirm = { showChoose = false }) {
            if (phoneProducts.isEmpty()) {
                Text("Créez d'abord un produit de catégorie « Smartphones » ou « Téléphones simples » dans l'onglet Produits : il sera suivi par IMEI.")
            } else {
                Text("Choisissez le modèle :")
                phoneProducts.forEach { p -> TextButton({ addFor = p; showChoose = false }) { Text(p.name) } }
            }
        }
    }
    addFor?.let { PhoneUnitDialog(app, it) { addFor = null } }

    selectedId?.let { id ->
        val u = units.firstOrNull { it.id == id }
        if (u != null) PhoneDetailDialog(app, u, names[u.productId] ?: "Téléphone") { selectedId = null }
    }
}

@Composable
private fun PhoneDetailDialog(app: DidiApp, unit: PhoneUnit, productName: String, onClose: () -> Unit) {
    val db = app.db
    val scope = rememberCoroutineScope()
    val sale by produceState<Sale?>(null, unit.id, unit.status) { value = db.sales().saleOfUnit(unit.id) }
    val repairs by produceState(emptyList<RepairCase>(), unit.imei1) { value = db.repairs().ofImei(unit.imei1) }
    val supplier by produceState<Supplier?>(null, unit.supplierId) { value = unit.supplierId?.let { db.suppliers().get(it) } }
    val customerName by produceState<String?>(null, sale?.customerId) { value = sale?.customerId?.let { db.customers().get(it)?.fullName } }
    var newStatus by remember { mutableStateOf<String?>(null) }

    InfoDialog(productName, onClose) {
        val s = sale
        val warrantyLine = when {
            unit.warrantyMonths <= 0 -> "Garantie : aucune"
            s == null -> "Garantie : ${unit.warrantyMonths} mois, démarre à la vente"
            else -> {
                val end = addMonths(s.createdAt, unit.warrantyMonths)
                "Garantie : ${unit.warrantyMonths} mois, jusqu'au ${formatDate(end)}" +
                    if (System.currentTimeMillis() <= end) " (en cours)" else " (expirée)"
            }
        }
        Text(
            listOfNotNull(
                "IMEI 1 : ${unit.imei1}",
                unit.imei2?.let { "IMEI 2 : $it" },
                unit.serial?.let { "Série : $it" },
                "${unit.color} ${unit.storage} ${unit.ram}".trim().ifBlank { null },
                "État : ${unit.condition} · Statut : ${unitStatusLabel(unit.status)}",
                "Acheté le ${formatDate(unit.purchasedAt)}" + (supplier?.let { " chez ${it.name}" } ?: ""),
                "Prix d'achat : ${fmt(unit.costPrice)} · Prix de vente : ${fmt(unit.salePrice)}",
                warrantyLine,
                s?.let { "Vendu le ${formatDateTime(it.createdAt)} (vente ${it.number})" + (customerName?.let { n -> " à $n" } ?: "") }
            ).joinToString("\n")
        )
        if (repairs.isNotEmpty()) {
            Text("Réparations", style = MaterialTheme.typography.titleSmall)
            repairs.forEach { Text("${it.number} · ${formatDate(it.receivedAt)} · ${it.status} · ${it.problem}") }
        }
        if (unit.status != UnitStatus.SOLD) {
            Text("Changer le statut (ajuste le stock disponible)", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(UnitStatus.IN_STOCK, UnitStatus.IN_REPAIR, UnitStatus.DEFECTIVE, UnitStatus.RETURNED)
                    .filter { it != unit.status }
                    .forEach { st -> OutlinedButton({ newStatus = st }) { Text(unitStatusLabel(st)) } }
            }
        } else {
            Text("Un appareil vendu ne change de statut que par un retour ou une annulation de la vente.", style = MaterialTheme.typography.bodySmall)
        }
    }

    newStatus?.let { st ->
        ConfirmDialog(
            "Changer le statut ?", "L'appareil ${unit.imei1} passera à « ${unitStatusLabel(st)} ».", "Confirmer",
            {
                scope.launch {
                    db.withTransaction {
                        db.phoneUnits().setStatus(unit.id, st)
                        val delta = when {
                            unit.status == UnitStatus.IN_STOCK && st != UnitStatus.IN_STOCK -> -1
                            unit.status != UnitStatus.IN_STOCK && st == UnitStatus.IN_STOCK -> 1
                            else -> 0
                        }
                        if (delta != 0) db.products().insertMovement(
                            StockMovement(productId = unit.productId, phoneUnitId = unit.id, type = "AJUSTEMENT", quantityDelta = delta,
                                note = "Statut ${unitStatusLabel(unit.status)} → ${unitStatusLabel(st)}")
                        )
                    }
                    newStatus = null
                }
            },
            { newStatus = null }
        )
    }
}
