package com.didi.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.didi.app.data.Customer
import com.didi.app.data.PhoneUnit
import com.didi.app.data.Product
import com.didi.app.data.Sale
import com.didi.app.data.SettingKeys
import com.didi.app.domain.CartLine
import com.didi.app.domain.CheckoutRequest
import com.didi.app.domain.Currency
import com.didi.app.domain.FinanceCalculator
import com.didi.app.domain.ReceiptPdf
import com.didi.app.domain.SaleException
import kotlinx.coroutines.launch
import java.util.UUID

private data class CartEntry(val product: Product, val qty: Int, val discount: Long, val unit: PhoneUnit?) {
    val unitPrice: Long get() = unit?.salePrice ?: product.salePrice
}

private val METHODS = listOf(
    "ESPECES" to "Espèces", "MOBILE_MONEY" to "Mobile Money", "VIREMENT" to "Virement",
    "CARTE" to "Carte", "AUTRE" to "Autre"
)

@Composable
fun PosScreen(app: DidiApp) {
    val db = app.db
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val products by db.products().observeActive().collectAsState(emptyList())
    val customers by db.customers().observeAll().collectAsState(emptyList())
    val settings by db.settings().observeAll().collectAsState(emptyList())
    val settingMap = settings.associate { it.key to it.value }
    val mainCurrency = runCatching { Currency.valueOf(settingMap[SettingKeys.MAIN_CURRENCY] ?: "USD") }.getOrDefault(Currency.USD)
    val rate = settingMap[SettingKeys.RATE_CDF_PER_USD]?.toLongOrNull()

    val cart = remember { mutableStateListOf<CartEntry>() }
    var token by remember { mutableStateOf(UUID.randomUUID().toString()) }
    var query by remember { mutableStateOf("") }
    var customer by remember { mutableStateOf<Customer?>(null) }
    var method by remember { mutableStateOf("ESPECES") }
    var reference by remember { mutableStateOf("") }
    var payCurrency by remember { mutableStateOf<Currency?>(null) }
    var received by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var phoneChoice by remember { mutableStateOf<Product?>(null) }
    var showCustomers by remember { mutableStateOf(false) }
    var doneSale by remember { mutableStateOf<Sale?>(null) }

    val currency = payCurrency ?: mainCurrency
    val subtotal = cart.sumOf { it.unitPrice * it.qty }
    val discounts = cart.sumOf { it.discount }
    val total = subtotal - discounts

    fun addProduct(p: Product, unit: PhoneUnit?) {
        error = null
        if (unit != null) {
            if (cart.any { it.unit?.id == unit.id }) return
            cart.add(CartEntry(p, 1, 0, unit))
        } else {
            val i = cart.indexOfFirst { it.product.id == p.id && it.unit == null }
            if (i >= 0) cart[i] = cart[i].copy(qty = cart[i].qty + 1) else cart.add(CartEntry(p, 1, 0, null))
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { OutlinedTextField(query, { query = it }, label = { Text("Rechercher un produit") }, modifier = Modifier.fillMaxWidth()) }

        val found = if (query.isBlank()) emptyList()
        else products.filter {
            it.name.contains(query, true) || it.sku?.contains(query, true) == true || it.barcode == query
        }.take(6)
        items(found, key = { "f" + it.id }) { p ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, style = MaterialTheme.typography.titleSmall)
                        Text(
                            FinanceCalculator.formatMinor(p.salePrice) + if (p.tracksImei) " · par IMEI" else " · stock ${p.stockQty}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    TextButton({ if (p.tracksImei) phoneChoice = p else { addProduct(p, null); query = "" } }) { Text("Ajouter") }
                }
            }
        }

        item { Text("Panier", style = MaterialTheme.typography.titleMedium) }
        if (cart.isEmpty()) item { Text("Le panier est vide. Recherchez un produit ci-dessus.") }
        itemsIndexed(cart.toList(), key = { _, x -> "c${x.product.id}-${x.unit?.id ?: 0}" }) { i, _ ->
            val e = cart.getOrNull(i) ?: return@itemsIndexed
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(e.product.name + (e.unit?.let { " (IMEI ${it.imei1})" } ?: ""), style = MaterialTheme.typography.titleSmall)
                    Text("${FinanceCalculator.formatMinor(e.unitPrice)} x ${e.qty} = ${FinanceCalculator.formatMinor(e.unitPrice * e.qty - e.discount)}")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (e.unit == null) {
                            OutlinedButton({ if (e.qty > 1) cart[i] = e.copy(qty = e.qty - 1, discount = 0) }) { Text("-") }
                            OutlinedButton({ cart[i] = e.copy(qty = e.qty + 1, discount = 0) }) { Text("+") }
                        }
                        var disc by remember(e.product.id, e.unit?.id) { mutableStateOf(if (e.discount > 0) FinanceCalculator.formatMinor(e.discount) else "") }
                        OutlinedTextField(
                            disc,
                            {
                                disc = it
                                val d = if (it.isBlank()) 0L else FinanceCalculator.parseToMinor(it)
                                if (d != null && d in 0..(e.unitPrice * e.qty)) cart[i] = cart[i].copy(discount = d)
                            },
                            label = { Text("Remise") }, singleLine = true, modifier = Modifier.weight(1f)
                        )
                        TextButton({ cart.removeAt(i) }) { Text("Retirer") }
                    }
                }
            }
        }

        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Total : ${FinanceCalculator.formatMinor(total)} ${mainCurrency.name}", style = MaterialTheme.typography.titleLarge)
                    OutlinedButton({ showCustomers = true }) { Text("Client : " + (customer?.fullName ?: "aucun")) }
                    Text("Mode de paiement")
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        METHODS.take(3).forEach { (k, l) -> FilterChip(method == k, { method = k }, { Text(l) }) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        METHODS.drop(3).forEach { (k, l) -> FilterChip(method == k, { method = k }, { Text(l) }) }
                    }
                    if (method != "ESPECES") {
                        OutlinedTextField(reference, { reference = it }, label = { Text("Référence de transaction (facultatif)") }, modifier = Modifier.fillMaxWidth())
                    }
                    Text("Devise reçue")
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Currency.values().forEach { c -> FilterChip(currency == c, { payCurrency = c }, { Text(c.name) }) }
                    }
                    if (currency != mainCurrency && rate == null) {
                        Text("Taux de change non renseigné (onglet Réglages).", color = MaterialTheme.colorScheme.error)
                    }
                    OutlinedTextField(received, { received = it }, label = { Text("Montant reçu en ${currency.name}") }, modifier = Modifier.fillMaxWidth())
                    OutlinedButton({
                        val inCur = if (currency == mainCurrency || rate == null) total
                        else FinanceCalculator.convert(total, mainCurrency, currency, rate)
                        received = FinanceCalculator.formatMinor(inCur)
                    }) { Text("Tout payer") }
                    Text("Si le montant reçu est inférieur au total, la vente est enregistrée à crédit (client obligatoire).", style = MaterialTheme.typography.bodySmall)
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    Button(
                        enabled = cart.isNotEmpty() && !busy,
                        onClick = {
                            val amount = if (received.isBlank()) 0L else FinanceCalculator.parseToMinor(received)
                            if (amount == null) { error = "Montant reçu invalide."; return@Button }
                            busy = true; error = null
                            scope.launch {
                                try {
                                    val sale = app.saleService.checkout(
                                        CheckoutRequest(
                                            clientToken = token,
                                            lines = cart.map { CartLine(it.product.id, it.qty, it.unitPrice, it.discount, it.unit?.id) },
                                            customerId = customer?.id, paymentMethod = method,
                                            paymentReference = reference, paymentCurrency = currency, amountReceived = amount
                                        )
                                    )
                                    doneSale = sale
                                    cart.clear(); received = ""; reference = ""; customer = null; query = ""
                                    payCurrency = null; token = UUID.randomUUID().toString()
                                } catch (e: SaleException) {
                                    error = e.message
                                } catch (e: Exception) {
                                    error = "Erreur inattendue : ${e.message}"
                                } finally { busy = false }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Valider la vente") }
                }
            }
        }
    }

    phoneChoice?.let { p ->
        val units by db.phoneUnits().observeAvailable(p.id).collectAsState(emptyList())
        AlertDialog(
            onDismissRequest = { phoneChoice = null },
            title = { Text("Choisir l'appareil (IMEI)") },
            text = {
                if (units.isEmpty()) Text("Aucun appareil en stock pour ce modèle.")
                else LazyColumn(Modifier.heightIn(max = 300.dp)) { items(units, key = { it.id }) { u ->
                    TextButton({ addProduct(p, u); phoneChoice = null; query = "" }) {
                        Text("${u.imei1} · ${u.color} ${u.storage} · ${FinanceCalculator.formatMinor(u.salePrice)}")
                    }
                } }
            },
            confirmButton = { TextButton({ phoneChoice = null }) { Text("Fermer") } }
        )
    }

    if (showCustomers) {
        var newName by remember { mutableStateOf("") }
        var newPhone by remember { mutableStateOf("") }
        var warn by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showCustomers = false },
            title = { Text("Client") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton({ customer = null; showCustomers = false }) { Text("Aucun client") }
                    LazyColumn(Modifier.heightIn(max = 200.dp)) {
                        items(customers, key = { it.id }) { c ->
                            TextButton({ customer = c; showCustomers = false }) { Text(c.fullName + if (c.phone.isNotBlank()) " · ${c.phone}" else "") }
                        }
                    }
                    Text("Nouveau client", style = MaterialTheme.typography.titleSmall)
                    OutlinedTextField(newName, { newName = it }, label = { Text("Nom complet") })
                    OutlinedTextField(newPhone, { newPhone = it }, label = { Text("Téléphone") })
                    warn?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton({
                    if (newName.isBlank()) { warn = "Le nom est obligatoire."; return@TextButton }
                    scope.launch {
                        val dup = if (newPhone.isBlank()) null else db.customers().findByPhone(newPhone.trim())
                        if (dup != null && warn == null) {
                            warn = "Un client avec ce numéro existe déjà : ${dup.fullName}. Touchez de nouveau pour créer quand même."
                        } else {
                            val id = db.customers().insert(Customer(fullName = newName.trim(), phone = newPhone.trim()))
                            customer = db.customers().get(id)
                            showCustomers = false
                        }
                    }
                }) { Text("Créer ce client") }
            },
            dismissButton = { TextButton({ showCustomers = false }) { Text("Fermer") } }
        )
    }

    doneSale?.let { s ->
        AlertDialog(
            onDismissRequest = { doneSale = null },
            title = { Text("Vente ${s.number} enregistrée") },
            text = {
                val bal = FinanceCalculator.balance(s.total, s.paidAmount)
                Text("Total ${FinanceCalculator.formatMinor(s.total)} ${s.currency}" +
                    if (bal > 0) "\nReste à payer : ${FinanceCalculator.formatMinor(bal)} ${s.currency}" else "\nPayée en totalité.")
            },
            confirmButton = {
                TextButton({
                    scope.launch {
                        val f = ReceiptPdf.create(context, db, s)
                        ReceiptPdf.share(context, f)
                    }
                }) { Text("Reçu PDF / Partager") }
            },
            dismissButton = { TextButton({ doneSale = null }) { Text("Fermer") } }
        )
    }
}
