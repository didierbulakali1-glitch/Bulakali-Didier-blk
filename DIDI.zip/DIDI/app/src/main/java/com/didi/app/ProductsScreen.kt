package com.didi.app

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.room.withTransaction
import com.didi.app.data.Category
import com.didi.app.data.PhoneUnit
import com.didi.app.data.Product
import com.didi.app.data.StockMovement
import com.didi.app.domain.FinanceCalculator
import com.didi.app.domain.Session
import com.didi.app.domain.formatDate
import com.didi.app.domain.formatDateTime
import kotlinx.coroutines.launch

private enum class SortMode(val label: String) { NAME("Nom"), STOCK("Stock"), PRICE("Prix") }

@Composable
fun ProductsScreen(app: DidiApp) {
    val db = app.db
    val products by db.products().observeActive().collectAsState(emptyList())
    val categories by db.categories().observeAll().collectAsState(emptyList())
    val unitCounts by db.products().observeUnitCounts().collectAsState(emptyList())
    val units = unitCounts.associate { it.productId to it.n }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var catFilter by remember { mutableStateOf<Long?>(null) }
    var sort by remember { mutableStateOf(SortMode.NAME) }
    var lowOnly by remember { mutableStateOf(false) }

    selectedId?.let { id ->
        ProductDetail(app, id, categories) { selectedId = null }
        return
    }

    fun stockOf(p: Product) = if (p.tracksImei) units[p.id] ?: 0 else p.stockQty
    val shown = products
        .filter { catFilter == null || it.categoryId == catFilter }
        .filter { query.isBlank() || it.name.contains(query, true) || it.sku?.contains(query, true) == true || it.barcode == query || it.brand.contains(query, true) || it.model.contains(query, true) }
        .filter { !lowOnly || stockOf(it) <= it.minStock }
        .let { l ->
            when (sort) {
                SortMode.NAME -> l.sortedBy { it.name.lowercase() }
                SortMode.STOCK -> l.sortedBy { stockOf(it) }
                SortMode.PRICE -> l.sortedByDescending { it.salePrice }
            }
        }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            TextField1(query, "Rechercher (nom, SKU, code-barres, marque)", { query = it }, Modifier.fillMaxWidth().padding(top = 8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                item { FilterChip(catFilter == null, { catFilter = null }, { Text("Toutes") }) }
                items(categories.filter { it.active }, key = { it.id }) { c ->
                    FilterChip(catFilter == c.id, { catFilter = c.id }, { Text(c.name) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SortMode.values().forEach { m -> FilterChip(sort == m, { sort = m }, { Text(m.label) }) }
                FilterChip(lowOnly, { lowOnly = !lowOnly }, { Text("Stock bas") })
            }
            if (shown.isEmpty()) {
                Text(
                    if (products.isEmpty()) "Aucun produit enregistré. Touchez + pour en ajouter." else "Aucun produit ne correspond.",
                    Modifier.padding(vertical = 16.dp)
                )
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                items(shown, key = { it.id }) { p ->
                    val st = stockOf(p)
                    val label = when { st <= 0 -> "Rupture"; st <= p.minStock -> "Stock faible"; else -> "" }
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Thumbnail(p.photoPath)
                            Column(Modifier.weight(1f)) {
                                Text(p.name, style = MaterialTheme.typography.titleMedium)
                                Text("Vente ${fmt(p.salePrice)} · Stock $st" + if (label.isNotEmpty()) " · $label" else "",
                                    color = if (label.isNotEmpty()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                            }
                            TextButton({ selectedId = p.id }) { Text("Fiche") }
                        }
                    }
                }
                item { Box(Modifier.heightIn(min = 80.dp)) }
            }
        }
        FloatingActionButton({ showAdd = true }, Modifier.align(Alignment.BottomEnd).padding(16.dp)) { Text("+") }
    }

    if (showAdd) ProductEditDialog(app, null, categories) { showAdd = false }
}

@Composable
fun ProductEditDialog(app: DidiApp, existing: Product?, categories: List<Category>, onClose: () -> Unit) {
    val db = app.db
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(existing?.name.orEmpty()) }
    var sku by remember { mutableStateOf(existing?.sku.orEmpty()) }
    var barcode by remember { mutableStateOf(existing?.barcode.orEmpty()) }
    var brand by remember { mutableStateOf(existing?.brand.orEmpty()) }
    var model by remember { mutableStateOf(existing?.model.orEmpty()) }
    var description by remember { mutableStateOf(existing?.description.orEmpty()) }
    var cost by remember { mutableStateOf(existing?.let { fmt(it.costPrice) }.orEmpty()) }
    var price by remember { mutableStateOf(existing?.let { fmt(it.salePrice) }.orEmpty()) }
    var qty by remember { mutableStateOf("") }
    var minQty by remember { mutableStateOf(existing?.minStock?.toString() ?: "0") }
    var warranty by remember { mutableStateOf(existing?.warrantyMonths?.toString() ?: "0") }
    var condition by remember { mutableStateOf(existing?.condition ?: "NEUF") }
    var location by remember { mutableStateOf(existing?.location.orEmpty()) }
    var catId by remember { mutableStateOf(existing?.categoryId ?: categories.firstOrNull { it.active }?.id) }
    var photo by remember { mutableStateOf(existing?.photoPath) }
    var error by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) copyIntoApp(context, uri, "photos")?.let { photo = it }
    }
    val tracksImei = existing?.tracksImei ?: (categories.firstOrNull { it.id == catId }?.isPhone == true)

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (existing == null) "Nouveau produit" else "Modifier le produit") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                TextField1(name, "Nom du produit", { name = it })
                Text("Catégorie")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(categories.filter { it.active || it.id == catId }, key = { it.id }) { c ->
                        FilterChip(catId == c.id, { if (existing == null || existing.categoryId == c.id || !existing.tracksImei) catId = c.id }, { Text(c.name) })
                    }
                }
                if (tracksImei) Text("Les téléphones sont suivis un par un avec leur IMEI.", style = MaterialTheme.typography.bodySmall)
                TextField1(sku, "Référence interne (SKU)", { sku = it })
                TextField1(barcode, "Code-barres (saisi à la main)", { barcode = it })
                TextField1(brand, "Marque", { brand = it })
                TextField1(model, "Modèle", { model = it })
                TextField1(description, "Description", { description = it })
                MoneyField(cost, "Prix d'achat", { cost = it })
                MoneyField(price, "Prix de vente", { price = it })
                if (existing == null && !tracksImei) IntField(qty, "Quantité en stock au départ", { qty = it })
                if (!tracksImei) IntField(minQty, "Seuil minimal de stock", { minQty = it })
                IntField(warranty, "Garantie (mois)", { warranty = it })
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("NEUF", "OCCASION", "RECONDITIONNE").forEach { c -> FilterChip(condition == c, { condition = c }, { Text(c.lowercase().replaceFirstChar { it.uppercase() }) }) }
                }
                TextField1(location, "Emplacement dans la boutique", { location = it })
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Thumbnail(photo)
                    OutlinedButton({ picker.launch("image/*") }) { Text(if (photo == null) "Ajouter une photo" else "Changer la photo") }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton({
                val c = FinanceCalculator.parseToMinor(cost.ifBlank { "0" })
                val s = FinanceCalculator.parseToMinor(price.ifBlank { "0" })
                val q = if (existing != null || tracksImei) 0 else qty.ifBlank { "0" }.toIntOrNull()
                val mq = minQty.ifBlank { "0" }.toIntOrNull()
                val w = warranty.ifBlank { "0" }.toIntOrNull()
                when {
                    name.isBlank() -> error = "Le nom est obligatoire."
                    catId == null -> error = "Choisissez une catégorie."
                    c == null || s == null || c < 0 || s < 0 -> error = "Prix invalide."
                    q == null || q < 0 || mq == null || mq < 0 || w == null || w < 0 -> error = "Nombre invalide."
                    else -> scope.launch {
                        try {
                            val skuV = sku.trim().ifBlank { null }
                            val base = (existing ?: Product(name = "", categoryId = catId!!)).copy(
                                name = name.trim(), sku = skuV, barcode = barcode.trim().ifBlank { null },
                                categoryId = catId!!, brand = brand.trim(), model = model.trim(),
                                description = description.trim(), costPrice = c, salePrice = s, minStock = mq,
                                warrantyMonths = w, photoPath = photo, condition = condition, location = location.trim(),
                                tracksImei = tracksImei
                            )
                            if (existing == null) {
                                db.withTransaction {
                                    val id = db.products().insert(base.copy(stockQty = q))
                                    if (q > 0) db.products().insertMovement(
                                        StockMovement(productId = id, type = "ENTREE", quantityDelta = q, note = "Stock initial")
                                    )
                                }
                            } else db.products().update(base)
                            onClose()
                        } catch (e: android.database.sqlite.SQLiteConstraintException) {
                            error = "Cette référence (SKU) existe déjà."
                        }
                    }
                }
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClose) { Text("Annuler") } }
    )
}

@Composable
fun ProductDetail(app: DidiApp, id: Long, categories: List<Category>, onBack: () -> Unit) {
    val db = app.db
    val scope = rememberCoroutineScope()
    val product by db.products().observe(id).collectAsState(null)
    val movements by db.products().observeMovements(id).collectAsState(emptyList())
    val unitList by db.phoneUnits().observeAllOf(id).collectAsState(emptyList())
    var showEdit by remember { mutableStateOf(false) }
    var showAdjust by remember { mutableStateOf(false) }
    var showUnit by remember { mutableStateOf(false) }
    var showArchive by remember { mutableStateOf(false) }
    BackHandler(onBack = onBack)

    val p = product
    if (p == null) { Text("Produit introuvable.", Modifier.padding(16.dp)); return }
    val inStock = if (p.tracksImei) unitList.count { it.status == "EN_STOCK" } else p.stockQty

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { TextButton(onBack) { Text("← Retour à la liste") } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Thumbnail(p.photoPath, 80)
                Text(p.name, style = MaterialTheme.typography.titleLarge)
            }
        }
        item {
            InfoCard("Fiche produit", listOfNotNull(
                "Catégorie : " + (categories.firstOrNull { it.id == p.categoryId }?.name ?: "-"),
                if (p.brand.isNotBlank() || p.model.isNotBlank()) "Marque / modèle : ${p.brand} ${p.model}" else null,
                p.sku?.let { "SKU : $it" }, p.barcode?.let { "Code-barres : $it" },
                "Prix d'achat : ${fmt(p.costPrice)} · Prix de vente : ${fmt(p.salePrice)}",
                "Stock : $inStock" + if (!p.tracksImei) " (seuil ${p.minStock})" else " appareil(s) en stock",
                "Garantie : ${p.warrantyMonths} mois · État : ${p.condition}",
                if (p.location.isNotBlank()) "Emplacement : ${p.location}" else null,
                if (p.description.isNotBlank()) p.description else null,
                "Ajouté le ${formatDate(p.createdAt)}"
            ))
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton({ showEdit = true }) { Text("Modifier") }
                if (!p.tracksImei) OutlinedButton({ showAdjust = true }) { Text("Ajuster le stock") }
                else Button({ showUnit = true }) { Text("Recevoir un téléphone") }
                TextButton({ showArchive = true }) { Text("Archiver") }
            }
        }
        if (p.tracksImei) {
            item { Text("Appareils (IMEI)", style = MaterialTheme.typography.titleMedium) }
            if (unitList.isEmpty()) item { Text("Aucun appareil enregistré.") }
            items(unitList, key = { "u${it.id}" }) { u ->
                Text("${u.imei1} · ${u.color} ${u.storage} · ${u.condition} · achat ${fmt(u.costPrice)} → vente ${fmt(u.salePrice)} · ${u.status}")
            }
        }
        item { Text("Historique des mouvements de stock", style = MaterialTheme.typography.titleMedium) }
        if (movements.isEmpty()) item { Text("Aucun mouvement.") }
        items(movements, key = { "m${it.id}" }) { m ->
            Text("${formatDateTime(m.createdAt)} · ${m.type} · ${if (m.quantityDelta > 0) "+" else ""}${m.quantityDelta}" + if (m.note.isNotBlank()) " · ${m.note}" else "")
        }
    }

    if (showEdit) ProductEditDialog(app, p, categories) { showEdit = false }
    if (showArchive) ConfirmDialog(
        "Archiver « ${p.name} » ?",
        "Le produit disparaît de la liste et de la caisse, mais l'historique de ses ventes est conservé.",
        "Archiver", { scope.launch { db.products().archive(p.id); showArchive = false; onBack() } }, { showArchive = false }
    )
    if (showAdjust) {
        var delta by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showAdjust = false },
            title = { Text("Ajuster le stock") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Stock actuel : ${p.stockQty}. Saisissez +5 pour ajouter ou -2 pour retirer.")
                    TextField1(delta, "Variation (ex. +5 ou -2)", { delta = it })
                    TextField1(note, "Motif (casse, inventaire, ...)", { note = it })
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton({
                    val d = delta.trim().removePrefix("+").toIntOrNull()
                    when {
                        d == null || d == 0 -> err = "Saisissez un nombre différent de zéro."
                        p.stockQty + d < 0 -> err = "Le stock ne peut pas devenir négatif."
                        note.isBlank() -> err = "Indiquez un motif."
                        else -> scope.launch {
                            db.withTransaction {
                                db.products().increment(p.id, d)
                                db.products().insertMovement(StockMovement(productId = p.id, type = "AJUSTEMENT", quantityDelta = d, note = note.trim()))
                            }
                            showAdjust = false
                        }
                    }
                }) { Text("Valider") }
            },
            dismissButton = { TextButton({ showAdjust = false }) { Text("Annuler") } }
        )
    }
    if (showUnit) PhoneUnitDialog(app, p) { showUnit = false }
}

@Composable
fun PhoneUnitDialog(app: DidiApp, product: Product, onClose: () -> Unit) {
    val db = app.db
    val scope = rememberCoroutineScope()
    var imei1 by remember { mutableStateOf("") }
    var imei2 by remember { mutableStateOf("") }
    var serial by remember { mutableStateOf("") }
    var color by remember { mutableStateOf("") }
    var storage by remember { mutableStateOf("") }
    var ram by remember { mutableStateOf("") }
    var condition by remember { mutableStateOf(product.condition) }
    var cost by remember { mutableStateOf(fmt(product.costPrice)) }
    var price by remember { mutableStateOf(fmt(product.salePrice)) }
    var warranty by remember { mutableStateOf(product.warrantyMonths.toString()) }
    var error by remember { mutableStateOf<String?>(null) }
    var luhnWarned by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Nouveau téléphone : ${product.name}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                IntField(imei1, "IMEI 1 (15 chiffres)", { imei1 = it.filter(Char::isDigit).take(15); luhnWarned = false })
                IntField(imei2, "IMEI 2 (facultatif)", { imei2 = it.filter(Char::isDigit).take(15) })
                TextField1(serial, "Numéro de série (facultatif)", { serial = it })
                TextField1(color, "Couleur", { color = it })
                TextField1(storage, "Stockage (ex. 128 Go)", { storage = it })
                TextField1(ram, "RAM (ex. 6 Go)", { ram = it })
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("NEUF", "OCCASION", "RECONDITIONNE").forEach { c -> FilterChip(condition == c, { condition = c }, { Text(c.lowercase().replaceFirstChar { it.uppercase() }) }) }
                }
                MoneyField(cost, "Prix d'achat", { cost = it })
                MoneyField(price, "Prix de vente", { price = it })
                IntField(warranty, "Garantie (mois)", { warranty = it })
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton({
                val c = FinanceCalculator.parseToMinor(cost)
                val s = FinanceCalculator.parseToMinor(price)
                val w = warranty.ifBlank { "0" }.toIntOrNull()
                when {
                    imei1.length != 15 -> error = "L'IMEI 1 doit contenir 15 chiffres."
                    imei2.isNotEmpty() && imei2.length != 15 -> error = "L'IMEI 2 doit contenir 15 chiffres."
                    imei2.isNotEmpty() && imei2 == imei1 -> error = "Les deux IMEI sont identiques."
                    c == null || s == null || c < 0 || s < 0 -> error = "Prix invalide."
                    w == null || w < 0 -> error = "Garantie invalide."
                    !FinanceCalculator.isValidImei(imei1) && !luhnWarned -> {
                        luhnWarned = true
                        error = "Cet IMEI ne passe pas le contrôle de validité. Vérifiez-le, ou touchez de nouveau Enregistrer pour confirmer."
                    }
                    else -> scope.launch {
                        val dup = db.phoneUnits().findByImei(imei1) ?: if (imei2.isNotEmpty()) db.phoneUnits().findByImei(imei2) else null
                        if (dup != null) { error = "Cet IMEI est déjà enregistré (statut ${dup.status})."; return@launch }
                        try {
                            db.withTransaction {
                                val id = db.phoneUnits().insert(
                                    PhoneUnit(
                                        productId = product.id, imei1 = imei1, imei2 = imei2.ifBlank { null },
                                        serial = serial.trim().ifBlank { null }, color = color.trim(), storage = storage.trim(),
                                        ram = ram.trim(), condition = condition, costPrice = c!!, salePrice = s!!,
                                        supplierId = product.supplierId, warrantyMonths = w!!
                                    )
                                )
                                db.products().insertMovement(StockMovement(productId = product.id, phoneUnitId = id, type = "ENTREE", quantityDelta = 1, note = "IMEI $imei1"))
                            }
                            onClose()
                        } catch (e: android.database.sqlite.SQLiteConstraintException) {
                            error = "Cet IMEI est déjà enregistré."
                        }
                    }
                }
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClose) { Text("Annuler") } }
    )
}
