package com.didi.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.room.withTransaction
import com.didi.app.data.RepairCase
import com.didi.app.data.RepairEvent
import com.didi.app.data.RepairStatus
import com.didi.app.domain.FinanceCalculator
import com.didi.app.domain.addMonths
import com.didi.app.domain.formatDate
import com.didi.app.domain.formatDateTime
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RepairsScreen(app: DidiApp) {
    val db = app.db
    val repairs by remember(db) { db.repairs().observeAll() }.collectAsState(emptyList())
    var query by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("all") }
    var showForm by remember { mutableStateOf(false) }
    var selectedId by remember { mutableStateOf<Long?>(null) }

    val shown = repairs.filter { r ->
        (status == "all" || r.status == status) &&
            (query.isBlank() || r.number.contains(query, true) || r.customerName.contains(query, true) ||
                r.imei.contains(query) || r.productLabel.contains(query, true) || r.customerPhone.contains(query))
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            TextField1(query, "Rechercher (n°, client, IMEI, appareil)", { query = it }, Modifier.fillMaxWidth().padding(vertical = 6.dp))
            ChipRow(listOf("all" to "Toutes") + RepairStatus.ALL.map { it to it }, status) { status = it }
            Text("${shown.size} dossier(s)", Modifier.padding(vertical = 4.dp))
            if (repairs.isEmpty()) Text("Aucune réparation enregistrée. Touchez + pour recevoir un appareil.")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.id }) { r ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${r.number} · ${r.productLabel.ifBlank { "Appareil" }}", style = MaterialTheme.typography.titleSmall)
                                Text("${r.customerName.ifBlank { "Client non précisé" }} · ${r.status}" + if (r.underWarranty) " · sous garantie" else "")
                                Text(r.problem, style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton({ selectedId = r.id }) { Text("Ouvrir") }
                        }
                    }
                }
                item { Box(Modifier.heightIn(min = 80.dp)) }
            }
        }
        FloatingActionButton({ showForm = true }, Modifier.align(Alignment.BottomEnd).padding(16.dp)) { Text("+") }
    }

    if (showForm) RepairFormDialog(app) { showForm = false }
    selectedId?.let { id ->
        val r = repairs.firstOrNull { it.id == id }
        if (r != null) RepairDetailDialog(app, r) { selectedId = null }
    }
}

@Composable
private fun RepairFormDialog(app: DidiApp, onClose: () -> Unit) {
    val db = app.db
    val scope = rememberCoroutineScope()
    val cur by rememberMainCurrency(app)
    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var label by remember { mutableStateOf("") }
    var imei by remember { mutableStateOf("") }
    var problem by remember { mutableStateOf("") }
    var condition by remember { mutableStateOf("") }
    var estimate by remember { mutableStateOf("") }
    var technician by remember { mutableStateOf("") }
    var warrantyInfo by remember { mutableStateOf<String?>(null) }
    var underWarranty by remember { mutableStateOf(false) }
    var soldAt by remember { mutableStateOf<Long?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    FormDialog(
        title = "Recevoir un appareil", error = error, onDismiss = onClose, confirmLabel = "Créer le dossier",
        onConfirm = {
            val est = if (estimate.isBlank()) 0L else FinanceCalculator.parseToMinor(estimate)
            when {
                problem.isBlank() -> error = "Décrivez la panne."
                label.isBlank() && imei.isBlank() -> error = "Indiquez l'appareil ou son IMEI."
                est == null || est < 0 -> error = "Devis invalide."
                else -> scope.launch {
                    db.withTransaction {
                        val seq = db.repairs().count() + 1
                        val number = "R" + SimpleDateFormat("yyMMdd", Locale.US).format(Date()) + "-" + seq.toString().padStart(3, '0')
                        val id = db.repairs().insert(
                            RepairCase(
                                number = number, customerName = customerName.trim(), customerPhone = customerPhone.trim(),
                                productLabel = label.trim(), imei = imei.trim(), soldAt = soldAt, problem = problem.trim(),
                                itemCondition = condition.trim(), estimatedCost = est, technician = technician.trim(),
                                underWarranty = underWarranty
                            )
                        )
                        db.repairs().insertEvent(RepairEvent(repairId = id, status = RepairStatus.RECEIVED, note = "Appareil reçu"))
                    }
                    onClose()
                }
            }
        }
    ) {
        TextField1(customerName, "Nom du client", { customerName = it })
        TextField1(customerPhone, "Téléphone du client", { customerPhone = it })
        TextField1(imei, "IMEI (vérifie la garantie)", { imei = it; warrantyInfo = null })
        OutlinedButton({
            scope.launch {
                val unit = db.phoneUnits().findByImei(imei.trim())
                if (unit == null) {
                    warrantyInfo = "IMEI inconnu : appareil non vendu par la boutique ou non enregistré."
                    underWarranty = false; soldAt = null
                } else {
                    val sale = db.sales().saleOfUnit(unit.id)
                    if (label.isBlank()) label = db.products().get(unit.productId)?.name.orEmpty()
                    if (sale == null) {
                        warrantyInfo = "Appareil connu, mais pas vendu : pas de garantie à vérifier."
                        underWarranty = false; soldAt = null
                    } else {
                        soldAt = sale.createdAt
                        val end = addMonths(sale.createdAt, unit.warrantyMonths)
                        underWarranty = unit.warrantyMonths > 0 && System.currentTimeMillis() <= end
                        warrantyInfo = when {
                            unit.warrantyMonths <= 0 -> "Vendu le ${formatDate(sale.createdAt)} sans garantie."
                            underWarranty -> "Sous garantie jusqu'au ${formatDate(end)}."
                            else -> "Garantie expirée depuis le ${formatDate(end)}."
                        }
                    }
                }
            }
        }) { Text("Vérifier la garantie") }
        warrantyInfo?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        TextField1(label, "Appareil (marque, modèle)", { label = it })
        TextField1(problem, "Panne signalée", { problem = it })
        TextField1(condition, "État à la réception (rayures, accessoires…)", { condition = it })
        MoneyField(estimate, "Devis estimé ($cur, facultatif)", { estimate = it })
        TextField1(technician, "Technicien (facultatif)", { technician = it })
    }
}

@Composable
private fun RepairDetailDialog(app: DidiApp, repair: RepairCase, onClose: () -> Unit) {
    val db = app.db
    val scope = rememberCoroutineScope()
    val cur by rememberMainCurrency(app)
    val events by produceState(emptyList<RepairEvent>(), repair.id, repair.status, repair.finalCost) { value = db.repairs().eventsOf(repair.id) }
    var target by remember { mutableStateOf<String?>(null) }
    var note by remember { mutableStateOf("") }
    var diagnosis by remember(repair.id) { mutableStateOf(repair.diagnosis) }
    var finalCost by remember(repair.id) { mutableStateOf(if (repair.finalCost > 0) fmt(repair.finalCost) else "") }
    var error by remember { mutableStateOf<String?>(null) }

    InfoDialog("${repair.number} · ${repair.status}", onClose) {
        Text(
            listOfNotNull(
                "Client : ${repair.customerName.ifBlank { "-" }} ${repair.customerPhone}".trim(),
                "Appareil : ${repair.productLabel.ifBlank { "-" }}" + if (repair.imei.isNotBlank()) " · IMEI ${repair.imei}" else "",
                "Reçu le ${formatDate(repair.receivedAt)}" + (repair.returnedAt?.let { " · restitué le ${formatDate(it)}" } ?: ""),
                "Panne : ${repair.problem}",
                repair.itemCondition.takeIf { it.isNotBlank() }?.let { "État : $it" },
                if (repair.underWarranty) "Sous garantie" else "Hors garantie",
                "Devis : ${fmt(repair.estimatedCost)} $cur · Coût final : ${fmt(repair.finalCost)} $cur",
                repair.technician.takeIf { it.isNotBlank() }?.let { "Technicien : $it" }
            ).joinToString("\n")
        )
        TextField1(diagnosis, "Diagnostic", { diagnosis = it })
        MoneyField(finalCost, "Coût final ($cur)", { finalCost = it })
        OutlinedButton({
            val fc = if (finalCost.isBlank()) 0L else FinanceCalculator.parseToMinor(finalCost)
            if (fc == null || fc < 0) error = "Coût final invalide."
            else scope.launch {
                db.repairs().update(repair.copy(diagnosis = diagnosis.trim(), finalCost = fc))
                error = null
            }
        }) { Text("Enregistrer diagnostic et coût") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        if (repair.status != RepairStatus.RETURNED) {
            Text("Changer l'état", style = MaterialTheme.typography.titleSmall)
            ChipRow(RepairStatus.ALL.filter { it != repair.status }.map { it to it }, target) { target = it }
            if (target != null) {
                TextField1(note, "Note (facultatif)", { note = it })
                Button1("Valider « $target »") {
                    val t = target ?: return@Button1
                    val ok = t != RepairStatus.RETURNED ||
                        repair.status == RepairStatus.REPAIRED || repair.status == RepairStatus.UNREPAIRABLE
                    if (!ok) {
                        error = "Un appareil ne peut être restitué qu'après « Réparé » ou « Non réparable »."
                    } else scope.launch {
                        db.withTransaction {
                            db.repairs().update(
                                repair.copy(
                                    status = t, diagnosis = diagnosis.trim(),
                                    returnedAt = if (t == RepairStatus.RETURNED) System.currentTimeMillis() else repair.returnedAt
                                )
                            )
                            db.repairs().insertEvent(RepairEvent(repairId = repair.id, status = t, note = note.trim()))
                        }
                        target = null; note = ""; error = null
                    }
                }
            }
        }
        Text("Historique", style = MaterialTheme.typography.titleSmall)
        events.forEach { Text("${formatDateTime(it.createdAt)} · ${it.status}" + if (it.note.isNotBlank()) " — ${it.note}" else "") }
    }
}

@Composable
private fun Button1(label: String, onClick: () -> Unit) {
    androidx.compose.material3.Button(onClick) { Text(label) }
}
