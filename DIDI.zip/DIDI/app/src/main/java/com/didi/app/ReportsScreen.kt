package com.didi.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.didi.app.data.UnitStatus
import com.didi.app.domain.CsvExport
import com.didi.app.domain.PayMethods
import com.didi.app.domain.PdfText
import com.didi.app.domain.ReceiptPdf
import com.didi.app.domain.Summary
import com.didi.app.domain.formatDate
import com.didi.app.domain.summaryFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

private val TABS = listOf("resume" to "Résumé", "produits" to "Produits", "vendeurs" to "Vendeurs", "stock" to "Stock")

@Composable
fun ReportsScreen(app: DidiApp) {
    val db = app.db
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val cur by rememberMainCurrency(app)
    var range by remember { mutableStateOf(DateRange.presets()[2]) }
    var tab by remember { mutableStateOf("resume") }
    var filter by remember { mutableStateOf("") }
    val csv = rememberFileSaver("text/csv")

    val summary by remember(range) { summaryFlow(db, range.from, range.to) }
        .collectAsState(Summary(0, 0, 0, 0, 0, 0, 0, 0))
    val receivables by remember(db) { db.reports().receivables() }.collectAsState(0L)
    val supplierDebts by remember(db) { db.reports().supplierDebts() }.collectAsState(0L)
    val stockValue by remember(db) { db.products().observeStockValue() }.collectAsState(0L)
    val methodTotals by remember(range) {
        combine(PayMethods.ALL.map { m -> db.reports().cashByMethod(m.first, range.from, range.to) }) { it.toList() }
    }.collectAsState(emptyList())
    val sold by remember(range) { db.reports().productsSold(range.from, range.to) }.collectAsState(emptyList())
    val sales by remember(range) { db.sales().observeBetween(range.from, range.to) }.collectAsState(emptyList())
    val products by remember(db) { db.products().observeActive() }.collectAsState(emptyList())
    val units by remember(db) { db.phoneUnits().observeAll() }.collectAsState(emptyList())
    val unitCounts by remember(db) { db.products().observeUnitCounts() }.collectAsState(emptyList())
    val categories by remember(db) { db.categories().observeAll() }.collectAsState(emptyList())
    val catNames = categories.associate { it.id to it.name }
    val counts = unitCounts.associate { it.productId to it.n }

    val validSales = sales.filter { it.status == "VALIDEE" }
    val sellers = validSales.groupBy { it.sellerName.ifBlank { "(non renseigné)" } }
        .map { (name, list) -> Triple(name, list.size, list.sumOf { it.total - it.returnedAmount }) }
        .sortedByDescending { it.third }
    val shownSold = sold.filter { filter.isBlank() || it.productName.contains(filter, true) }
    val stockRows = products.filter { filter.isBlank() || it.name.contains(filter, true) || (catNames[it.categoryId] ?: "").contains(filter, true) }
        .map { p -> p to (if (p.tracksImei) counts[p.id] ?: 0 else p.stockQty) }

    fun reportLines(): List<String> = buildList {
        add("Période : ${formatDate(range.from)} au ${formatDate(range.to)}")
        add("Chiffre d'affaires net : ${fmt(summary.revenue)} $cur (ventes: ${summary.salesCount}, retours: ${fmt(summary.returns)})")
        add("Coût des marchandises vendues : ${fmt(summary.cogs)} $cur")
        add("Bénéfice brut : ${fmt(summary.gross)} $cur")
        add("Dépenses : ${fmt(summary.expenses)} $cur")
        add("Bénéfice net estimé : ${fmt(summary.net)} $cur")
        add("Trésorerie encaissée (paiements - remboursements) : ${fmt(summary.cash)} $cur")
        add("Créances clients (à ce jour) : ${fmt(receivables)} $cur")
        add("Dettes fournisseurs (à ce jour) : ${fmt(supplierDebts)} $cur")
        add("Valeur du stock au prix d'achat : ${fmt(stockValue)} $cur")
        add("")
        add("Encaissements par mode :")
        PayMethods.ALL.forEachIndexed { i, m -> add("  ${m.second} : ${fmt(methodTotals.getOrElse(i) { 0L })} $cur") }
        add("")
        add("Produits vendus :")
        sold.forEach { add("  ${it.productName} : ${it.qty} pièce(s), ${fmt(it.revenue)} $cur") }
        add("")
        add("Ventes par vendeur :")
        sellers.forEach { add("  ${it.first} : ${it.second} vente(s), ${fmt(it.third)} $cur") }
    }

    Column(Modifier.padding(horizontal = 12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        RangePicker(range) { range = it }
        ChipRow(TABS, tab) { tab = it }
        when (tab) {
            "resume" -> {
                InfoCard(
                    "Résultats de la période ($cur)",
                    listOf(
                        "Chiffre d'affaires net : ${fmt(summary.revenue)}",
                        "Coût des marchandises vendues : ${fmt(summary.cogs)}",
                        "Bénéfice brut : ${fmt(summary.gross)}",
                        "Dépenses : ${fmt(summary.expenses)}",
                        "Bénéfice net estimé : ${fmt(summary.net)}",
                        "Nombre de ventes : ${summary.salesCount} · Retours : ${fmt(summary.returns)}"
                    )
                )
                InfoCard(
                    "Trésorerie et dettes ($cur)",
                    listOf("Encaissé sur la période : ${fmt(summary.cash)}") +
                        PayMethods.ALL.mapIndexed { i, m -> "  ${m.second} : ${fmt(methodTotals.getOrElse(i) { 0L })}" } +
                        listOf("Créances clients (total actuel) : ${fmt(receivables)}", "Dettes fournisseurs (total actuel) : ${fmt(supplierDebts)}")
                )
                Text(
                    "Le chiffre d'affaires n'est pas la trésorerie : une vente à crédit compte dans le chiffre d'affaires mais pas dans l'argent encaissé. Les achats de marchandises ne sont pas des dépenses : ils passent par le coût des marchandises vendues.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            "produits" -> {
                TextField1(filter, "Filtrer par nom", { filter = it }, Modifier.fillMaxWidth())
                if (shownSold.isEmpty()) Text("Aucune vente de produit sur cette période.")
                shownSold.forEachIndexed { i, p ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${i + 1}. ${p.productName}", Modifier.weight(1f))
                            Text("${p.qty} pc · ${fmt(p.revenue)} $cur")
                        }
                    }
                }
                if (sold.size > 1) Text("Moins vendu : ${sold.last().productName} (${sold.last().qty} pc)", style = MaterialTheme.typography.bodySmall)
            }
            "vendeurs" -> {
                if (sellers.isEmpty()) Text("Aucune vente sur cette période.")
                sellers.forEach { s ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(s.first, Modifier.weight(1f))
                            Text("${s.second} vente(s) · ${fmt(s.third)} $cur")
                        }
                    }
                }
            }
            "stock" -> {
                TextField1(filter, "Filtrer par produit ou catégorie", { filter = it }, Modifier.fillMaxWidth())
                Text("Valeur totale du stock au prix d'achat : ${fmt(stockValue)} $cur", style = MaterialTheme.typography.titleSmall)
                stockRows.forEach { (p, q) ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name)
                                Text(catNames[p.categoryId] ?: "", style = MaterialTheme.typography.bodySmall)
                            }
                            val low = !p.tracksImei && q <= p.minStock
                            Text("Stock : $q" + if (q <= 0) " (rupture)" else if (low) " (bas)" else "")
                        }
                    }
                }
                Text("${units.count { it.status == UnitStatus.IN_STOCK }} téléphone(s) à IMEI en stock.", style = MaterialTheme.typography.bodySmall)
            }
        }
        Text("Exports", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ scope.launch { csv("didi-ventes.csv", CsvExport.sales(db, range.from, range.to)) } }) { Text("Ventes CSV") }
            OutlinedButton({ scope.launch { csv("didi-stock.csv", CsvExport.products(db)) } }) { Text("Stock CSV") }
        }
        OutlinedButton({
            scope.launch {
                val f = PdfText.create(context, "rapport-didi.pdf", "Rapport DIDI", reportLines())
                ReceiptPdf.share(context, f)
            }
        }) { Text("Rapport PDF (partager)") }
        Column(Modifier.padding(bottom = 24.dp)) {}
    }
}
