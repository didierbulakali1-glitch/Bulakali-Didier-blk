package com.didi.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.didi.app.data.Payment
import com.didi.app.data.Sale
import com.didi.app.data.SaleItem
import com.didi.app.data.SaleReturn
import com.didi.app.data.SaleStatus
import com.didi.app.domain.FinanceCalculator
import com.didi.app.domain.ReceiptPdf
import com.didi.app.domain.ReturnLine
import com.didi.app.domain.SaleException
import com.didi.app.domain.Session
import com.didi.app.domain.formatDate
import com.didi.app.domain.formatDateTime
import kotlinx.coroutines.launch

@Composable
fun SalesScreen(app: DidiApp) {
    val db = app.db
    val cur by rememberMainCurrency(app)
    var range by remember { mutableStateOf(DateRange.presets()[2]) }
    var query by remember { mutableStateOf("") }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    val customers by remember(db) { db.customers().observeAll() }.collectAsState(emptyList())
    val names = customers.associate { it.id to it.fullName }

    selectedId?.let { id ->
        SaleDetail(app, id, names) { selectedId = null }
        return
    }

    val sales by remember(range) { db.sales().observeBetween(range.from, range.to) }.collectAsState(emptyList())
    val shown = sales.filter { s ->
        query.isBlank() || s.number.contains(query, true) || s.sellerName.contains(query, true) ||
            (names[s.customerId]?.contains(query, true) == true) || methodLabel(s.paymentMethod).contains(query, true)
    }
    val valid = shown.filter { it.status == SaleStatus.VALIDATED }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        RangePicker(range) { range = it }
        TextField1(query, "Rechercher (n°, client, vendeur, mode de paiement)", { query = it }, Modifier.fillMaxWidth().padding(vertical = 6.dp))
        Text("${valid.size} vente(s) validée(s) · ${fmt(valid.sumOf { it.total - it.returnedAmount })} $cur net")
        if (shown.isEmpty()) Text("Aucune vente sur cette période.", Modifier.padding(vertical = 12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(shown, key = { it.id }) { s ->
                val owed = FinanceCalculator.balance(s.total - s.returnedAmount, s.paidAmount)
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("${s.number} · ${formatDateTime(s.createdAt)}", style = MaterialTheme.typography.titleSmall)
                            Text(
                                (names[s.customerId] ?: "Sans client") + " · ${fmt(s.total)} ${s.currency}" +
                                    (if (s.status != SaleStatus.VALIDATED) " · ANNULÉE" else "") +
                                    (if (s.status == SaleStatus.VALIDATED && owed > 0) " · reste ${fmt(owed)}" else "") +
                                    (if (s.returnedAmount > 0) " · retours ${fmt(s.returnedAmount)}" else "")
                            )
                        }
                        TextButton({ selectedId = s.id }) { Text("Détail") }
                    }
                }
            }
        }
    }
}

@Composable
private fun SaleDetail(app: DidiApp, id: Long, names: Map<Long, String>, onBack: () -> Unit) {
    val db = app.db
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    BackHandler(onBack = onBack)

    val sale by remember(id) { db.sales().observe(id) }.collectAsState(null)
    val s = sale ?: run {
        Text("Vente introuvable.", Modifier.padding(16.dp))
        return
    }
    val saleItems by produceState(emptyList<SaleItem>(), id) { value = db.sales().itemsOf(id) }
    val payments by produceState(emptyList<Payment>(), s.paidAmount, s.returnedAmount, s.status) { value = db.sales().paymentsOfSale(id) }
    val returns by produceState(emptyList<SaleReturn>(), s.returnedAmount, s.status) { value = db.returns().ofSale(id) }

    var msg by remember { mutableStateOf<String?>(null) }
    var showPay by remember { mutableStateOf(false) }
    var showReturn by remember { mutableStateOf(false) }
    var showCancel by remember { mutableStateOf(false) }

    val cur = s.currency
    val valid = s.status == SaleStatus.VALIDATED
    val owed = FinanceCalculator.balance(s.total - s.returnedAmount, s.paidAmount)
    val recovered = returns.sumOf { it.costRecovered }
    val gross = (s.total - s.returnedAmount) - (s.costTotal - recovered)

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { TextButton(onBack) { Text("← Retour à l'historique") } }
        item { Text("Vente ${s.number}" + if (!valid) " (annulée)" else "", style = MaterialTheme.typography.titleLarge) }
        msg?.let { m -> item { Text(m, color = MaterialTheme.colorScheme.primary) } }
        item {
            InfoCard(
                "Détails",
                listOfNotNull(
                    "Date : ${formatDateTime(s.createdAt)}",
                    names[s.customerId]?.let { "Client : $it" },
                    if (s.sellerName.isNotBlank()) "Vendeur : ${s.sellerName}" else null,
                    "Mode de paiement : ${methodLabel(s.paymentMethod)}",
                    "Sous-total : ${fmt(s.subtotal)} · Remises : ${fmt(s.discountTotal)}",
                    "Total : ${fmt(s.total)} $cur",
                    if (s.returnedAmount > 0) "Retours : ${fmt(s.returnedAmount)} $cur" else null,
                    "Payé (net) : ${fmt(s.paidAmount)} $cur · Solde : ${fmt(owed)} $cur",
                    s.dueDate?.let { "Échéance : ${formatDate(it)}" },
                    if (valid) "Bénéfice brut estimé : ${fmt(gross)} $cur" else null,
                    s.cancelledAt?.let { "Annulée le ${formatDateTime(it)} : ${s.cancelReason}" },
                    if (s.note.isNotBlank()) "Note : ${s.note}" else null
                )
            )
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton({ scope.launch { ReceiptPdf.share(context, ReceiptPdf.create(context, db, s)) } }) { Text("Reçu PDF / partager") }
                OutlinedButton({ scope.launch { ReceiptPdf.print(context, ReceiptPdf.create(context, db, s)) } }) { Text("Imprimer") }
                if (valid && owed > 0) Button({ showPay = true }) { Text("Encaisser") }
                if (valid && Session.can("sensitive")) {
                    OutlinedButton({ showReturn = true }) { Text("Retour d'articles") }
                    if (s.returnedAmount == 0L) TextButton({ showCancel = true }) { Text("Annuler la vente") }
                }
            }
        }
        item { Text("Articles", style = MaterialTheme.typography.titleMedium) }
        items(saleItems, key = { "i${it.id}" }) { it ->
            Text(
                "${it.productName} x${it.quantity} · ${fmt(it.unitPrice)}" +
                    (if (it.discount > 0) " · remise ${fmt(it.discount)}" else "") +
                    (if (!it.imei.isNullOrBlank()) " · IMEI ${it.imei}" else "") + " = ${fmt(it.lineTotal)}"
            )
        }
        item { Text("Paiements", style = MaterialTheme.typography.titleMedium) }
        if (payments.isEmpty()) item { Text("Aucun paiement enregistré.") }
        items(payments, key = { "p${it.id}" }) { p ->
            Text(
                "${formatDateTime(p.createdAt)} · ${methodLabel(p.method)} · ${fmt(p.amountInMain)} $cur" +
                    (if (p.currency != cur) " (reçu ${fmt(p.amountReceived)} ${p.currency})" else "") +
                    (if (p.amountInMain < 0) " · remboursement" else "") +
                    (if (p.reference.isNotBlank()) " · ${p.reference}" else "")
            )
        }
        if (returns.isNotEmpty()) {
            item { Text("Retours", style = MaterialTheme.typography.titleMedium) }
            items(returns, key = { "r${it.id}" }) { r ->
                Text("${formatDateTime(r.createdAt)} · valeur ${fmt(r.amount)} · dette réduite ${fmt(r.creditReduction)} · remboursé ${fmt(r.refundAmount)} · ${r.reason}")
            }
        }
    }

    if (showPay) PayDialog("Encaisser sur ${s.number}", owed, cur, { showPay = false }) { amount, method, ref ->
        app.saleService.payDebt(s.id, s.customerId, amount, method, ref)
        msg = "Paiement de ${fmt(amount)} $cur enregistré."
    }
    if (showReturn) ReturnDialog(app, s, saleItems) { result -> showReturn = false; if (result != null) msg = result }
    if (showCancel) CancelDialog(app, s) { result -> showCancel = false; if (result != null) msg = result }
}

@Composable
private fun ReturnDialog(app: DidiApp, sale: Sale, items: List<SaleItem>, onClose: (String?) -> Unit) {
    val db = app.db
    val scope = rememberCoroutineScope()
    val remaining by produceState(emptyMap<Long, Int>(), items) {
        value = items.associate { it.id to (it.quantity - db.returns().returnedQty(it.id)) }
    }
    val qty = remember { mutableStateMapOf<Long, String>() }
    val restock = remember { mutableStateMapOf<Long, Boolean>() }
    var reason by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("ESPECES") }
    var error by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf(false) }

    fun lines(): List<ReturnLine> = items.mapNotNull { item ->
        val q = qty[item.id]?.toIntOrNull() ?: 0
        if (q > 0) ReturnLine(item.id, q, restock[item.id] ?: true) else null
    }

    FormDialog(
        title = "Retour d'articles", confirmLabel = "Continuer", error = error,
        onDismiss = { onClose(null) },
        onConfirm = {
            when {
                lines().isEmpty() -> error = "Saisissez une quantité à retourner."
                reason.isBlank() -> error = "Indiquez la raison du retour."
                else -> { error = null; confirm = true }
            }
        }
    ) {
        items.forEach { item ->
            val rem = remaining[item.id] ?: 0
            if (rem > 0) {
                Text(item.productName + (if (!item.imei.isNullOrBlank()) " (IMEI ${item.imei})" else "") + " : $rem retournable(s)")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IntField(qty[item.id] ?: "", "Quantité", { v -> qty[item.id] = v.filter(Char::isDigit) }, Modifier.weight(1f))
                    FilterChip(restock[item.id] ?: true, { restock[item.id] = !(restock[item.id] ?: true) }, { Text("Remettre en stock") })
                }
            }
        }
        TextField1(reason, "Raison du retour", { reason = it })
        Text("Remboursement en argent (si la valeur retournée dépasse la dette)")
        ChipRow(PAY_METHODS, method) { method = it }
        Text("Un article défectueux ne doit pas revenir en stock vendable : décochez « Remettre en stock ».", style = MaterialTheme.typography.bodySmall)
    }
    if (confirm) ConfirmDialog(
        "Confirmer le retour",
        "Enregistrer le retour de ${lines().sumOf { it.quantity }} article(s) ? Le stock, la dette et les chiffres seront mis à jour.",
        "Confirmer",
        {
            scope.launch {
                try {
                    val r = app.afterSale.returnItems(sale.id, lines(), reason.trim(), method, Session.name())
                    onClose("Retour enregistré : valeur ${fmt(r.amount)}, dette réduite de ${fmt(r.creditReduction)}, remboursé ${fmt(r.refundAmount)}.")
                } catch (e: SaleException) {
                    error = e.message; confirm = false
                } catch (e: Exception) {
                    error = "Erreur inattendue : ${e.message}"; confirm = false
                }
            }
        },
        { confirm = false }
    )
}

@Composable
private fun CancelDialog(app: DidiApp, sale: Sale, onClose: (String?) -> Unit) {
    val scope = rememberCoroutineScope()
    var reason by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("ESPECES") }
    var error by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf(false) }
    FormDialog(
        title = "Annuler la vente ${sale.number}", confirmLabel = "Continuer", error = error,
        onDismiss = { onClose(null) },
        onConfirm = { if (reason.isBlank()) error = "Indiquez la raison de l'annulation." else { error = null; confirm = true } }
    ) {
        Text("Le stock sera remis, l'argent déjà encaissé (${fmt(sale.paidAmount)} ${sale.currency}) sera remboursé. La vente reste visible dans l'historique.")
        TextField1(reason, "Raison", { reason = it })
        if (sale.paidAmount > 0) { Text("Mode de remboursement"); ChipRow(PAY_METHODS, method) { method = it } }
    }
    if (confirm) ConfirmDialog(
        "Annuler définitivement cette vente ?", "Cette opération ne peut pas être défaite.", "Annuler la vente",
        {
            scope.launch {
                try {
                    app.afterSale.cancelSale(sale.id, reason.trim(), method)
                    onClose("Vente annulée.")
                } catch (e: SaleException) {
                    error = e.message; confirm = false
                } catch (e: Exception) {
                    error = "Erreur inattendue : ${e.message}"; confirm = false
                }
            }
        },
        { confirm = false }
    )
}
