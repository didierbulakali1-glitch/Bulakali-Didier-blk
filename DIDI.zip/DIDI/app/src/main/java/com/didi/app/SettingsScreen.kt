package com.didi.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.didi.app.data.AppSetting
import com.didi.app.data.SettingKeys
import com.didi.app.domain.FinanceCalculator
import com.didi.app.domain.Session
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(app: DidiApp) {
    val db = app.db
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var footer by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf("USD") }
    var rate by remember { mutableStateOf("") }
    var allowNegative by remember { mutableStateOf(false) }
    var theme by remember { mutableStateOf("auto") }
    var accent by remember { mutableStateOf("or") }
    var vendorMax by remember { mutableStateOf("") }
    var logo by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) copyIntoApp(context, uri, "logo")?.let { logo = it }
    }

    LaunchedEffect(Unit) {
        name = db.settings().get(SettingKeys.SHOP_NAME).orEmpty()
        phone = db.settings().get(SettingKeys.SHOP_PHONE).orEmpty()
        address = db.settings().get(SettingKeys.SHOP_ADDRESS).orEmpty()
        footer = db.settings().get(SettingKeys.RECEIPT_TEXT).orEmpty()
        currency = db.settings().get(SettingKeys.MAIN_CURRENCY) ?: "USD"
        rate = db.settings().get(SettingKeys.RATE_CDF_PER_USD)?.toLongOrNull()?.let { FinanceCalculator.formatMinor(it) }.orEmpty()
        allowNegative = db.settings().get(SettingKeys.ALLOW_NEGATIVE_STOCK) == "true"
        theme = db.settings().get(SettingKeys.DARK_THEME) ?: "auto"
        accent = db.settings().get(SettingKeys.ACCENT) ?: "or"
        vendorMax = db.settings().get(SettingKeys.VENDOR_MAX_DISCOUNT).orEmpty()
        logo = db.settings().get(SettingKeys.LOGO)?.ifBlank { null }
    }

    Column(
        Modifier.padding(12.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Paramètres du commerce", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(name, { name = it }, label = { Text("Nom de la boutique") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(phone, { phone = it }, label = { Text("Téléphone") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(address, { address = it }, label = { Text("Adresse") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(footer, { footer = it }, label = { Text("Message sur les reçus") }, modifier = Modifier.fillMaxWidth())

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Thumbnail(logo, 56)
            OutlinedButton({ logoPicker.launch("image/*") }) { Text(if (logo == null) "Choisir un logo" else "Changer le logo") }
            if (logo != null) OutlinedButton({ logo = null }) { Text("Retirer") }
        }

        Text("Devise principale")
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("USD", "CDF").forEach { c -> FilterChip(currency == c, { currency = c }, { Text(c) }) }
        }
        Text("Changer la devise principale n'altère pas l'historique : chaque vente garde sa devise d'origine.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(
            rate, { rate = it },
            label = { Text("Taux de change : combien de CDF pour 1 USD (à saisir vous-même)") },
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(allowNegative, { allowNegative = !allowNegative }, { Text("Autoriser la vente sans stock") })
        }
        OutlinedTextField(
            vendorMax, { vendorMax = it.filter(Char::isDigit).take(3) },
            label = { Text("Remise maximale des vendeurs, en % (vide = pas de limite)") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )

        Text("Apparence")
        ChipRow(listOf("auto" to "Automatique", "light" to "Clair", "dark" to "Sombre"), theme) { theme = it }
        ChipRow(listOf("or" to "Or", "vert" to "Vert", "rouge" to "Rouge"), accent) { accent = it }

        message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        Button(
            onClick = {
                if (!Session.can("settings")) { message = "Vous n'avez pas le droit de modifier les réglages."; return@Button }
                val r = if (rate.isBlank()) null else FinanceCalculator.parseToMinor(rate)
                val vm = if (vendorMax.isBlank()) null else vendorMax.toIntOrNull()
                if (rate.isNotBlank() && (r == null || r <= 0)) { message = "Taux invalide."; return@Button }
                if (vm != null && vm > 100) { message = "La remise maximale ne peut pas dépasser 100 %."; return@Button }
                if (name.isBlank()) { message = "Le nom de la boutique est obligatoire."; return@Button }
                scope.launch {
                    val s = db.settings()
                    s.put(AppSetting(SettingKeys.SHOP_NAME, name.trim()))
                    s.put(AppSetting(SettingKeys.SHOP_PHONE, phone.trim()))
                    s.put(AppSetting(SettingKeys.SHOP_ADDRESS, address.trim()))
                    s.put(AppSetting(SettingKeys.RECEIPT_TEXT, footer.trim()))
                    s.put(AppSetting(SettingKeys.MAIN_CURRENCY, currency))
                    if (r != null) s.put(AppSetting(SettingKeys.RATE_CDF_PER_USD, r.toString()))
                    s.put(AppSetting(SettingKeys.ALLOW_NEGATIVE_STOCK, allowNegative.toString()))
                    s.put(AppSetting(SettingKeys.VENDOR_MAX_DISCOUNT, vm?.toString() ?: "100"))
                    s.put(AppSetting(SettingKeys.DARK_THEME, theme))
                    s.put(AppSetting(SettingKeys.ACCENT, accent))
                    s.put(AppSetting(SettingKeys.LOGO, logo.orEmpty()))
                    message = "Paramètres enregistrés."
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Enregistrer") }
    }
}
