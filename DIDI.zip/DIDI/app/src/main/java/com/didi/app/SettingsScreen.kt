package com.didi.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.didi.app.data.AppSetting
import com.didi.app.data.SettingKeys
import com.didi.app.domain.FinanceCalculator
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(app: DidiApp) {
    val db = app.db
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var footer by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf("USD") }
    var rate by remember { mutableStateOf("") }
    var allowNegative by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        name = db.settings().get(SettingKeys.SHOP_NAME).orEmpty()
        phone = db.settings().get(SettingKeys.SHOP_PHONE).orEmpty()
        address = db.settings().get(SettingKeys.SHOP_ADDRESS).orEmpty()
        footer = db.settings().get(SettingKeys.RECEIPT_TEXT).orEmpty()
        currency = db.settings().get(SettingKeys.MAIN_CURRENCY) ?: "USD"
        rate = db.settings().get(SettingKeys.RATE_CDF_PER_USD)?.toLongOrNull()?.let { FinanceCalculator.formatMinor(it) }.orEmpty()
        allowNegative = db.settings().get(SettingKeys.ALLOW_NEGATIVE_STOCK) == "true"
    }

    Column(
        Modifier.padding(12.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Paramètres du commerce", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(name, { name = it }, label = { Text("Nom de la boutique") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(phone, { phone = it }, label = { Text("Téléphone") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(address, { address = it }, label = { Text("Adresse") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(footer, { footer = it }, label = { Text("Message sur les reçus") }, modifier = Modifier.fillMaxWidth())
        Text("Devise principale")
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("USD", "CDF").forEach { c -> FilterChip(currency == c, { currency = c }, { Text(c) }) }
        }
        OutlinedTextField(
            rate, { rate = it },
            label = { Text("Taux de change : combien de CDF pour 1 USD (à saisir vous-même)") },
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(allowNegative, { allowNegative = !allowNegative }, { Text("Autoriser la vente sans stock") })
        }
        message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        Button(
            onClick = {
                val r = if (rate.isBlank()) null else FinanceCalculator.parseToMinor(rate)
                if (rate.isNotBlank() && (r == null || r <= 0)) { message = "Taux invalide."; return@Button }
                if (name.isBlank()) { message = "Le nom de la boutique est obligatoire."; return@Button }
                scope.launch {
                    db.settings().put(AppSetting(SettingKeys.SHOP_NAME, name.trim()))
                    db.settings().put(AppSetting(SettingKeys.SHOP_PHONE, phone.trim()))
                    db.settings().put(AppSetting(SettingKeys.SHOP_ADDRESS, address.trim()))
                    db.settings().put(AppSetting(SettingKeys.RECEIPT_TEXT, footer.trim()))
                    db.settings().put(AppSetting(SettingKeys.MAIN_CURRENCY, currency))
                    if (r != null) db.settings().put(AppSetting(SettingKeys.RATE_CDF_PER_USD, r.toString()))
                    db.settings().put(AppSetting(SettingKeys.ALLOW_NEGATIVE_STOCK, allowNegative.toString()))
                    message = "Paramètres enregistrés."
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Enregistrer") }
    }
}
