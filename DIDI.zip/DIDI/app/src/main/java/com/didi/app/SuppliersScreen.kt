package com.didi.app

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.didi.app.data.Product
import com.didi.app.data.Purchase
import com.didi.app.data.PurchaseItem
import com.didi.app.data.PurchasePayment
import com.didi.app.data.Supplier
import com.didi.app.domain.FinanceCalculator
import com.didi.app.domain.PurchaseLine
import com.didi.app.domain.PurchaseRequest
import com.didi.app.domain.SaleException
import com.didi.app.domain.formatDate
import com.didi.app.domain.formatDateTime
import kotlinx.coroutines.launch
import java.util.UUID

private fun owed(p: Purchase) = (p.total - p.paidAmount).coerceAtLeast(0)

@Composable
fun SuppliersScreen(app: DidiApp) {
    val db = app.db
    val cur by rememberMainCurrency(app)
    val suppliers by remember(db) { db.suppliers().observeAll() }.collectAsState(emptyList())
    val purchases by remember(db) { db.purchases().observeAll() }.collectAsState(emptyList())
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Supplier?>(null) }
    var detailId by remember { mutableStateOf<Long?>(null) }
    var newPurchaseFor by remember { mutableStateOf<Long?>(null) }
    val debts = purchases.groupBy { it.supplierId }.mapValues { e -> e.value.sumOf { owed(it) } }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("Total dû aux fournisseurs : ${fmt(debts.values.sum())} $cur", style = MaterialTheme.typography.titleMedium) }
            if (suppliers.isEmpty()) item { Text("Aucun fournisseur. Touchez + pour en ajouter.") }
            items(suppliers, key = { it.id }) { s ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.name, style = MaterialTheme.typography.titleMedium)
                            Text((if (s.phone.isNotBlank()) "${s.phone} · " else "") + "dû ${fmt(debts[s.id] ?: 0)} $cur")
                        }
                        TextButton({ detailId = s.id }) { Text("Fiche") }
                    }
                }
            }
            item { Box(Modifier.heightIn(min = 80.dp)) }
        }
        FloatingActionButton({ showAdd = true }, Modifier.align(Alignment.BottomEnd).padding(16.dp)) { Text("+") }
    }

    if (showAdd) SupplierEditDialog(app, null) { showAdd = false }
    editing?.let { SupplierEditDialog(app, it) { editing = null } }
    detailId?.let { id ->
        val s = suppliers.firstOrNull { it.id == id }
        if (s != null) {
            val mine = purchases.filter { it.supplierId == id }
            InfoDialog(s.name, { detailId = null }) {
                Text(
                    listOfNotNull(
                        if (s.phone.isNotBlank()) "Téléphone : ${s.phone}" else null,
                        if (s.address.isNotBlank()) "Adresse : ${s.address}" else null,
                        if (s.notes.isNotBlank()) "Notes : ${s.notes}" else null,
                        "Dû : ${fmt(debts[id] ?: 0)} $cur"
                    ).joinToString("\n")
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button({ newPurchaseFor = id; detailId = null }) { Text("Nouvel achat") }
                    OutlinedButton({ editing = s; detailId = null }) { Text("Modifier") }
                }
                Text("Historique des achats", style = MaterialTheme.typography.titleSmall)
                if (mine.isEmpty()) Text("Aucun achat.")
                mine.forEach { p ->
                    Text("${formatDate(p.createdAt)} · ${if (p.invoiceRef.isNotBlank()) p.invoiceRef + " · " else ""}${fmt(p.total)} · payé ${fmt(p.paidAmount)} · reste ${fmt(owed(p))}")
                }
            }
        }
    }
    newPurchaseFor?.let { id -> PurchaseFormDialog(app, id) { newPurchaseFor = null } }
}

@Composable
fun SupplierEditDialog(app: DidiApp, existing: Supplier?, onClose: () -> Unit) {
    val db = app.db
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(existing?.name.orEmpty()) }
    var phone by remember { mutableStateOf(existing?.phone.orEmpty()) }
    var address by remember { mutableStateOf(existing?.address.orEmpty()) }
    var notes by remember { mutableStateOf(existing?.notes.orEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }
    FormDialog(
        title = if (existing == null) "Nouveau fournisseur" else "Modifier le fournisseur", error = error, onDismiss = onClose,
        onConfirm = {
            if (name.isBlank()) error = "Le nom est obligatoire."
            else scope.launch {
                if (existing == null) db.suppliers().insert(Supplier(name = name.trim(), phone = phone.trim(), address = address.trim(), notes = notes.trim()))
                else db.suppliers().update(existing.copy(name = name.trim(), phone = phone.trim(), address = address.trim(), notes = notes.trim()))
                onClose()
            }
        }
    ) {
        TextField1(name, "Nom ou raison sociale", { name = it })
        TextField1(phone, "Téléphone", { phone = it })
        TextField1(address, "Adresse", { address = it })
        TextField1(notes, "Notes", { notes = it })
    }
}

@Composable
fun PurchasesScreen(app: DidiApp) {
    val db = app.db
    val cur by rememberMainCurrency(app)
    val purchases by remember(db) { db.purchases().observeAll() }.collectAsState(emptyList())
    val suppliers by remember(db) { db.suppliers().observeAll() }.collectAsState(emptyList())
    val names = suppliers.associate { it.id to it.name }
    var showNew by remember { mutableStateOf(false) }
    var detailId by remember { mutableStateOf<Long?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("Achats : ${purchases.size} · reste à payer ${fmt(purchases.sumOf { owed(it) })} $cur", style = MaterialTheme.typography.titleMedium) }
            if (purchases.isEmpty()) item { Text("Aucun achat. Touchez + pour réceptionner une marchandise.") }
            items(purchases, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${names[p.supplierId] ?: "Fournisseur"} · ${formatDate(p.createdAt)}", style = MaterialTheme.typography.titleSmall)
                            Text("Total ${fmt(p.total)} $cur · payé ${fmt(p.paidAmount)} · reste ${fmt(owed(p))}" + if (p.invoiceRef.isNotBlank()) " · ${p.invoiceRef}" else "")
                        }
                        TextButton({ detailId = p.id }) { Text("Détail") }
                    }
                }
            }
            item { Box(Modifier.heightIn(min = 80.dp)) }
        }
        FloatingActionButton({ showNew = true }, Modifier.align(Alignment.BottomEnd).padding(16.dp)) { Text("+") }
    }
    if (showNew) PurchaseFormDialog(app, null) { showNew = false }
    detailId?.let { id ->
        val p = purchases.firstOrNull { it.id == id }
        if (p != null) PurchaseDetailDialog(app, p, names[p.supplierId] ?: "Fournisseur") { detailId = null }
    }
}

@Composable
private fun PurchaseDetailDialog(app: DidiApp, p: Purchase, supplierName: String, onClose: () -> Unit) {
    val db = app.db
    val items by produceState(emptyList<PurchaseItem>(), p.id) { value = db.purchases().itemsOf(p.id) }
    val payments by produceState(emptyList<PurchasePayment>(), p.id, p.paidAmount) { value = db.purchases().paymentsOf(p.id) }
    val productNames by produceState(emptyMap<Long, String>(), items) {
        value = items.associate { it.productId to (db.products().get(it.productId)?.name ?: "Produit") }
    }
    var showPay by remember { mutableStateOf(false) }
    val due = owed(p)
    if (showPay) {
        PayDialog("Payer $supplierName", due, p.currency, { showPay = false }) { amount, method, _ ->
            app.purchaseService.payPurchase(p.id, amount, method)
        }
    } else {
        InfoDialog("Achat chez $supplierName", onClose) {
            Text(
                listOfNotNull(
                    "Date : ${formatDateTime(p.createdAt)}",
                    if (p.invoiceRef.isNotBlank()) "Facture fournisseur : ${p.invoiceRef}" else null,
                    "Articles : ${fmt(p.itemsTotal)} · Frais : ${fmt(p.extraFees)}",
                    "Total : ${fmt(p.total)} ${p.currency} · Payé : ${fmt(p.paidAmount)} · Reste : ${fmt(due)}"
                ).joinToString("\n")
            )
            Text("Produits reçus", style = MaterialTheme.typography.titleSmall)
            items.forEach { Text("${productNames[it.productId] ?: "..."} x${it.quantity} à ${fmt(it.unitCost)}") }
            Text("Paiements au fournisseur", style = MaterialTheme.typography.titleSmall)
            if (payments.isEmpty()) Text("Aucun paiement.")
            payments.forEach { Text("${formatDateTime(it.createdAt)} · ${methodLabel(it.method)} · ${fmt(it.amount)}") }
            if (due > 0) Button({ showPay = true }) { Text("Payer le fournisseur") }
        }
    }
}

private class LineState(val product: Product) {
    var cost by mutableStateOf(FinanceCalculator.formatMinor(product.costPrice))
    var qty by mutableStateOf("1")
    var imeis by mutableStateOf("")
    var color by mutableStateOf("")
    var storage by mutableStateOf("")
}

/** Réception d'une marchandise : augmente le stock, recalcule le coût moyen, enregistre les IMEI. */
@Composable
fun PurchaseFormDialog(app: DidiApp, supplierId0: Long?, onClose: () -> Unit) {
    val db = app.db
    val scope = rememberCoroutineScope()
    val cur by rememberMainCurrency(app)
    val suppliers by remember(db) { db.suppliers().observeAll() }.collectAsState(emptyList())
    val products by remember(db) { db.products().observeActive() }.collectAsState(emptyList())
    var supplierId by remember { mutableStateOf(supplierId0) }
    var invoice by remember { mutableStateOf("") }
    var fees by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("ESPECES") }
    val lines = remember { mutableStateListOf<LineState>() }
    val token = remember { UUID.randomUUID().toString() }
    var showPicker by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun parseImeis(s: String) = s.split(Regex("[\\s,;]+")).filter { it.isNotBlank() }

    fun build(): PurchaseRequest? {
        val sid = supplierId ?: run { error = "Choisissez un fournisseur."; return null }
        if (lines.isEmpty()) { error = "Ajoutez au moins un produit."; return null }
        val out = mutableListOf<PurchaseLine>()
        for (l in lines) {
            val c = FinanceCalculator.parseToMinor(l.cost.ifBlank { "0" })
            if (c == null || c < 0) { error = "Prix d'achat invalide pour « ${l.product.name} »."; return null }
            if (l.product.tracksImei) {
                val list = parseImeis(l.imeis)
                if (list.isEmpty()) { error = "Saisissez les IMEI de « ${l.product.name} » (un par ligne)."; return null }
                out += PurchaseLine(l.product.id, list.size, c, list, l.color.trim(), l.storage.trim(), l.product.condition)
            } else {
                val q = l.qty.toIntOrNull()
                if (q == null || q <= 0) { error = "Quantité invalide pour « ${l.product.name} »."; return null }
                out += PurchaseLine(l.product.id, q, c)
            }
        }
        val f = if (fees.isBlank()) 0L else FinanceCalculator.parseToMinor(fees)
        val p = if (paid.isBlank()) 0L else FinanceCalculator.parseToMinor(paid)
        if (f == null || f < 0) { error = "Frais invalides."; return null }
        if (p == null || p < 0) { error = "Montant payé invalide."; return null }
        return PurchaseRequest(token, sid, invoice.trim(), out, f, p, method)
    }

    val itemsTotal = lines.sumOf { l ->
        val c = FinanceCalculator.parseToMinor(l.cost.ifBlank { "0" }) ?: 0L
        val q = if (l.product.tracksImei) parseImeis(l.imeis).size else (l.qty.toIntOrNull() ?: 0)
        c * q
    }
    val totalFees = FinanceCalculator.parseToMinor(fees.ifBlank { "0" }) ?: 0L

    FormDialog(
        title = "Nouvel achat (réception)", confirmLabel = if (busy) "..." else "Valider l'achat", error = error, onDismiss = onClose,
        onConfirm = {
            if (!busy) {
                val req = build()
                if (req != null) {
                    error = null; busy = true
                    scope.launch {
                        try {
                            app.purchaseService.receive(req)
                            onClose()
                        } catch (e: SaleException) {
                            error = e.message
                        } catch (e: Exception) {
                            error = "Erreur inattendue : ${e.message}"
                        } finally { busy = false }
                    }
                }
            }
        }
    ) {
        Text("Fournisseur")
        if (suppliers.isEmpty()) Text("Créez d'abord un fournisseur (menu Fournisseurs).", color = MaterialTheme.colorScheme.error)
        ChipRow(suppliers.map { it.id.toString() to it.name }, supplierId?.toString()) { supplierId = it.toLong() }
        TextField1(invoice, "Référence de la facture fournisseur", { invoice = it })
        Text("Produits reçus", style = MaterialTheme.typography.titleSmall)
        lines.forEachIndexed { i, l ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(l.product.name, style = MaterialTheme.typography.titleSmall)
                    MoneyField(l.cost, "Prix d'achat unitaire ($cur)", { l.cost = it })
                    if (l.product.tracksImei) {
                        OutlinedTextField(
                            l.imeis, { l.imeis = it }, label = { Text("IMEI reçus (un par ligne, 15 chiffres)") },
                            minLines = 3, modifier = Modifier.fillMaxWidth()
                        )
                        Text("${parseImeis(l.imeis).size} appareil(s)", style = MaterialTheme.typography.bodySmall)
                        TextField1(l.color, "Couleur (facultatif)", { l.color = it })
                        TextField1(l.storage, "Stockage (facultatif)", { l.storage = it })
                    } else {
                        IntField(l.qty, "Quantité reçue", { l.qty = it.filter(Char::isDigit) })
                    }
                    TextButton({ lines.removeAt(i) }) { Text("Retirer ce produit") }
                }
            }
        }
        OutlinedButton({ showPicker = true }) { Text("+ Ajouter un produit") }
        MoneyField(fees, "Frais supplémentaires (transport, douane...)", { fees = it })
        Text("Total de l'achat : ${fmt(itemsTotal + totalFees)} $cur")
        MoneyField(paid, "Montant payé maintenant", { paid = it })
        Text("Mode de paiement")
        ChipRow(PAY_METHODS, method) { method = it }
        Text("Le reste est enregistré comme dette envers le fournisseur. Les frais sont répartis dans le coût de revient.", style = MaterialTheme.typography.bodySmall)
    }

    if (showPicker) ProductPickerDialog(products, { p -> lines.add(LineState(p)); showPicker = false }, { showPicker = false })
}

@Composable
fun ProductPickerDialog(products: List<Product>, onPick: (Product) -> Unit, onClose: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val shown = products.filter { q.isBlank() || it.name.contains(q, true) || it.brand.contains(q, true) || it.model.contains(q, true) || it.sku?.contains(q, true) == true }
    FormDialog(title = "Choisir un produit", confirmLabel = "Fermer", onDismiss = onClose, onConfirm = onClose) {
        TextField1(q, "Rechercher", { q = it })
        if (products.isEmpty()) Text("Aucun produit. Créez-le d'abord dans l'onglet Produits.")
        shown.take(30).forEach { p ->
            TextButton({ onPick(p) }) { Text(p.name + (if (p.tracksImei) " (IMEI)" else "")) }
        }
    }
}
