package com.didi.app

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.didi.app.data.SettingKeys
import com.didi.app.domain.FinanceCalculator
import java.io.File
import java.util.UUID

fun fmt(v: Long): String = FinanceCalculator.formatMinor(v)

/** Devise principale du commerce (réglage), "USD" par défaut. */
@Composable
fun rememberMainCurrency(app: DidiApp): State<String> {
    val settings by app.db.settings().observeAll().collectAsState(emptyList())
    return remember { derivedStateOf { settings.firstOrNull { it.key == SettingKeys.MAIN_CURRENCY }?.value ?: "USD" } }
}

@Composable
fun MoneyField(value: String, label: String, onChange: (String) -> Unit, modifier: Modifier = Modifier.fillMaxWidth()) {
    OutlinedTextField(
        value, onChange, label = { Text(label) }, singleLine = true, modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    )
}

@Composable
fun IntField(value: String, label: String, onChange: (String) -> Unit, modifier: Modifier = Modifier.fillMaxWidth()) {
    OutlinedTextField(
        value, onChange, label = { Text(label) }, singleLine = true, modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
    )
}

@Composable
fun TextField1(value: String, label: String, onChange: (String) -> Unit, modifier: Modifier = Modifier.fillMaxWidth()) {
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true, modifier = modifier)
}

@Composable
fun ConfirmDialog(title: String, text: String, confirmLabel: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onConfirm) { Text(confirmLabel) } },
        dismissButton = { TextButton(onDismiss) { Text("Annuler") } }
    )
}

@Composable
fun InfoCard(title: String, lines: List<String>, modifier: Modifier = Modifier.fillMaxWidth()) {
    Card(modifier) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            lines.forEach { Text(it, style = MaterialTheme.typography.bodyMedium) }
        }
    }
}

/** Enregistre un fichier à l'endroit choisi par l'utilisateur (aucune permission Android nécessaire). */
@Composable
fun rememberFileSaver(mime: String): (String, ByteArray) -> Unit {
    val context = LocalContext.current
    var pending by remember { mutableStateOf<ByteArray?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(mime)) { uri: Uri? ->
        val bytes = pending
        if (uri != null && bytes != null) {
            context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
        }
        pending = null
    }
    return { name, bytes -> pending = bytes; launcher.launch(name) }
}

/** Copie un fichier choisi (photo, justificatif) dans le stockage privé de l'application. */
fun copyIntoApp(context: Context, uri: Uri, folder: String): String? = try {
    val dir = File(context.filesDir, folder).apply { mkdirs() }
    val out = File(dir, UUID.randomUUID().toString())
    context.contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { i.copyTo(it) } }
    out.path
} catch (e: Exception) { null }

@Composable
fun Thumbnail(path: String?, size: Int = 56) {
    if (path == null) return
    val bmp = remember(path) {
        try {
            val o = BitmapFactory.Options().apply { inSampleSize = 4 }
            BitmapFactory.decodeFile(path, o)
        } catch (e: Exception) { null }
    } ?: return
    Image(bmp.asImageBitmap(), contentDescription = null, modifier = Modifier.size(size.dp))
}
