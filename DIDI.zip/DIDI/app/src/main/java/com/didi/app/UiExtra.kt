package com.didi.app

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.didi.app.domain.FinanceCalculator
import com.didi.app.domain.PayMethods
import com.didi.app.domain.SaleException
import com.didi.app.domain.endOfDay
import com.didi.app.domain.formatDate
import com.didi.app.domain.parseDate
import com.didi.app.domain.startOfDay
import com.didi.app.domain.startOfMonth
import kotlinx.coroutines.launch

val PAY_METHODS: List<Pair<String, String>> get() = PayMethods.ALL
fun methodLabel(key: String): String = PayMethods.label(key)

/** Rangée de pastilles qui défile horizontalement (une seule sélection). */
@Composable
fun ChipRow(options: List<Pair<String, String>>, selected: String?, onSelect: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { (key, label) -> FilterChip(selected == key, { onSelect(key) }, { Text(label) }) }
    }
}

/** Boîte de dialogue de formulaire avec défilement et message d'erreur. */
@Composable
fun FormDialog(
    title: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    confirmLabel: String = "Enregistrer",
    error: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                content()
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = { TextButton(onConfirm) { Text(confirmLabel) } },
        dismissButton = { TextButton(onDismiss) { Text("Annuler") } }
    )
}

/** Boîte de dialogue d'information (bouton Fermer seulement). */
@Composable
fun InfoDialog(title: String, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) { content() }
        },
        confirmButton = { TextButton(onClose) { Text("Fermer") } }
    )
}

/** Période d'analyse choisie par l'utilisateur. */
data class DateRange(val label: String, val from: Long, val to: Long) {
    companion object {
        fun presets(): List<DateRange> {
            val end = endOfDay(System.currentTimeMillis())
            return listOf(
                DateRange("Aujourd'hui", startOfDay(0), end),
                DateRange("7 jours", startOfDay(6), end),
                DateRange("Ce mois", startOfMonth(), end),
                DateRange("Tout", 0L, end)
            )
        }
    }
}

@Composable
fun RangePicker(range: DateRange, onChange: (DateRange) -> Unit) {
    val presets = DateRange.presets()
    var custom by remember { mutableStateOf(false) }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        presets.forEach { p -> FilterChip(range.label == p.label, { onChange(p) }, { Text(p.label) }) }
        FilterChip(range.label.startsWith("Du "), { custom = true }, { Text("Période...") })
    }
    if (custom) {
        var a by remember { mutableStateOf(formatDate(range.from.coerceAtLeast(startOfDay(30)))) }
        var b by remember { mutableStateOf(formatDate(range.to)) }
        var err by remember { mutableStateOf<String?>(null) }
        FormDialog(
            title = "Période personnalisée", confirmLabel = "Appliquer", error = err,
            onDismiss = { custom = false },
            onConfirm = {
                val f = parseDate(a)
                val t = parseDate(b)
                if (f == null || t == null || t < f) err = "Dates invalides (format jj/mm/aaaa)."
                else { onChange(DateRange("Du $a au $b", f, endOfDay(t))); custom = false }
            }
        ) {
            TextField1(a, "Du (jj/mm/aaaa)", { a = it })
            TextField1(b, "Au (jj/mm/aaaa)", { b = it })
        }
    }
}

/**
 * Formulaire d'encaissement/paiement avec confirmation. [onPay] lance l'opération réelle ;
 * toute SaleException (ex. montant supérieur au solde) est affichée sans rien enregistrer.
 */
@Composable
fun PayDialog(
    title: String,
    maxAmount: Long,
    cur: String,
    onClose: () -> Unit,
    onPay: suspend (amount: Long, method: String, reference: String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var amount by remember { mutableStateOf(FinanceCalculator.formatMinor(maxAmount)) }
    var method by remember { mutableStateOf("ESPECES") }
    var ref by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf<Long?>(null) }

    FormDialog(
        title = title, confirmLabel = "Continuer", error = error, onDismiss = onClose,
        onConfirm = {
            val a = FinanceCalculator.parseToMinor(amount)
            if (a == null || a <= 0) error = "Montant invalide."
            else if (a > maxAmount) error = "Le montant dépasse le solde dû (${fmt(maxAmount)} $cur)."
            else { error = null; confirm = a }
        }
    ) {
        Text("Solde dû : ${fmt(maxAmount)} $cur")
        MoneyField(amount, "Montant payé ($cur)", { amount = it })
        ChipRow(PAY_METHODS, method) { method = it }
        if (method != "ESPECES") TextField1(ref, "Référence de transaction (facultatif)", { ref = it })
    }
    confirm?.let { a ->
        ConfirmDialog(
            "Confirmer le paiement",
            "Enregistrer un paiement de ${fmt(a)} $cur (${methodLabel(method)}) ?",
            "Confirmer",
            {
                scope.launch {
                    try {
                        onPay(a, method, ref.trim())
                        confirm = null
                        onClose()
                    } catch (e: SaleException) {
                        error = e.message; confirm = null
                    } catch (e: Exception) {
                        error = "Erreur inattendue : ${e.message}"; confirm = null
                    }
                }
            },
            { confirm = null }
        )
    }
}
