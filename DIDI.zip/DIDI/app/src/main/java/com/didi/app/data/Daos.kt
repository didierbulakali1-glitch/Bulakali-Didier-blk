package com.didi.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

data class TopProduct(val productName: String, val qty: Long, val revenue: Long)
data class UnitCount(val productId: Long, val n: Int)

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY name")
    fun observeAll(): Flow<List<Category>>

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun count(): Int

    @Insert suspend fun insert(c: Category): Long
    @Insert suspend fun insertAll(list: List<Category>)
    @Update suspend fun update(c: Category)
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE archived = 0 ORDER BY name")
    fun observeActive(): Flow<List<Product>>

    /** Tous les produits, y compris archivés (pour afficher l'historique). */
    @Query("SELECT * FROM products ORDER BY name")
    fun observeAll(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun get(id: Long): Product?

    @Query("SELECT * FROM products WHERE id = :id")
    fun observe(id: Long): Flow<Product?>

    @Insert suspend fun insert(p: Product): Long
    @Update suspend fun update(p: Product)

    @Query("UPDATE products SET archived = 1 WHERE id = :id")
    suspend fun archive(id: Long)

    /** Décrémente le stock seulement si la quantité est suffisante. Renvoie 0 si refusé. */
    @Query("UPDATE products SET stockQty = stockQty - :qty WHERE id = :id AND stockQty >= :qty")
    suspend fun decrementIfAvailable(id: Long, qty: Int): Int

    @Query("UPDATE products SET stockQty = stockQty - :qty WHERE id = :id")
    suspend fun decrementForced(id: Long, qty: Int)

    @Query("UPDATE products SET stockQty = stockQty + :qty WHERE id = :id")
    suspend fun increment(id: Long, qty: Int)

    @Query("UPDATE products SET stockQty = :qty, costPrice = :cost WHERE id = :id")
    suspend fun setStockAndCost(id: Long, qty: Int, cost: Long)

    @Query("SELECT * FROM stock_movements WHERE productId = :productId ORDER BY createdAt DESC, id DESC LIMIT 200")
    fun observeMovements(productId: Long): Flow<List<StockMovement>>

    @Insert suspend fun insertMovement(m: StockMovement)

    @Query("SELECT productId, COUNT(*) AS n FROM phone_units WHERE status = 'EN_STOCK' GROUP BY productId")
    fun observeUnitCounts(): Flow<List<UnitCount>>

    // ---- Indicateurs du tableau de bord ----
    @Query("""SELECT COALESCE(SUM(CASE WHEN tracksImei = 1
                 THEN (SELECT COALESCE(SUM(u.costPrice),0) FROM phone_units u WHERE u.productId = products.id AND u.status = 'EN_STOCK')
                 ELSE stockQty * costPrice END),0) FROM products WHERE archived = 0""")
    fun observeStockValue(): Flow<Long>

    @Query("""SELECT COUNT(*) FROM products WHERE archived = 0 AND
              ((tracksImei = 0 AND stockQty <= 0) OR
               (tracksImei = 1 AND NOT EXISTS (SELECT 1 FROM phone_units u WHERE u.productId = products.id AND u.status = 'EN_STOCK')))""")
    fun observeOutOfStockCount(): Flow<Int>

    @Query("""SELECT COUNT(*) FROM products WHERE archived = 0 AND tracksImei = 0 AND stockQty > 0 AND stockQty <= minStock""")
    fun observeLowStockCount(): Flow<Int>

    @Query("""SELECT COALESCE(SUM(stockQty),0) + (SELECT COUNT(*) FROM phone_units WHERE status = 'EN_STOCK')
              FROM products WHERE archived = 0 AND tracksImei = 0""")
    fun observeUnitsInStock(): Flow<Int>
}

@Dao
interface PhoneUnitDao {
    @Query("SELECT * FROM phone_units WHERE productId = :productId AND status = 'EN_STOCK' ORDER BY id")
    fun observeAvailable(productId: Long): Flow<List<PhoneUnit>>

    @Query("SELECT * FROM phone_units WHERE productId = :productId ORDER BY id DESC")
    fun observeAllOf(productId: Long): Flow<List<PhoneUnit>>

    @Query("SELECT * FROM phone_units ORDER BY id DESC")
    fun observeAll(): Flow<List<PhoneUnit>>

    @Query("SELECT * FROM phone_units WHERE imei1 = :imei OR imei2 = :imei LIMIT 1")
    suspend fun findByImei(imei: String): PhoneUnit?

    @Query("SELECT * FROM phone_units WHERE id = :id")
    suspend fun get(id: Long): PhoneUnit?

    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(u: PhoneUnit): Long

    @Query("UPDATE phone_units SET status = :status WHERE id = :id")
    suspend fun setStatus(id: Long, status: String)

    /** Passe l'appareil de EN_STOCK à VENDU en une opération atomique. */
    @Query("UPDATE phone_units SET status = 'VENDU' WHERE id = :id AND status = 'EN_STOCK'")
    suspend fun markSold(id: Long): Int
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY fullName")
    fun observeAll(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun get(id: Long): Customer?

    @Query("SELECT * FROM customers WHERE phone = :phone AND phone != '' LIMIT 1")
    suspend fun findByPhone(phone: String): Customer?

    @Insert suspend fun insert(c: Customer): Long
    @Update suspend fun update(c: Customer)
}

@Dao
interface SupplierDao {
    @Query("SELECT * FROM suppliers ORDER BY name")
    fun observeAll(): Flow<List<Supplier>>

    @Query("SELECT * FROM suppliers WHERE id = :id")
    suspend fun get(id: Long): Supplier?

    @Insert suspend fun insert(s: Supplier): Long
    @Update suspend fun update(s: Supplier)
}

@Dao
interface SaleDao {
    @Insert suspend fun insertSale(s: Sale): Long
    @Insert suspend fun insertItems(items: List<SaleItem>)
    @Insert suspend fun insertPayment(p: Payment): Long
    @Insert suspend fun insertMovement(m: StockMovement)
    @Update suspend fun updateSale(s: Sale)

    @Query("SELECT * FROM sales WHERE clientToken = :token LIMIT 1")
    suspend fun findByToken(token: String): Sale?

    @Query("SELECT * FROM sales WHERE id = :id")
    suspend fun get(id: Long): Sale?

    @Query("SELECT * FROM sales WHERE id = :id")
    fun observe(id: Long): Flow<Sale?>

    @Query("SELECT * FROM payments WHERE createdAt BETWEEN :from AND :to ORDER BY createdAt DESC")
    fun observePaymentsBetween(from: Long, to: Long): Flow<List<Payment>>

    @Query("SELECT COUNT(*) FROM sales")
    suspend fun countAll(): Int

    @Query("SELECT * FROM sales ORDER BY createdAt DESC LIMIT :limit")
    fun observeLatest(limit: Int): Flow<List<Sale>>

    @Query("SELECT * FROM sales WHERE createdAt BETWEEN :from AND :to ORDER BY createdAt DESC")
    fun observeBetween(from: Long, to: Long): Flow<List<Sale>>

    @Query("SELECT * FROM sale_items WHERE saleId = :saleId")
    suspend fun itemsOf(saleId: Long): List<SaleItem>

    @Query("SELECT * FROM sale_items WHERE id = :id")
    suspend fun itemOf(id: Long): SaleItem?

    @Query("SELECT * FROM payments WHERE saleId = :saleId ORDER BY createdAt")
    suspend fun paymentsOfSale(saleId: Long): List<Payment>

    @Query("SELECT * FROM payments WHERE customerId = :customerId ORDER BY createdAt DESC")
    fun observePaymentsOfCustomer(customerId: Long): Flow<List<Payment>>

    @Query("SELECT * FROM sales WHERE customerId = :customerId ORDER BY createdAt DESC")
    fun observeSalesOfCustomer(customerId: Long): Flow<List<Sale>>

    /** Ventes validées ayant encore un solde à payer. */
    @Query("SELECT * FROM sales WHERE status='VALIDEE' AND total - returnedAmount - paidAmount > 0 ORDER BY createdAt")
    fun observeOpenDebts(): Flow<List<Sale>>

    @Query("SELECT * FROM sales WHERE customerId = :customerId AND status='VALIDEE' AND total - returnedAmount - paidAmount > 0 ORDER BY createdAt")
    suspend fun openDebtsOf(customerId: Long): List<Sale>

    @Query("""SELECT s.* FROM sales s JOIN sale_items i ON i.saleId = s.id
              WHERE i.phoneUnitId = :unitId AND s.status = 'VALIDEE' ORDER BY s.id DESC LIMIT 1""")
    suspend fun saleOfUnit(unitId: Long): Sale?

    /** N'accepte le paiement que s'il ne dépasse pas le solde restant. */
    @Query("""UPDATE sales SET paidAmount = paidAmount + :amount
              WHERE id = :saleId AND status = 'VALIDEE' AND paidAmount + :amount <= total - returnedAmount""")
    suspend fun addToPaid(saleId: Long, amount: Long): Int
}

@Dao
interface ReturnDao {
    @Insert suspend fun insert(r: SaleReturn): Long
    @Insert suspend fun insertItems(items: List<SaleReturnItem>)

    @Query("SELECT * FROM sale_returns WHERE saleId = :saleId ORDER BY createdAt")
    suspend fun ofSale(saleId: Long): List<SaleReturn>

    @Query("SELECT * FROM sale_returns WHERE createdAt BETWEEN :from AND :to ORDER BY createdAt DESC")
    fun observeBetween(from: Long, to: Long): Flow<List<SaleReturn>>

    @Query("SELECT COALESCE(SUM(quantity),0) FROM sale_return_items WHERE saleItemId = :saleItemId")
    suspend fun returnedQty(saleItemId: Long): Int

    @Query("SELECT COALESCE(SUM(amount),0) FROM sale_return_items WHERE saleItemId = :saleItemId")
    suspend fun returnedAmountOfItem(saleItemId: Long): Long
}

@Dao
interface PurchaseDao {
    @Insert suspend fun insert(p: Purchase): Long
    @Insert suspend fun insertItems(items: List<PurchaseItem>)
    @Insert suspend fun insertPayment(p: PurchasePayment): Long

    @Query("SELECT * FROM purchases WHERE clientToken = :token LIMIT 1")
    suspend fun findByToken(token: String): Purchase?

    @Query("SELECT * FROM purchases WHERE id = :id")
    suspend fun get(id: Long): Purchase?

    @Query("SELECT * FROM purchases ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<Purchase>>

    @Query("SELECT * FROM purchases WHERE supplierId = :supplierId ORDER BY createdAt DESC")
    fun observeOfSupplier(supplierId: Long): Flow<List<Purchase>>

    @Query("SELECT * FROM purchase_items WHERE purchaseId = :purchaseId")
    suspend fun itemsOf(purchaseId: Long): List<PurchaseItem>

    @Query("SELECT * FROM purchase_payments WHERE purchaseId = :purchaseId ORDER BY createdAt")
    suspend fun paymentsOf(purchaseId: Long): List<PurchasePayment>

    @Query("UPDATE purchases SET paidAmount = paidAmount + :amount WHERE id = :id AND paidAmount + :amount <= total")
    suspend fun addToPaid(id: Long, amount: Long): Int
}

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expense_categories ORDER BY name")
    fun observeCategories(): Flow<List<ExpenseCategory>>

    @Query("SELECT COUNT(*) FROM expense_categories")
    suspend fun countCategories(): Int

    @Insert suspend fun insertCategories(list: List<ExpenseCategory>)
    @Insert suspend fun insertCategory(c: ExpenseCategory): Long
    @Update suspend fun updateCategory(c: ExpenseCategory)
    @Insert suspend fun insert(e: Expense): Long
    @Update suspend fun update(e: Expense)

    @Query("SELECT * FROM expenses WHERE date BETWEEN :from AND :to ORDER BY date DESC")
    fun observeBetween(from: Long, to: Long): Flow<List<Expense>>

    @Query("SELECT COALESCE(SUM(amountInMain),0) FROM expenses WHERE date BETWEEN :from AND :to")
    fun observeTotal(from: Long, to: Long): Flow<Long>
}

@Dao
interface RepairDao {
    @Insert suspend fun insert(r: RepairCase): Long
    @Update suspend fun update(r: RepairCase)
    @Insert suspend fun insertEvent(e: RepairEvent)

    @Query("SELECT COUNT(*) FROM repairs")
    suspend fun count(): Int

    @Query("SELECT * FROM repairs ORDER BY receivedAt DESC")
    fun observeAll(): Flow<List<RepairCase>>

    @Query("SELECT * FROM repairs WHERE imei = :imei ORDER BY receivedAt DESC")
    suspend fun ofImei(imei: String): List<RepairCase>

    @Query("SELECT * FROM repair_events WHERE repairId = :repairId ORDER BY createdAt, id")
    suspend fun eventsOf(repairId: Long): List<RepairEvent>
}

@Dao
interface UserDao {
    @Query("SELECT * FROM users ORDER BY name")
    fun observeAll(): Flow<List<AppUser>>

    @Query("SELECT COUNT(*) FROM users WHERE active = 1")
    fun observeActiveCount(): Flow<Int>

    @Query("SELECT * FROM users WHERE active = 1")
    suspend fun active(): List<AppUser>

    @Insert suspend fun insert(u: AppUser): Long
    @Update suspend fun update(u: AppUser)

    @Query("SELECT COUNT(*) FROM users WHERE active = 1 AND role = 'ADMIN'")
    suspend fun activeAdminCount(): Int
}

@Dao
interface SettingsDao {
    @Query("SELECT value FROM app_settings WHERE key = :key")
    suspend fun get(key: String): String?

    @Query("SELECT * FROM app_settings")
    fun observeAll(): Flow<List<AppSetting>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(s: AppSetting)
}

/** Agrégats financiers. Seules les ventes validées comptent ; les retours sont déduits à leur date. */
@Dao
interface ReportDao {
    @Query("SELECT COALESCE(SUM(total),0) FROM sales WHERE status='VALIDEE' AND createdAt BETWEEN :from AND :to")
    fun salesTotal(from: Long, to: Long): Flow<Long>

    @Query("SELECT COALESCE(SUM(costTotal),0) FROM sales WHERE status='VALIDEE' AND createdAt BETWEEN :from AND :to")
    fun salesCost(from: Long, to: Long): Flow<Long>

    @Query("SELECT COUNT(*) FROM sales WHERE status='VALIDEE' AND createdAt BETWEEN :from AND :to")
    fun salesCount(from: Long, to: Long): Flow<Int>

    @Query("SELECT COALESCE(SUM(amount),0) FROM sale_returns WHERE createdAt BETWEEN :from AND :to")
    fun returnsAmount(from: Long, to: Long): Flow<Long>

    @Query("SELECT COALESCE(SUM(costRecovered),0) FROM sale_returns WHERE createdAt BETWEEN :from AND :to")
    fun returnsCost(from: Long, to: Long): Flow<Long>

    /** Trésorerie encaissée : paiements reçus moins remboursements (montants négatifs). */
    @Query("SELECT COALESCE(SUM(amountInMain),0) FROM payments WHERE createdAt BETWEEN :from AND :to")
    fun cashIn(from: Long, to: Long): Flow<Long>

    @Query("SELECT COALESCE(SUM(MAX(total - returnedAmount - paidAmount, 0)),0) FROM sales WHERE status='VALIDEE'")
    fun receivables(): Flow<Long>

    @Query("SELECT COALESCE(SUM(MAX(total - paidAmount, 0)),0) FROM purchases")
    fun supplierDebts(): Flow<Long>

    @Query("""SELECT i.productName AS productName, SUM(i.quantity) AS qty, SUM(i.lineTotal) AS revenue
              FROM sale_items i JOIN sales s ON s.id = i.saleId
              WHERE s.status='VALIDEE' AND s.createdAt BETWEEN :from AND :to
              GROUP BY i.productId ORDER BY qty DESC, revenue DESC""")
    fun productsSold(from: Long, to: Long): Flow<List<TopProduct>>

    @Query("SELECT COALESCE(SUM(amountInMain),0) FROM payments WHERE method = :method AND createdAt BETWEEN :from AND :to")
    fun cashByMethod(method: String, from: Long, to: Long): Flow<Long>
}
