package com.didi.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

data class TopProduct(val productName: String, val qty: Long, val revenue: Long)

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY name")
    fun observeAll(): Flow<List<Category>>

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun count(): Int

    @Insert suspend fun insert(c: Category): Long
    @Insert suspend fun insertAll(list: List<Category>)
    @Update suspend fun update(c: Category)
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE archived = 0 ORDER BY name")
    fun observeActive(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun get(id: Long): Product?

    @Insert suspend fun insert(p: Product): Long
    @Update suspend fun update(p: Product)

    @Query("UPDATE products SET archived = 1 WHERE id = :id")
    suspend fun archive(id: Long)

    /** Décrémente le stock seulement si la quantité est suffisante. Renvoie 0 si refusé. */
    @Query("UPDATE products SET stockQty = stockQty - :qty WHERE id = :id AND stockQty >= :qty")
    suspend fun decrementIfAvailable(id: Long, qty: Int): Int

    @Query("UPDATE products SET stockQty = stockQty - :qty WHERE id = :id")
    suspend fun decrementForced(id: Long, qty: Int)

    @Query("UPDATE products SET stockQty = stockQty + :qty WHERE id = :id")
    suspend fun increment(id: Long, qty: Int)

    // ---- Indicateurs du tableau de bord ----
    @Query("""SELECT COALESCE(SUM(CASE WHEN tracksImei = 1
                 THEN (SELECT COALESCE(SUM(u.costPrice),0) FROM phone_units u WHERE u.productId = products.id AND u.status = 'EN_STOCK')
                 ELSE stockQty * costPrice END),0) FROM products WHERE archived = 0""")
    fun observeStockValue(): Flow<Long>

    @Query("""SELECT COUNT(*) FROM products WHERE archived = 0 AND tracksImei = 0 AND stockQty <= 0""")
    fun observeOutOfStockCount(): Flow<Int>

    @Query("""SELECT COUNT(*) FROM products WHERE archived = 0 AND tracksImei = 0 AND stockQty > 0 AND stockQty <= minStock""")
    fun observeLowStockCount(): Flow<Int>

    @Query("""SELECT COALESCE(SUM(stockQty),0) + (SELECT COUNT(*) FROM phone_units WHERE status = 'EN_STOCK')
              FROM products WHERE archived = 0 AND tracksImei = 0""")
    fun observeUnitsInStock(): Flow<Int>
}

@Dao
interface PhoneUnitDao {
    @Query("SELECT * FROM phone_units WHERE productId = :productId AND status = 'EN_STOCK' ORDER BY id")
    fun observeAvailable(productId: Long): Flow<List<PhoneUnit>>

    @Query("SELECT * FROM phone_units WHERE imei1 = :imei OR imei2 = :imei LIMIT 1")
    suspend fun findByImei(imei: String): PhoneUnit?

    @Query("SELECT * FROM phone_units WHERE id = :id")
    suspend fun get(id: Long): PhoneUnit?

    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(u: PhoneUnit): Long

    /** Passe l'appareil de EN_STOCK à VENDU en une opération atomique. */
    @Query("UPDATE phone_units SET status = 'VENDU' WHERE id = :id AND status = 'EN_STOCK'")
    suspend fun markSold(id: Long): Int
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY fullName")
    fun observeAll(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun get(id: Long): Customer?

    @Query("SELECT * FROM customers WHERE phone = :phone AND phone != '' LIMIT 1")
    suspend fun findByPhone(phone: String): Customer?

    @Insert suspend fun insert(c: Customer): Long
    @Update suspend fun update(c: Customer)
}

@Dao
interface SupplierDao {
    @Query("SELECT * FROM suppliers ORDER BY name")
    fun observeAll(): Flow<List<Supplier>>

    @Insert suspend fun insert(s: Supplier): Long
    @Update suspend fun update(s: Supplier)
}

@Dao
interface SaleDao {
    @Insert suspend fun insertSale(s: Sale): Long
    @Insert suspend fun insertItems(items: List<SaleItem>)
    @Insert suspend fun insertPayment(p: Payment): Long
    @Insert suspend fun insertMovement(m: StockMovement)

    @Query("SELECT * FROM sales WHERE clientToken = :token LIMIT 1")
    suspend fun findByToken(token: String): Sale?

    @Query("SELECT COUNT(*) FROM sales")
    suspend fun countAll(): Int

    @Query("SELECT * FROM sales ORDER BY createdAt DESC LIMIT :limit")
    fun observeLatest(limit: Int): Flow<List<Sale>>

    @Query("SELECT * FROM sale_items WHERE saleId = :saleId")
    suspend fun itemsOf(saleId: Long): List<SaleItem>

    // ---- Indicateurs : on ne compte que les ventes validées ----
    @Query("SELECT COALESCE(SUM(total),0) FROM sales WHERE status='VALIDEE' AND createdAt BETWEEN :from AND :to")
    fun observeRevenue(from: Long, to: Long): Flow<Long>

    @Query("SELECT COALESCE(SUM(costTotal),0) FROM sales WHERE status='VALIDEE' AND createdAt BETWEEN :from AND :to")
    fun observeCogs(from: Long, to: Long): Flow<Long>

    @Query("SELECT COUNT(*) FROM sales WHERE status='VALIDEE' AND createdAt BETWEEN :from AND :to")
    fun observeSalesCount(from: Long, to: Long): Flow<Int>

    /** Créances clients = somme des soldes des ventes validées. */
    @Query("SELECT COALESCE(SUM(total - paidAmount),0) FROM sales WHERE status='VALIDEE' AND total > paidAmount")
    fun observeReceivables(): Flow<Long>

    @Query("""SELECT i.productName AS productName, SUM(i.quantity) AS qty, SUM(i.lineTotal) AS revenue
              FROM sale_items i JOIN sales s ON s.id = i.saleId
              WHERE s.status='VALIDEE' AND s.createdAt BETWEEN :from AND :to
              GROUP BY i.productId ORDER BY qty DESC LIMIT :limit""")
    fun observeTopProducts(from: Long, to: Long, limit: Int): Flow<List<TopProduct>>

    @Query("UPDATE sales SET paidAmount = paidAmount + :amount WHERE id = :saleId AND paidAmount + :amount <= total")
    suspend fun addToPaid(saleId: Long, amount: Long): Int
}

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expense_categories ORDER BY name")
    fun observeCategories(): Flow<List<ExpenseCategory>>

    @Query("SELECT COUNT(*) FROM expense_categories")
    suspend fun countCategories(): Int

    @Insert suspend fun insertCategories(list: List<ExpenseCategory>)
    @Insert suspend fun insert(e: Expense): Long

    @Query("SELECT * FROM expenses WHERE date BETWEEN :from AND :to ORDER BY date DESC")
    fun observeBetween(from: Long, to: Long): Flow<List<Expense>>

    @Query("SELECT COALESCE(SUM(amountInMain),0) FROM expenses WHERE date BETWEEN :from AND :to")
    fun observeTotal(from: Long, to: Long): Flow<Long>
}

@Dao
interface SettingsDao {
    @Query("SELECT value FROM app_settings WHERE key = :key")
    suspend fun get(key: String): String?

    @Query("SELECT * FROM app_settings")
    fun observeAll(): Flow<List<AppSetting>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(s: AppSetting)
}
