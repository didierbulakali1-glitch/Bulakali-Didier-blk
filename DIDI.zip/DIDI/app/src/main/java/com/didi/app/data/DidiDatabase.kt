package com.didi.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        Category::class, Supplier::class, Product::class, PhoneUnit::class, Customer::class,
        Sale::class, SaleItem::class, Payment::class, StockMovement::class,
        ExpenseCategory::class, Expense::class, Purchase::class, PurchaseItem::class,
        PurchasePayment::class, SaleReturn::class, SaleReturnItem::class,
        RepairCase::class, RepairEvent::class, AppUser::class,
        AppSetting::class
    ],
    version = 1,
    exportSchema = true
)
abstract class DidiDatabase : RoomDatabase() {
    abstract fun categories(): CategoryDao
    abstract fun products(): ProductDao
    abstract fun phoneUnits(): PhoneUnitDao
    abstract fun customers(): CustomerDao
    abstract fun suppliers(): SupplierDao
    abstract fun sales(): SaleDao
    abstract fun expenses(): ExpenseDao
    abstract fun settings(): SettingsDao
    abstract fun returns(): ReturnDao
    abstract fun purchases(): PurchaseDao
    abstract fun repairs(): RepairDao
    abstract fun users(): UserDao
    abstract fun reports(): ReportDao

    companion object {
        /**
         * Quand une version future ajoute une table ou une colonne, on ajoute ici une Migration
         * (ex. MIGRATION_1_2) et on augmente `version`. Les données existantes sont conservées.
         */
        val MIGRATIONS: Array<Migration> = arrayOf()

        @Volatile private var instance: DidiDatabase? = null

        fun get(context: Context): DidiDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(context.applicationContext, DidiDatabase::class.java, "didi.db")
                    .addMigrations(*MIGRATIONS)
                    .build()
                    .also { instance = it }
            }

        /** Ferme la base (utilisé avant une restauration de sauvegarde). */
        fun close() {
            synchronized(this) { instance?.close(); instance = null }
        }
    }
}

/** Données de départ modifiables ensuite par l'utilisateur. Ce sont des réglages, pas des ventes fictives. */
suspend fun DidiDatabase.seedDefaultsIfNeeded() {
    if (categories().count() == 0) {
        categories().insertAll(
            listOf(
                Category(name = "Smartphones", isPhone = true),
                Category(name = "Téléphones simples", isPhone = true),
                Category(name = "Chargeurs"), Category(name = "Câbles USB"),
                Category(name = "Écouteurs"), Category(name = "Casques"),
                Category(name = "Batteries"), Category(name = "Power banks"),
                Category(name = "Coques"), Category(name = "Vitres de protection"),
                Category(name = "Cartes mémoire"), Category(name = "Supports téléphoniques"),
                Category(name = "Adaptateurs"), Category(name = "Accessoires Bluetooth"),
                Category(name = "Autres accessoires")
            )
        )
    }
    if (expenses().countCategories() == 0) {
        expenses().insertCategories(
            listOf("Loyer", "Transport", "Électricité", "Internet", "Salaires",
                "Réparations", "Emballages", "Frais bancaires", "Autres dépenses")
                .map { ExpenseCategory(name = it) }
        )
    }
    if (settings().get(SettingKeys.SHOP_NAME) == null) {
        settings().put(AppSetting(SettingKeys.SHOP_NAME, "Ma boutique"))
        settings().put(AppSetting(SettingKeys.MAIN_CURRENCY, "USD"))
        settings().put(AppSetting(SettingKeys.ALLOW_NEGATIVE_STOCK, "false"))
    }
}
