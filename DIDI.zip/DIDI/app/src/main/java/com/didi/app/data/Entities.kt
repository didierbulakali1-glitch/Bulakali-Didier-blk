package com.didi.app.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

// Tous les montants sont des Long en centièmes (voir FinanceCalculator).

@Entity(tableName = "categories", indices = [Index("name", unique = true)])
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val isPhone: Boolean = false,
    val active: Boolean = true
)

@Entity(tableName = "suppliers")
data class Supplier(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "products",
    foreignKeys = [
        ForeignKey(Category::class, ["id"], ["categoryId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(Supplier::class, ["id"], ["supplierId"], onDelete = ForeignKey.SET_NULL)
    ],
    indices = [Index("categoryId"), Index("supplierId"), Index("sku", unique = true), Index("barcode")]
)
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sku: String? = null,
    val barcode: String? = null,
    val categoryId: Long,
    val brand: String = "",
    val model: String = "",
    val description: String = "",
    val costPrice: Long = 0,          // prix d'achat moyen (devise principale)
    val salePrice: Long = 0,          // prix de vente (devise principale)
    val stockQty: Int = 0,            // inutilisé pour les téléphones suivis par IMEI
    val minStock: Int = 0,
    val supplierId: Long? = null,
    val warrantyMonths: Int = 0,
    val photoPath: String? = null,
    val condition: String = "NEUF",
    val location: String = "",
    val tracksImei: Boolean = false,  // true = chaque appareil est une ligne dans phone_units
    val archived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "phone_units",
    foreignKeys = [ForeignKey(Product::class, ["id"], ["productId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("productId"), Index("imei1", unique = true), Index("imei2")]
)
data class PhoneUnit(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val imei1: String,
    val imei2: String? = null,
    val serial: String? = null,
    val color: String = "",
    val storage: String = "",
    val ram: String = "",
    val condition: String = "NEUF",
    val costPrice: Long,
    val salePrice: Long,
    val status: String = UnitStatus.IN_STOCK,
    val purchasedAt: Long = System.currentTimeMillis(),
    val supplierId: Long? = null,
    val warrantyMonths: Int = 0
)

object UnitStatus {
    const val IN_STOCK = "EN_STOCK"
    const val SOLD = "VENDU"
    const val RETURNED = "RETOURNE"
    const val IN_REPAIR = "EN_REPARATION"
    const val DEFECTIVE = "DEFECTUEUX"
}

@Entity(tableName = "customers", indices = [Index("phone")])
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String,
    val phone: String = "",
    val address: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "sales",
    foreignKeys = [ForeignKey(Customer::class, ["id"], ["customerId"], onDelete = ForeignKey.SET_NULL)],
    indices = [Index("customerId"), Index("createdAt"), Index("clientToken", unique = true), Index("number", unique = true)]
)
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val number: String,
    val clientToken: String,          // jeton unique : empêche l'enregistrement en double
    val createdAt: Long = System.currentTimeMillis(),
    val customerId: Long? = null,
    val sellerName: String = "",
    val subtotal: Long,
    val discountTotal: Long,
    val total: Long,
    val paidAmount: Long,
    val currency: String,             // devise principale au moment de la vente
    val paymentMethod: String,
    val costTotal: Long,              // coût des marchandises vendues
    val status: String = SaleStatus.VALIDATED,
    val dueDate: Long? = null,
    val note: String = "",
    val returnedAmount: Long = 0,     // total des retours acceptés sur cette vente
    val cancelledAt: Long? = null,
    val cancelReason: String = ""
)

object SaleStatus {
    const val VALIDATED = "VALIDEE"
    const val CANCELLED = "ANNULEE"
}

@Entity(
    tableName = "sale_items",
    foreignKeys = [
        ForeignKey(Sale::class, ["id"], ["saleId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(Product::class, ["id"], ["productId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index("saleId"), Index("productId"), Index("phoneUnitId")]
)
data class SaleItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val productId: Long,
    val phoneUnitId: Long? = null,
    val imei: String? = null,         // copie de l'IMEI au moment de la vente
    val productName: String,          // copie du nom : l'historique ne change pas si le produit est renommé
    val quantity: Int,
    val unitPrice: Long,
    val discount: Long,
    val lineTotal: Long,
    val unitCost: Long
)

@Entity(
    tableName = "payments",
    foreignKeys = [ForeignKey(Sale::class, ["id"], ["saleId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("saleId"), Index("customerId")]
)
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val customerId: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val method: String,               // ESPECES, MOBILE_MONEY, VIREMENT, CARTE, AUTRE
    val reference: String = "",
    val currency: String,             // devise réellement reçue
    val amountReceived: Long,         // montant dans la devise reçue
    val rateCdfPerUsd: Long? = null,  // taux utilisé si conversion (conservé pour l'historique)
    val amountInMain: Long,           // montant converti en devise principale, imputé sur la dette
    val note: String = ""
)

@Entity(
    tableName = "stock_movements",
    foreignKeys = [ForeignKey(Product::class, ["id"], ["productId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("productId"), Index("createdAt")]
)
data class StockMovement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val phoneUnitId: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val type: String,                 // ACHAT, VENTE, RETOUR, AJUSTEMENT, ANNULATION
    val quantityDelta: Int,
    val refType: String = "",
    val refId: Long? = null,
    val note: String = ""
)

@Entity(tableName = "expense_categories", indices = [Index("name", unique = true)])
data class ExpenseCategory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val active: Boolean = true
)

@Entity(
    tableName = "expenses",
    foreignKeys = [ForeignKey(ExpenseCategory::class, ["id"], ["categoryId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("categoryId"), Index("date")]
)
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long = System.currentTimeMillis(),
    val categoryId: Long,
    val description: String = "",
    val amount: Long,
    val currency: String,
    val amountInMain: Long,
    val method: String = "ESPECES",
    val reference: String = "",
    val attachmentPath: String? = null
)

@Entity(
    tableName = "purchases",
    foreignKeys = [ForeignKey(Supplier::class, ["id"], ["supplierId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("supplierId"), Index("clientToken", unique = true)]
)
data class Purchase(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientToken: String,
    val supplierId: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val invoiceRef: String = "",
    val itemsTotal: Long,
    val extraFees: Long = 0,
    val total: Long,
    val paidAmount: Long,
    val currency: String
)

@Entity(
    tableName = "purchase_items",
    foreignKeys = [
        ForeignKey(Purchase::class, ["id"], ["purchaseId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(Product::class, ["id"], ["productId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index("purchaseId"), Index("productId")]
)
data class PurchaseItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val purchaseId: Long,
    val productId: Long,
    val quantity: Int,
    val unitCost: Long
)

@Entity(
    tableName = "sale_returns",
    foreignKeys = [ForeignKey(Sale::class, ["id"], ["saleId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("saleId"), Index("createdAt")]
)
data class SaleReturn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val reason: String = "",
    val amount: Long,                 // valeur des articles retournés
    val costRecovered: Long,          // coût des articles remis en stock vendable
    val creditReduction: Long,        // part qui diminue la dette du client
    val refundAmount: Long,           // part rendue en argent
    val refundMethod: String = "ESPECES",
    val byUser: String = ""
)

@Entity(
    tableName = "sale_return_items",
    foreignKeys = [ForeignKey(SaleReturn::class, ["id"], ["returnId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("returnId"), Index("saleItemId")]
)
data class SaleReturnItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val returnId: Long,
    val saleItemId: Long,
    val productId: Long,
    val phoneUnitId: Long? = null,
    val quantity: Int,
    val amount: Long,
    val restocked: Boolean
)

@Entity(
    tableName = "purchase_payments",
    foreignKeys = [ForeignKey(Purchase::class, ["id"], ["purchaseId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("purchaseId")]
)
data class PurchasePayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val purchaseId: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val amount: Long,
    val method: String = "ESPECES",
    val note: String = ""
)

@Entity(tableName = "repairs", indices = [Index("number", unique = true), Index("imei")])
data class RepairCase(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val number: String,
    val customerId: Long? = null,
    val customerName: String = "",
    val customerPhone: String = "",
    val productLabel: String = "",
    val imei: String = "",
    val soldAt: Long? = null,
    val receivedAt: Long = System.currentTimeMillis(),
    val problem: String = "",
    val itemCondition: String = "",
    val diagnosis: String = "",
    val plannedRepair: String = "",
    val estimatedCost: Long = 0,
    val finalCost: Long = 0,
    val technician: String = "",
    val returnedAt: Long? = null,
    val status: String = RepairStatus.RECEIVED,
    val underWarranty: Boolean = false
)

object RepairStatus {
    const val RECEIVED = "Reçu"
    const val DIAGNOSING = "En diagnostic"
    const val REPAIRING = "En réparation"
    const val WAITING_PART = "En attente de pièce"
    const val REPAIRED = "Réparé"
    const val RETURNED = "Restitué"
    const val UNREPAIRABLE = "Non réparable"
    val ALL = listOf(RECEIVED, DIAGNOSING, REPAIRING, WAITING_PART, REPAIRED, RETURNED, UNREPAIRABLE)
}

@Entity(
    tableName = "repair_events",
    foreignKeys = [ForeignKey(RepairCase::class, ["id"], ["repairId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("repairId")]
)
data class RepairEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val repairId: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val status: String,
    val note: String = ""
)

@Entity(tableName = "users", indices = [Index("name", unique = true)])
data class AppUser(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val role: String,                 // ADMIN, VENDEUR, STOCK
    val pinHash: String,
    val pinSalt: String,
    val permissions: String,          // clés séparées par des virgules
    val active: Boolean = true
)

@Entity(tableName = "app_settings")
data class AppSetting(
    @PrimaryKey val key: String,
    val value: String
)

object SettingKeys {
    const val SHOP_NAME = "shop_name"
    const val SHOP_PHONE = "shop_phone"
    const val SHOP_ADDRESS = "shop_address"
    const val MAIN_CURRENCY = "main_currency"
    const val RATE_CDF_PER_USD = "rate_cdf_per_usd" // en centièmes, saisi manuellement
    const val RECEIPT_TEXT = "receipt_text"
    const val ALLOW_NEGATIVE_STOCK = "allow_negative_stock"
    const val VENDOR_MAX_DISCOUNT = "vendor_max_discount_percent"
    const val LOGO = "logo_path"
    const val LAST_BACKUP = "last_backup_at"
    const val DARK_THEME = "dark_theme"           // "auto" | "light" | "dark"
    const val ACCENT = "accent_color"             // "or" | "vert" | "rouge"
    fun feature(key: String) = "feature_$key"     // "true" / "false"
}
