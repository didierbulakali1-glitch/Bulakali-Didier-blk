package com.didi.app.domain

import androidx.room.withTransaction
import com.didi.app.data.DidiDatabase
import com.didi.app.data.Payment
import com.didi.app.data.SaleReturn
import com.didi.app.data.SaleReturnItem
import com.didi.app.data.SaleStatus
import com.didi.app.data.SettingKeys
import com.didi.app.data.StockMovement
import com.didi.app.data.UnitStatus

data class ReturnLine(val saleItemId: Long, val quantity: Int, val restock: Boolean)

/** Retours, annulations et encaissement de dettes. Chaque opération est atomique (une seule transaction). */
class AfterSaleService(private val db: DidiDatabase) {

    private suspend fun mainCurrency() = db.settings().get(SettingKeys.MAIN_CURRENCY) ?: "USD"

    /**
     * Retour partiel ou total sur une vente validée.
     * - La valeur retournée diminue d'abord la dette du client, le reste est remboursé en argent.
     * - Un article défectueux (restock = false) ne revient PAS dans le stock vendable.
     */
    suspend fun returnItems(
        saleId: Long, lines: List<ReturnLine>, reason: String,
        refundMethod: String = "ESPECES", byUser: String = ""
    ): SaleReturn = db.withTransaction {
        val sale = db.sales().get(saleId) ?: throw SaleException("Vente introuvable.")
        if (sale.status != SaleStatus.VALIDATED) throw SaleException("Cette vente est annulée.")
        val chosen = lines.filter { it.quantity > 0 }
        if (chosen.isEmpty()) throw SaleException("Sélectionnez au moins un article à retourner.")

        var amountTotal = 0L
        var costRecovered = 0L
        val returnItems = mutableListOf<SaleReturnItem>()
        val movements = mutableListOf<StockMovement>()

        for (l in chosen) {
            val item = db.sales().itemOf(l.saleItemId)?.takeIf { it.saleId == saleId }
                ?: throw SaleException("Article introuvable dans cette vente.")
            val already = db.returns().returnedQty(item.id)
            val remaining = item.quantity - already
            if (l.quantity > remaining) throw SaleException("« ${item.productName} » : maximum $remaining à retourner.")
            val alreadyAmount = db.returns().returnedAmountOfItem(item.id)
            val amount = if (l.quantity == remaining) item.lineTotal - alreadyAmount
            else item.lineTotal * l.quantity / item.quantity

            if (item.phoneUnitId != null) {
                db.phoneUnits().setStatus(item.phoneUnitId, if (l.restock) UnitStatus.IN_STOCK else UnitStatus.DEFECTIVE)
            } else if (l.restock) {
                db.products().increment(item.productId, l.quantity)
            }
            if (l.restock) {
                costRecovered += item.unitCost * l.quantity
                movements += StockMovement(
                    productId = item.productId, phoneUnitId = item.phoneUnitId,
                    type = "RETOUR", quantityDelta = l.quantity, refType = "VENTE", refId = saleId, note = reason
                )
            }
            amountTotal += amount
            returnItems += SaleReturnItem(
                returnId = 0, saleItemId = item.id, productId = item.productId, phoneUnitId = item.phoneUnitId,
                quantity = l.quantity, amount = amount, restocked = l.restock
            )
        }

        val balanceBefore = (sale.total - sale.returnedAmount - sale.paidAmount).coerceAtLeast(0)
        val creditReduction = minOf(amountTotal, balanceBefore)
        val refund = amountTotal - creditReduction

        val ret = SaleReturn(
            saleId = saleId, reason = reason, amount = amountTotal, costRecovered = costRecovered,
            creditReduction = creditReduction, refundAmount = refund, refundMethod = refundMethod, byUser = byUser
        )
        val returnId = db.returns().insert(ret)
        db.returns().insertItems(returnItems.map { it.copy(returnId = returnId) })
        movements.forEach { db.sales().insertMovement(it) }

        db.sales().updateSale(
            sale.copy(returnedAmount = sale.returnedAmount + amountTotal, paidAmount = sale.paidAmount - refund)
        )
        if (refund > 0) {
            val cur = mainCurrency()
            db.sales().insertPayment(
                Payment(
                    saleId = saleId, customerId = sale.customerId, method = refundMethod,
                    reference = "Remboursement retour #$returnId", currency = cur,
                    amountReceived = -refund, amountInMain = -refund, note = reason
                )
            )
        }
        ret.copy(id = returnId)
    }

    /** Annule une vente (sans retour préalable) : le stock revient, l'argent encaissé est remboursé, la trace reste. */
    suspend fun cancelSale(saleId: Long, reason: String, refundMethod: String = "ESPECES") = db.withTransaction {
        val sale = db.sales().get(saleId) ?: throw SaleException("Vente introuvable.")
        if (sale.status != SaleStatus.VALIDATED) throw SaleException("Cette vente est déjà annulée.")
        if (sale.returnedAmount > 0) throw SaleException("Cette vente a des retours : annulation impossible.")
        for (item in db.sales().itemsOf(saleId)) {
            if (item.phoneUnitId != null) db.phoneUnits().setStatus(item.phoneUnitId, UnitStatus.IN_STOCK)
            else db.products().increment(item.productId, item.quantity)
            db.sales().insertMovement(
                StockMovement(
                    productId = item.productId, phoneUnitId = item.phoneUnitId, type = "ANNULATION",
                    quantityDelta = item.quantity, refType = "VENTE", refId = saleId, note = reason
                )
            )
        }
        if (sale.paidAmount > 0) {
            val cur = mainCurrency()
            db.sales().insertPayment(
                Payment(
                    saleId = saleId, customerId = sale.customerId, method = refundMethod,
                    reference = "Annulation ${sale.number}", currency = cur,
                    amountReceived = -sale.paidAmount, amountInMain = -sale.paidAmount, note = reason
                )
            )
        }
        db.sales().updateSale(
            sale.copy(status = SaleStatus.CANCELLED, cancelledAt = System.currentTimeMillis(), cancelReason = reason)
        )
    }

    /**
     * Encaisse un paiement d'un client sur ses dettes, de la plus ancienne à la plus récente.
     * Ce n'est pas une vente. Un montant supérieur à la dette totale est refusé.
     */
    suspend fun payCustomerDebt(customerId: Long, amount: Long, method: String, reference: String = ""): Int =
        db.withTransaction {
            if (amount <= 0) throw SaleException("Montant invalide.")
            val debts = db.sales().openDebtsOf(customerId)
            val totalDebt = debts.sumOf { it.total - it.returnedAmount - it.paidAmount }
            if (amount > totalDebt) throw SaleException("Le montant dépasse la dette du client (${FinanceCalculator.formatMinor(totalDebt)}).")
            var left = amount
            var touched = 0
            val cur = mainCurrency()
            for (s in debts) {
                if (left <= 0) break
                val due = s.total - s.returnedAmount - s.paidAmount
                val part = minOf(due, left)
                if (db.sales().addToPaid(s.id, part) == 0) throw SaleException("Paiement refusé sur ${s.number}.")
                db.sales().insertPayment(
                    Payment(
                        saleId = s.id, customerId = customerId, method = method, reference = reference,
                        currency = cur, amountReceived = part, amountInMain = part, note = "Remboursement de dette"
                    )
                )
                left -= part
                touched++
            }
            touched
        }
}
