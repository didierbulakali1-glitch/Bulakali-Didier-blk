package com.didi.app.domain

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import com.didi.app.data.DidiDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Sauvegarde = copie du fichier de base de données SQLite (non chiffrée : protégez le fichier comme vos données).
 * Restauration = vérification d'intégrité, copie de sécurité de la base actuelle, remplacement, redémarrage.
 */
object BackupService {
    private const val DB_NAME = "didi.db"

    class BackupException(message: String) : Exception(message)

    /** Écrit une copie cohérente de la base dans l'emplacement choisi (Storage Access Framework). */
    suspend fun backupTo(context: Context, db: DidiDatabase, target: Uri) = withContext(Dispatchers.IO) {
        // vide le journal WAL dans le fichier principal pour que la copie soit complète
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { it.moveToFirst() }
        val src = context.getDatabasePath(DB_NAME)
        context.contentResolver.openOutputStream(target)?.use { out -> src.inputStream().use { it.copyTo(out) } }
            ?: throw BackupException("Impossible d'écrire dans l'emplacement choisi.")
    }

    /** Vérifie qu'un fichier est une sauvegarde DIDI intacte. Renvoie le fichier temporaire vérifié. */
    suspend fun verify(context: Context, source: Uri): File = withContext(Dispatchers.IO) {
        val tmp = File(context.cacheDir, "restore-check.db")
        tmp.delete()
        context.contentResolver.openInputStream(source)?.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            ?: throw BackupException("Fichier illisible.")
        val header = tmp.inputStream().use { s -> ByteArray(16).also { s.read(it) } }
        if (String(header, Charsets.ISO_8859_1) != "SQLite format 3\u0000") {
            tmp.delete(); throw BackupException("Ce fichier n'est pas une sauvegarde DIDI.")
        }
        val check = SQLiteDatabase.openDatabase(tmp.path, null, SQLiteDatabase.OPEN_READONLY)
        try {
            check.rawQuery("PRAGMA integrity_check", null).use { c ->
                if (!c.moveToFirst() || c.getString(0) != "ok") throw BackupException("La sauvegarde est endommagée.")
            }
            val tables = mutableSetOf<String>()
            check.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c ->
                while (c.moveToNext()) tables += c.getString(0)
            }
            val required = listOf("products", "sales", "sale_items", "customers", "app_settings")
            if (!tables.containsAll(required)) throw BackupException("Cette base ne ressemble pas à une base DIDI.")
        } catch (e: BackupException) {
            tmp.delete(); throw e
        } catch (e: Exception) {
            tmp.delete(); throw BackupException("Vérification impossible : ${e.message}")
        } finally {
            check.close()
        }
        tmp
    }

    /** Remplace la base actuelle par la sauvegarde vérifiée. L'application doit ensuite redémarrer. */
    suspend fun restore(context: Context, verified: File) = withContext(Dispatchers.IO) {
        val dbFile = context.getDatabasePath(DB_NAME)
        // copie de sécurité de l'état actuel
        val safety = File(context.filesDir, "avant-restauration.db")
        if (dbFile.exists()) dbFile.copyTo(safety, overwrite = true)
        DidiDatabase.close()
        File(dbFile.path + "-wal").delete()
        File(dbFile.path + "-shm").delete()
        verified.copyTo(dbFile, overwrite = true)
        verified.delete()
    }
}
