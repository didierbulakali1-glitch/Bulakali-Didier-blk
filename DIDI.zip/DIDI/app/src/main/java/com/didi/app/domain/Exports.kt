package com.didi.app.domain

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.didi.app.data.DidiDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File

/**
 * CSV compatible Excel français : séparateur ";" et BOM UTF-8.
 */
object CsvExport {
    private fun esc(v: String): String {
        val needs = v.contains(';') || v.contains('"') || v.contains('\n')
        val s = v.replace("\"", "\"\"")
        return if (needs) "\"$s\"" else s
    }

    fun build(header: List<String>, rows: List<List<String>>): ByteArray {
        val sb = StringBuilder("﻿")
        sb.append(header.joinToString(";") { esc(it) }).append("\r\n")
        rows.forEach { r -> sb.append(r.joinToString(";") { esc(it) }).append("\r\n") }
        return sb.toString().toByteArray(Charsets.UTF_8)
    }

    private fun m(v: Long) = FinanceCalculator.formatMinor(v)

    suspend fun sales(db: DidiDatabase, from: Long, to: Long): ByteArray {
        val customers = db.customers().observeAll().first().associateBy { it.id }
        val rows = db.sales().observeBetween(from, to).first().map {
            listOf(
                it.number, formatDateTime(it.createdAt), it.status, customers[it.customerId]?.fullName.orEmpty(),
                m(it.subtotal), m(it.discountTotal), m(it.total), m(it.returnedAmount), m(it.paidAmount),
                m(FinanceCalculator.balance(it.total - it.returnedAmount, it.paidAmount)),
                it.currency, it.paymentMethod, m(it.total - it.costTotal), it.sellerName
            )
        }
        return build(
            listOf("Numero", "Date", "Statut", "Client", "Sous-total", "Remises", "Total", "Retours", "Paye", "Solde",
                "Devise", "Mode de paiement", "Benefice brut estime", "Vendeur"), rows
        )
    }

    suspend fun products(db: DidiDatabase): ByteArray {
        val cats = db.categories().observeAll().first().associateBy { it.id }
        val units = db.products().observeUnitCounts().first().associate { it.productId to it.n }
        val rows = db.products().observeActive().first().map {
            listOf(
                it.name, it.sku.orEmpty(), it.barcode.orEmpty(), cats[it.categoryId]?.name.orEmpty(), it.brand, it.model,
                m(it.costPrice), m(it.salePrice), (if (it.tracksImei) units[it.id] ?: 0 else it.stockQty).toString(),
                it.minStock.toString(), it.condition, it.location
            )
        }
        return build(
            listOf("Nom", "SKU", "Code-barres", "Categorie", "Marque", "Modele", "Prix achat", "Prix vente",
                "Stock", "Seuil", "Etat", "Emplacement"), rows
        )
    }

    suspend fun customers(db: DidiDatabase): ByteArray {
        val rows = db.customers().observeAll().first().map { listOf(it.fullName, it.phone, it.address, it.notes, formatDate(it.createdAt)) }
        return build(listOf("Nom", "Telephone", "Adresse", "Notes", "Cree le"), rows)
    }

    suspend fun expenses(db: DidiDatabase, from: Long, to: Long): ByteArray {
        val cats = db.expenses().observeCategories().first().associateBy { it.id }
        val rows = db.expenses().observeBetween(from, to).first().map {
            listOf(formatDate(it.date), cats[it.categoryId]?.name.orEmpty(), it.description, m(it.amount), it.currency,
                m(it.amountInMain), it.method, it.reference)
        }
        return build(listOf("Date", "Categorie", "Description", "Montant", "Devise", "Montant (devise principale)", "Mode", "Reference"), rows)
    }

    suspend fun units(db: DidiDatabase): ByteArray {
        val products = db.products().observeActive().first().associateBy { it.id }
        val rows = mutableListOf<List<String>>()
        products.values.filter { it.tracksImei }.forEach { p ->
            db.phoneUnits().observeAllOf(p.id).first().forEach { u ->
                rows += listOf(p.name, u.imei1, u.imei2.orEmpty(), u.serial.orEmpty(), u.color, u.storage, u.condition,
                    m(u.costPrice), m(u.salePrice), u.status, formatDate(u.purchasedAt))
            }
        }
        return build(listOf("Modele", "IMEI 1", "IMEI 2", "Serie", "Couleur", "Stockage", "Etat", "Prix achat", "Prix vente", "Statut", "Achete le"), rows)
    }
}

/** PDF texte multi-pages (rapports, relevés de compte). */
object PdfText {
    suspend fun create(context: Context, fileName: String, title: String, lines: List<String>): File =
        withContext(Dispatchers.IO) {
            val w = 595; val h = 842; val margin = 40f
            val doc = PdfDocument()
            val paint = Paint().apply { textSize = 11f; isAntiAlias = true }
            val bold = Paint(paint).apply { typeface = Typeface.DEFAULT_BOLD; textSize = 15f }
            var pageNo = 1
            var page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create())
            var y = margin + 10
            page.canvas.drawText(title, margin, y, bold)
            y += 28
            for (raw in lines) {
                var line = raw
                // coupe les lignes trop longues
                while (true) {
                    val n = paint.breakText(line, true, w - 2 * margin, null)
                    val part = if (n < line.length) line.take(n) else line
                    if (y > h - margin) {
                        doc.finishPage(page); pageNo++
                        page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create())
                        y = margin + 10
                    }
                    page.canvas.drawText(part, margin, y, paint)
                    y += 16
                    if (n >= line.length) break
                    line = line.substring(n)
                }
            }
            doc.finishPage(page)
            val dir = File(context.cacheDir, "receipts").apply { mkdirs() }
            val file = File(dir, fileName)
            file.outputStream().use { doc.writeTo(it) }
            doc.close()
            file
        }
}
