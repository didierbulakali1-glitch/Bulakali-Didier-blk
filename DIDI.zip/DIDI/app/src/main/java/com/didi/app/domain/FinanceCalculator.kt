package com.didi.app.domain

import java.math.BigDecimal
import java.math.RoundingMode

/**
 * Tous les montants de DIDI sont stockés en "centièmes" (Long) : 12,50 USD = 1250.
 * Cela évite les erreurs d'arrondi des Double et permet les SUM() en SQL.
 * Les conversions passent par BigDecimal avec arrondi HALF_UP contrôlé.
 */
object FinanceCalculator {

    /** Convertit une saisie "12,50" ou "12.5" en centièmes. Renvoie null si invalide. */
    fun parseToMinor(input: String): Long? {
        val cleaned = input.trim().replace(" ", "").replace(',', '.')
        if (cleaned.isEmpty()) return null
        return try {
            BigDecimal(cleaned).setScale(2, RoundingMode.HALF_UP).movePointRight(2).longValueExact()
        } catch (e: Exception) {
            null
        }
    }

    fun formatMinor(minor: Long): String {
        val bd = BigDecimal.valueOf(minor, 2)
        return bd.toPlainString()
    }

    /** Total d'une ligne : prix unitaire x quantité - remise (remise en centièmes, sur la ligne). */
    fun lineTotal(unitPrice: Long, quantity: Int, discount: Long = 0L): Long {
        require(quantity > 0) { "Quantité invalide" }
        require(unitPrice >= 0) { "Prix invalide" }
        val gross = Math.multiplyExact(unitPrice, quantity.toLong())
        require(discount in 0..gross) { "Remise invalide" }
        return gross - discount
    }

    /** Remise en pourcentage (ex. 10 = 10 %) convertie en montant, arrondie à 0,01. */
    fun percentDiscount(amount: Long, percent: Int): Long {
        require(percent in 0..100) { "Pourcentage invalide" }
        return BigDecimal.valueOf(amount)
            .multiply(BigDecimal(percent))
            .divide(BigDecimal(100), 0, RoundingMode.HALF_UP)
            .longValueExact()
    }

    /** Bénéfice brut = chiffre d'affaires net - coût des marchandises vendues. */
    fun grossProfit(netRevenue: Long, cogs: Long): Long = netRevenue - cogs

    /** Bénéfice net estimé = bénéfice brut - dépenses professionnelles. */
    fun netProfit(grossProfit: Long, expenses: Long): Long = grossProfit - expenses

    /** Solde restant d'une vente ou dette. Jamais négatif. */
    fun balance(total: Long, paid: Long): Long = (total - paid).coerceAtLeast(0L)

    /** Un paiement ne peut pas dépasser le solde restant. */
    fun canApplyPayment(balance: Long, payment: Long): Boolean = payment > 0 && payment <= balance

    /**
     * Convertit un montant entre USD et CDF.
     * [rateCdfPerUsd] = nombre de CDF pour 1 USD (taux saisi manuellement, ex. 2800.00 -> 280000).
     */
    fun convert(amount: Long, from: Currency, to: Currency, rateCdfPerUsd: Long): Long {
        if (from == to) return amount
        require(rateCdfPerUsd > 0) { "Taux de change manquant" }
        val a = BigDecimal.valueOf(amount)
        val r = BigDecimal.valueOf(rateCdfPerUsd, 2)
        val result = if (from == Currency.USD) a.multiply(r) else a.divide(r, 0, RoundingMode.HALF_UP)
        return result.setScale(0, RoundingMode.HALF_UP).longValueExact()
    }

    /** Valeur du stock au coût d'achat moyen enregistré par produit (méthode simple et documentée). */
    fun stockValue(quantity: Int, unitCost: Long): Long = Math.multiplyExact(quantity.toLong(), unitCost)

    /** Validation Luhn d'un IMEI à 15 chiffres. */
    fun isValidImei(imei: String): Boolean {
        if (imei.length != 15 || !imei.all { it.isDigit() }) return false
        var sum = 0
        for (i in imei.indices) {
            var d = imei[14 - i] - '0'
            if (i % 2 == 1) {
                d *= 2
                if (d > 9) d -= 9
            }
            sum += d
        }
        return sum % 10 == 0
    }
}

enum class Currency { USD, CDF }
