package com.didi.app.domain

import java.util.Calendar

/** Modes de paiement proposés partout dans l'application. */
object PayMethods {
    val ALL = listOf(
        "ESPECES" to "Espèces", "MOBILE_MONEY" to "Mobile Money", "VIREMENT" to "Virement",
        "CARTE" to "Carte", "AUTRE" to "Autre"
    )

    fun label(key: String): String = ALL.firstOrNull { it.first == key }?.second ?: key
}

/** Ajoute des mois à une date (utilisé pour calculer la fin d'une garantie). */
fun addMonths(ms: Long, months: Int): Long =
    Calendar.getInstance().apply { timeInMillis = ms; add(Calendar.MONTH, months) }.timeInMillis
