package com.didi.app.domain

import androidx.room.withTransaction
import com.didi.app.data.DidiDatabase
import com.didi.app.data.PhoneUnit
import com.didi.app.data.Purchase
import com.didi.app.data.PurchaseItem
import com.didi.app.data.PurchasePayment
import com.didi.app.data.SettingKeys
import com.didi.app.data.StockMovement
import java.math.BigDecimal
import java.math.RoundingMode

data class PurchaseLine(
    val productId: Long,
    val quantity: Int,               // ignoré pour un produit à IMEI : la quantité = nombre d'IMEI
    val unitCost: Long,
    val imeis: List<String> = emptyList(),
    val color: String = "",
    val storage: String = "",
    val condition: String = "NEUF"
)

data class PurchaseRequest(
    val clientToken: String,         // empêche la double entrée de stock
    val supplierId: Long,
    val invoiceRef: String = "",
    val lines: List<PurchaseLine>,
    val extraFees: Long = 0,
    val paid: Long = 0,
    val method: String = "ESPECES"
)

class PurchaseService(private val db: DidiDatabase) {

    /**
     * Réceptionne un achat : stock augmenté, coût moyen recalculé, IMEI enregistrés.
     * Les frais supplémentaires sont répartis au prorata sur le coût des articles (ils entrent dans le coût de revient).
     */
    suspend fun receive(req: PurchaseRequest): Purchase = db.withTransaction {
        db.purchases().findByToken(req.clientToken)?.let { return@withTransaction it }
        if (req.lines.isEmpty()) throw SaleException("Ajoutez au moins un produit à l'achat.")
        if (req.extraFees < 0 || req.paid < 0) throw SaleException("Montant négatif interdit.")
        db.suppliers().get(req.supplierId) ?: throw SaleException("Fournisseur introuvable.")
        val main = db.settings().get(SettingKeys.MAIN_CURRENCY) ?: "USD"

        data class Prepared(val line: PurchaseLine, val qty: Int, val imeis: List<String>)
        val prepared = req.lines.map { l ->
            val p = db.products().get(l.productId) ?: throw SaleException("Produit introuvable.")
            if (l.unitCost < 0) throw SaleException("Prix d'achat invalide pour « ${p.name} ».")
            if (p.tracksImei) {
                val imeis = l.imeis.map { it.trim() }.filter { it.isNotEmpty() }
                if (imeis.isEmpty()) throw SaleException("Saisissez les IMEI pour « ${p.name} ».")
                if (imeis.toSet().size != imeis.size) throw SaleException("IMEI en double dans la saisie.")
                imeis.forEach { imei ->
                    if (!imei.all { it.isDigit() } || imei.length != 15) throw SaleException("IMEI invalide : $imei")
                    if (db.phoneUnits().findByImei(imei) != null) throw SaleException("IMEI déjà enregistré : $imei")
                }
                Prepared(l, imeis.size, imeis)
            } else {
                if (l.quantity <= 0) throw SaleException("Quantité invalide pour « ${p.name} ».")
                Prepared(l, l.quantity, emptyList())
            }
        }

        val itemsTotal = prepared.sumOf { it.line.unitCost * it.qty }
        val total = itemsTotal + req.extraFees
        if (req.paid > total) throw SaleException("Le montant payé dépasse le total de l'achat.")

        val now = System.currentTimeMillis()
        val purchaseId = db.purchases().insert(
            Purchase(
                clientToken = req.clientToken, supplierId = req.supplierId, createdAt = now,
                invoiceRef = req.invoiceRef, itemsTotal = itemsTotal, extraFees = req.extraFees,
                total = total, paidAmount = req.paid, currency = main
            )
        )

        val items = mutableListOf<PurchaseItem>()
        for (pr in prepared) {
            val p = db.products().get(pr.line.productId)!!
            // frais répartis au prorata du prix unitaire (arrondi contrôlé)
            val feePerUnit = if (itemsTotal == 0L || req.extraFees == 0L) 0L
            else BigDecimal(req.extraFees).multiply(BigDecimal(pr.line.unitCost))
                .divide(BigDecimal(itemsTotal), 0, RoundingMode.HALF_UP).longValueExact()
            val effectiveCost = pr.line.unitCost + feePerUnit

            if (p.tracksImei) {
                pr.imeis.forEach { imei ->
                    val unitId = db.phoneUnits().insert(
                        PhoneUnit(
                            productId = p.id, imei1 = imei, color = pr.line.color, storage = pr.line.storage,
                            condition = pr.line.condition, costPrice = effectiveCost, salePrice = p.salePrice,
                            purchasedAt = now, supplierId = req.supplierId, warrantyMonths = p.warrantyMonths
                        )
                    )
                    db.products().insertMovement(
                        StockMovement(productId = p.id, phoneUnitId = unitId, type = "ACHAT", quantityDelta = 1,
                            refType = "ACHAT", refId = purchaseId)
                    )
                }
            } else {
                val newQty = p.stockQty + pr.qty
                val newCost = if (p.stockQty <= 0) effectiveCost
                else BigDecimal(p.stockQty.toLong() * p.costPrice + pr.qty.toLong() * effectiveCost)
                    .divide(BigDecimal(newQty), 0, RoundingMode.HALF_UP).longValueExact()
                db.products().setStockAndCost(p.id, newQty, newCost)
                db.products().insertMovement(
                    StockMovement(productId = p.id, type = "ACHAT", quantityDelta = pr.qty,
                        refType = "ACHAT", refId = purchaseId)
                )
            }
            items += PurchaseItem(purchaseId = purchaseId, productId = p.id, quantity = pr.qty, unitCost = pr.line.unitCost)
        }
        db.purchases().insertItems(items)
        if (req.paid > 0) {
            db.purchases().insertPayment(PurchasePayment(purchaseId = purchaseId, amount = req.paid, method = req.method))
        }
        db.purchases().get(purchaseId)!!
    }

    /** Paiement d'un fournisseur sur un achat. Refusé s'il dépasse le solde dû. */
    suspend fun payPurchase(purchaseId: Long, amount: Long, method: String, note: String = "") = db.withTransaction {
        if (amount <= 0) throw SaleException("Montant invalide.")
        if (db.purchases().addToPaid(purchaseId, amount) == 0) throw SaleException("Le paiement dépasse le solde dû.")
        db.purchases().insertPayment(PurchasePayment(purchaseId = purchaseId, amount = amount, method = method, note = note))
    }
}
