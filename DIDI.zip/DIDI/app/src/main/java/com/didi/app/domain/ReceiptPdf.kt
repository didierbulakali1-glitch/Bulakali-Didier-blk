package com.didi.app.domain

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.didi.app.data.DidiDatabase
import com.didi.app.data.Sale
import com.didi.app.data.SettingKeys
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class Row(val left: String, val right: String = "", val bold: Boolean = false)

object ReceiptPdf {

    /** Génère le reçu d'une vente en PDF dans le cache de l'application et renvoie le fichier. */
    suspend fun create(context: Context, db: DidiDatabase, sale: Sale): File = withContext(Dispatchers.IO) {
        val items = db.sales().itemsOf(sale.id)
        val shop = db.settings().get(SettingKeys.SHOP_NAME) ?: "DIDI"
        val phone = db.settings().get(SettingKeys.SHOP_PHONE).orEmpty()
        val address = db.settings().get(SettingKeys.SHOP_ADDRESS).orEmpty()
        val footer = db.settings().get(SettingKeys.RECEIPT_TEXT).orEmpty()
        val customer = sale.customerId?.let { db.customers().get(it) }
        val cur = sale.currency
        fun m(v: Long) = FinanceCalculator.formatMinor(v) + " " + cur

        val rows = mutableListOf<Row>()
        rows += Row(shop, bold = true)
        if (phone.isNotBlank()) rows += Row("Tél : $phone")
        if (address.isNotBlank()) rows += Row(address)
        rows += Row("")
        rows += Row("Reçu n° ${sale.number}", bold = true)
        rows += Row(SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date(sale.createdAt)))
        if (customer != null) rows += Row("Client : ${customer.fullName}")
        rows += Row("")
        items.forEach { it ->
            rows += Row("${it.productName} x${it.quantity}", m(it.lineTotal))
            if (it.discount > 0) rows += Row("   remise", "-" + FinanceCalculator.formatMinor(it.discount))
            if (!it.imei.isNullOrBlank()) rows += Row("   IMEI : ${it.imei}")
        }
        rows += Row("")
        if (sale.discountTotal > 0) rows += Row("Remises", "-" + m(sale.discountTotal))
        rows += Row("TOTAL", m(sale.total), bold = true)
        rows += Row("Payé", m(sale.paidAmount))
        val balance = FinanceCalculator.balance(sale.total, sale.paidAmount)
        if (balance > 0) rows += Row("Reste à payer", m(balance), bold = true)
        rows += Row("Mode : ${sale.paymentMethod}")
        if (footer.isNotBlank()) {
            rows += Row("")
            rows += Row(footer)
        }

        val width = 300
        val height = 60 + rows.size * 16
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(width, height, 1).create())
        val canvas = page.canvas
        val paint = Paint().apply { textSize = 11f; isAntiAlias = true }
        var y = 30f
        for (r in rows) {
            paint.typeface = if (r.bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            val rightW = if (r.right.isEmpty()) 0f else paint.measureText(r.right) + 6f
            val maxLeft = width - 32f - rightW
            var text = r.left
            val fit = paint.breakText(text, true, maxLeft, null)
            if (fit < text.length) text = text.take((fit - 1).coerceAtLeast(0)) + "…"
            canvas.drawText(text, 16f, y, paint)
            if (r.right.isNotEmpty()) canvas.drawText(r.right, width - 16f - paint.measureText(r.right), y, paint)
            y += 16f
        }
        doc.finishPage(page)

        val dir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val file = File(dir, "recu-${sale.number}.pdf")
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        file
    }

    /** Ouvre le partage Android (WhatsApp, e-mail, enregistrement, impression...). */
    fun share(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Partager le reçu"))
    }
}
