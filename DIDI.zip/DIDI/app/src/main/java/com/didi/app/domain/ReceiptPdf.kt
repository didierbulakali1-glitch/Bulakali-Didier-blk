package com.didi.app.domain

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.didi.app.data.DidiDatabase
import com.didi.app.data.Sale
import com.didi.app.data.SettingKeys
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class Row(val left: String, val right: String = "", val bold: Boolean = false)

object ReceiptPdf {

    /** Génère le reçu d'une vente en PDF dans le cache de l'application et renvoie le fichier. */
    suspend fun create(context: Context, db: DidiDatabase, sale: Sale): File = withContext(Dispatchers.IO) {
        val items = db.sales().itemsOf(sale.id)
        val shop = db.settings().get(SettingKeys.SHOP_NAME) ?: "DIDI"
        val phone = db.settings().get(SettingKeys.SHOP_PHONE).orEmpty()
        val address = db.settings().get(SettingKeys.SHOP_ADDRESS).orEmpty()
        val footer = db.settings().get(SettingKeys.RECEIPT_TEXT).orEmpty()
        val logoPath = db.settings().get(SettingKeys.LOGO)
        val customer = sale.customerId?.let { db.customers().get(it) }
        val cur = sale.currency
        fun m(v: Long) = FinanceCalculator.formatMinor(v) + " " + cur

        val logo: Bitmap? = logoPath?.let {
            try {
                BitmapFactory.decodeFile(it, BitmapFactory.Options().apply { inSampleSize = 2 })
            } catch (e: Exception) { null }
        }

        val rows = mutableListOf<Row>()
        rows += Row(shop, bold = true)
        if (phone.isNotBlank()) rows += Row("Tél : $phone")
        if (address.isNotBlank()) rows += Row(address)
        rows += Row("")
        rows += Row("Reçu n° ${sale.number}", bold = true)
        rows += Row(SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date(sale.createdAt)))
        if (customer != null) rows += Row("Client : ${customer.fullName}")
        if (sale.sellerName.isNotBlank()) rows += Row("Vendeur : ${sale.sellerName}")
        rows += Row("")
        items.forEach { it ->
            rows += Row("${it.productName} x${it.quantity}", m(it.lineTotal))
            if (it.discount > 0) rows += Row("   remise", "-" + FinanceCalculator.formatMinor(it.discount))
            if (!it.imei.isNullOrBlank()) rows += Row("   IMEI : ${it.imei}")
        }
        rows += Row("")
        if (sale.discountTotal > 0) rows += Row("Remises", "-" + m(sale.discountTotal))
        rows += Row("TOTAL", m(sale.total), bold = true)
        if (sale.returnedAmount > 0) rows += Row("Retours", "-" + m(sale.returnedAmount))
        rows += Row("Payé", m(sale.paidAmount))
        val balance = FinanceCalculator.balance(sale.total - sale.returnedAmount, sale.paidAmount)
        if (balance > 0) rows += Row("Reste à payer", m(balance), bold = true)
        rows += Row("Mode : ${PayMethods.label(sale.paymentMethod)}")
        if (footer.isNotBlank()) {
            rows += Row("")
            rows += Row(footer)
        }

        val width = 300
        val logoH = if (logo != null) 56 else 0
        val height = 60 + logoH + rows.size * 16
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(width, height, 1).create())
        val canvas = page.canvas
        val paint = Paint().apply { textSize = 11f; isAntiAlias = true }
        var y = 30f + logoH
        if (logo != null) {
            val h = 44
            val w = (logo.width * h / logo.height.coerceAtLeast(1)).coerceIn(1, width - 32)
            canvas.drawBitmap(Bitmap.createScaledBitmap(logo, w, h, true), 16f, 10f, null)
        }
        for (r in rows) {
            paint.typeface = if (r.bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            val rightW = if (r.right.isEmpty()) 0f else paint.measureText(r.right) + 6f
            val maxLeft = width - 32f - rightW
            var text = r.left
            val fit = paint.breakText(text, true, maxLeft, null)
            if (fit < text.length) text = text.take((fit - 1).coerceAtLeast(0)) + "…"
            canvas.drawText(text, 16f, y, paint)
            if (r.right.isNotEmpty()) canvas.drawText(r.right, width - 16f - paint.measureText(r.right), y, paint)
            y += 16f
        }
        doc.finishPage(page)

        val dir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val file = File(dir, "recu-${sale.number}.pdf")
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        file
    }

    /** Ouvre le partage Android (WhatsApp, e-mail, enregistrement, impression...). */
    fun share(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Partager le document"))
    }

    /**
     * Ouvre la boîte d'impression d'Android. Elle propose les imprimantes détectées par le système
     * et toujours « Enregistrer au format PDF ». DIDI ne se connecte à aucune imprimante lui-même.
     */
    fun print(context: Context, file: File) {
        val pm = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print(file.name, PdfPrintAdapter(file), null)
    }
}

private class PdfPrintAdapter(private val file: File) : PrintDocumentAdapter() {
    override fun onLayout(
        oldAttributes: PrintAttributes?, newAttributes: PrintAttributes?,
        cancellationSignal: CancellationSignal?, callback: LayoutResultCallback?, extras: Bundle?
    ) {
        if (cancellationSignal?.isCanceled == true) { callback?.onLayoutCancelled(); return }
        callback?.onLayoutFinished(
            PrintDocumentInfo.Builder(file.name)
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                .build(),
            true
        )
    }

    override fun onWrite(
        pages: Array<out PageRange>?, destination: ParcelFileDescriptor?,
        cancellationSignal: CancellationSignal?, callback: WriteResultCallback?
    ) {
        try {
            file.inputStream().use { input ->
                FileOutputStream(destination!!.fileDescriptor).use { out -> input.copyTo(out) }
            }
            callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
        } catch (e: Exception) {
            callback?.onWriteFailed(e.message)
        }
    }
}
