package com.didi.app.domain

import com.didi.app.data.DidiDatabase
import com.didi.app.data.Sale
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Définitions (toutes calculées à partir des données enregistrées) :
 * - Chiffre d'affaires net = ventes validées - retours de la période
 * - Coût des marchandises vendues (CMV) = coût des articles vendus - coût des articles retournés et remis en stock
 * - Bénéfice brut = CA net - CMV ; Bénéfice net estimé = bénéfice brut - dépenses de la période
 * - Trésorerie encaissée = paiements reçus - remboursements (ce n'est pas le CA)
 */
data class Summary(
    val revenue: Long, val cogs: Long, val gross: Long, val expenses: Long, val net: Long,
    val cash: Long, val salesCount: Long, val returns: Long
)

fun summaryFlow(db: DidiDatabase, from: Long, to: Long): Flow<Summary> {
    val r = db.reports()
    return combine(
        listOf(
            r.salesTotal(from, to), r.returnsAmount(from, to), r.salesCost(from, to), r.returnsCost(from, to),
            db.expenses().observeTotal(from, to), r.cashIn(from, to), r.salesCount(from, to).map { it.toLong() }
        )
    ) { a ->
        val revenue = a[0] - a[1]
        val cogs = a[2] - a[3]
        val gross = FinanceCalculator.grossProfit(revenue, cogs)
        Summary(revenue, cogs, gross, a[4], FinanceCalculator.netProfit(gross, a[4]), a[5], a[6], a[1])
    }
}

// ---------- Périodes et graphiques ----------

fun startOfDay(daysAgo: Int = 0): Long = Calendar.getInstance().apply {
    add(Calendar.DAY_OF_YEAR, -daysAgo)
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun startOfMonth(monthsAgo: Int = 0): Long = Calendar.getInstance().apply {
    add(Calendar.MONTH, -monthsAgo)
    set(Calendar.DAY_OF_MONTH, 1)
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun startOfWeek(weeksAgo: Int = 0): Long = Calendar.getInstance().apply {
    firstDayOfWeek = Calendar.MONDAY
    add(Calendar.WEEK_OF_YEAR, -weeksAgo)
    set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun endOfDay(ms: Long): Long = Calendar.getInstance().apply {
    timeInMillis = ms
    set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
}.timeInMillis

/** Convertit "jj/mm/aaaa" en début de journée, ou null si invalide. */
fun parseDate(s: String): Long? = try {
    val f = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).apply { isLenient = false }
    f.parse(s.trim())?.time
} catch (e: Exception) { null }

fun formatDate(ms: Long): String = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(ms))
fun formatDateTime(ms: Long): String = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date(ms))

enum class ChartMode(val label: String) { DAYS("Jours"), WEEKS("Semaines"), MONTHS("Mois") }

data class Bar(val label: String, val value: Long)

/** Regroupe les ventes validées par jour (7), semaine (8) ou mois (6) pour le graphique. */
fun chartBars(sales: List<Sale>, mode: ChartMode): List<Bar> {
    val valid = sales.filter { it.status == "VALIDEE" }
    val fmtDay = SimpleDateFormat("dd/MM", Locale.FRANCE)
    val fmtMonth = SimpleDateFormat("MMM", Locale.FRANCE)
    return when (mode) {
        ChartMode.DAYS -> (6 downTo 0).map { d ->
            val s = startOfDay(d); val e = endOfDay(s)
            Bar(fmtDay.format(Date(s)), valid.filter { it.createdAt in s..e }.sumOf { it.total - it.returnedAmount })
        }
        ChartMode.WEEKS -> (7 downTo 0).map { w ->
            val s = startOfWeek(w); val e = s + 7L * 24 * 3600 * 1000 - 1
            Bar(fmtDay.format(Date(s)), valid.filter { it.createdAt in s..e }.sumOf { it.total - it.returnedAmount })
        }
        ChartMode.MONTHS -> (5 downTo 0).map { m ->
            val s = startOfMonth(m); val e = startOfMonth(m - 1) - 1
            Bar(fmtMonth.format(Date(s)), valid.filter { it.createdAt in s..e }.sumOf { it.total - it.returnedAmount })
        }
    }
}

/** Début de la plage nécessaire pour le graphique. */
fun chartStart(mode: ChartMode): Long = when (mode) {
    ChartMode.DAYS -> startOfDay(6)
    ChartMode.WEEKS -> startOfWeek(7)
    ChartMode.MONTHS -> startOfMonth(5)
}
