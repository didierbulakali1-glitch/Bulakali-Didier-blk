package com.didi.app.domain

import androidx.room.withTransaction
import com.didi.app.data.DidiDatabase
import com.didi.app.data.Payment
import com.didi.app.data.Sale
import com.didi.app.data.SaleItem
import com.didi.app.data.SaleStatus
import com.didi.app.data.SettingKeys
import com.didi.app.data.StockMovement
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CartLine(
    val productId: Long,
    val quantity: Int,
    val unitPrice: Long,
    val discount: Long = 0,
    val phoneUnitId: Long? = null      // obligatoire pour un produit suivi par IMEI
)

data class CheckoutRequest(
    val clientToken: String,            // généré une seule fois à l'ouverture du panier
    val lines: List<CartLine>,
    val customerId: Long? = null,
    val sellerName: String = "",
    val paymentMethod: String = "ESPECES",
    val paymentReference: String = "",
    val paymentCurrency: Currency = Currency.USD,
    val amountReceived: Long = 0,       // dans paymentCurrency
    val dueDate: Long? = null
)

class SaleException(message: String) : Exception(message)

class SaleService(private val db: DidiDatabase) {

    /**
     * Valide une vente. Tout se passe dans UNE transaction : si une étape échoue,
     * rien n'est enregistré (ni vente, ni baisse de stock).
     * Un même clientToken ne peut pas être validé deux fois (double clic).
     */
    suspend fun checkout(req: CheckoutRequest): Sale = db.withTransaction {
        db.sales().findByToken(req.clientToken)?.let { return@withTransaction it }

        if (req.lines.isEmpty()) throw SaleException("Le panier est vide.")
        val mainCurrency = Currency.valueOf(db.settings().get(SettingKeys.MAIN_CURRENCY) ?: "USD")
        val allowNegative = db.settings().get(SettingKeys.ALLOW_NEGATIVE_STOCK) == "true"

        var subtotal = 0L
        var discountTotal = 0L
        var costTotal = 0L
        val pendingItems = mutableListOf<SaleItem>()
        val movements = mutableListOf<StockMovement>()

        for (line in req.lines) {
            val product = db.products().get(line.productId)
                ?: throw SaleException("Produit introuvable.")
            if (product.archived) throw SaleException("« ${product.name} » est archivé.")
            val lineTotal = try {
                FinanceCalculator.lineTotal(line.unitPrice, line.quantity, line.discount)
            } catch (e: IllegalArgumentException) {
                throw SaleException("Ligne invalide pour « ${product.name} » : ${e.message}")
            }

            var unitCost = product.costPrice
            var imei: String? = null
            if (product.tracksImei) {
                if (line.quantity != 1) throw SaleException("Un téléphone suivi par IMEI se vend à l'unité.")
                val unitId = line.phoneUnitId ?: throw SaleException("Choisissez l'appareil (IMEI) à vendre.")
                val unit = db.phoneUnits().get(unitId) ?: throw SaleException("Appareil introuvable.")
                if (unit.productId != product.id) throw SaleException("Cet IMEI ne correspond pas au produit.")
                if (db.phoneUnits().markSold(unitId) == 0) {
                    throw SaleException("L'appareil ${unit.imei1} n'est plus disponible.")
                }
                unitCost = unit.costPrice
                imei = unit.imei1
            } else {
                val ok = if (allowNegative) {
                    db.products().decrementForced(product.id, line.quantity); 1
                } else {
                    db.products().decrementIfAvailable(product.id, line.quantity)
                }
                if (ok == 0) throw SaleException("Stock insuffisant pour « ${product.name} ».")
            }

            subtotal += line.unitPrice * line.quantity
            discountTotal += line.discount
            costTotal += unitCost * line.quantity
            pendingItems += SaleItem(
                saleId = 0, productId = product.id, phoneUnitId = line.phoneUnitId, imei = imei,
                productName = product.name, quantity = line.quantity, unitPrice = line.unitPrice,
                discount = line.discount, lineTotal = lineTotal, unitCost = unitCost
            )
            movements += StockMovement(
                productId = product.id, phoneUnitId = line.phoneUnitId, type = "VENTE",
                quantityDelta = -line.quantity
            )
        }

        val total = subtotal - discountTotal

        // Paiement reçu, converti dans la devise principale avec le taux saisi manuellement
        var rate: Long? = null
        val paidInMain = if (req.amountReceived <= 0) 0L else {
            if (req.paymentCurrency != mainCurrency) {
                rate = db.settings().get(SettingKeys.RATE_CDF_PER_USD)?.toLongOrNull()
                    ?: throw SaleException("Renseignez d'abord le taux de change dans les paramètres.")
            }
            FinanceCalculator.convert(req.amountReceived, req.paymentCurrency, mainCurrency, rate ?: 1L)
        }
        if (paidInMain > total) throw SaleException("Le montant reçu dépasse le total de la vente.")
        if (paidInMain < total && req.customerId == null) {
            throw SaleException("Pour une vente à crédit, sélectionnez un client.")
        }

        val now = System.currentTimeMillis()
        val seq = db.sales().countAll() + 1
        val number = "V" + SimpleDateFormat("yyMMdd", Locale.FRANCE).format(Date(now)) + "-" + seq.toString().padStart(4, '0')

        val sale = Sale(
            number = number, clientToken = req.clientToken, createdAt = now,
            customerId = req.customerId, sellerName = req.sellerName,
            subtotal = subtotal, discountTotal = discountTotal, total = total,
            paidAmount = paidInMain, currency = mainCurrency.name,
            paymentMethod = req.paymentMethod, costTotal = costTotal,
            status = SaleStatus.VALIDATED, dueDate = req.dueDate
        )
        val saleId = db.sales().insertSale(sale)
        db.sales().insertItems(pendingItems.map { it.copy(saleId = saleId) })
        movements.forEach { db.sales().insertMovement(it.copy(refType = "VENTE", refId = saleId)) }
        if (paidInMain > 0) {
            db.sales().insertPayment(
                Payment(
                    saleId = saleId, customerId = req.customerId, method = req.paymentMethod,
                    reference = req.paymentReference, currency = req.paymentCurrency.name,
                    amountReceived = req.amountReceived, rateCdfPerUsd = rate, amountInMain = paidInMain
                )
            )
        }
        sale.copy(id = saleId)
    }

    /** Encaisse un paiement sur une dette existante : ce n'est PAS une nouvelle vente. */
    suspend fun payDebt(
        saleId: Long, customerId: Long?, amountInMain: Long, method: String, reference: String = ""
    ) = db.withTransaction {
        if (amountInMain <= 0) throw SaleException("Montant invalide.")
        if (db.sales().addToPaid(saleId, amountInMain) == 0) {
            throw SaleException("Le paiement dépasse le solde restant.")
        }
        val main = db.settings().get(SettingKeys.MAIN_CURRENCY) ?: "USD"
        db.sales().insertPayment(
            Payment(
                saleId = saleId, customerId = customerId, method = method, reference = reference,
                currency = main, amountReceived = amountInMain, amountInMain = amountInMain
            )
        )
    }
}
