package com.didi.app.domain

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.didi.app.data.AppUser
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Les codes PIN ne sont jamais stockés en clair : PBKDF2 + sel aléatoire. */
object PinHasher {
    private const val ITERATIONS = 60_000

    fun newSalt(): String {
        val b = ByteArray(16); SecureRandom().nextBytes(b)
        return Base64.getEncoder().encodeToString(b)
    }

    fun hash(pin: String, salt: String): String {
        val spec = PBEKeySpec(pin.toCharArray(), Base64.getDecoder().decode(salt), ITERATIONS, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return Base64.getEncoder().encodeToString(bytes)
    }

    fun verify(pin: String, salt: String, expected: String): Boolean =
        MessageDigest.isEqual(hash(pin, salt).toByteArray(), expected.toByteArray())

    fun isValidPin(pin: String) = pin.length in 4..8 && pin.all { it.isDigit() }
}

object Roles {
    const val ADMIN = "ADMIN"
    const val SELLER = "VENDEUR"
    const val STOCK = "STOCK"
    val ALL = listOf(ADMIN, SELLER, STOCK)
    fun label(r: String) = when (r) { ADMIN -> "Administrateur"; SELLER -> "Vendeur"; STOCK -> "Gestionnaire de stock"; else -> r }
}

/** Clés de droits (une par module). "sensitive" = retours, annulations, opérations financières sensibles. */
object Perm {
    val ALL = listOf(
        "dashboard" to "Tableau de bord", "pos" to "Caisse", "sales" to "Historique des ventes",
        "products" to "Produits", "phones" to "Téléphones / IMEI", "categories" to "Catégories",
        "customers" to "Clients", "debts" to "Dettes clients", "suppliers" to "Fournisseurs",
        "purchases" to "Achats", "expenses" to "Dépenses", "repairs" to "Garanties / réparations",
        "reports" to "Rapports", "sensitive" to "Opérations sensibles (retours, annulations)",
        "settings" to "Paramètres", "users" to "Utilisateurs", "backup" to "Sauvegardes", "features" to "Gestion des fonctionnalités"
    )

    fun defaultsFor(role: String): Set<String> = when (role) {
        Roles.ADMIN -> ALL.map { it.first }.toSet()
        Roles.SELLER -> setOf("pos", "sales", "customers", "debts", "phones", "repairs")
        Roles.STOCK -> setOf("products", "phones", "categories", "suppliers", "purchases")
        else -> emptySet()
    }

    fun parse(csv: String): Set<String> = csv.split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet()
    fun serialize(set: Set<String>): String = set.sorted().joinToString(",")
}

/**
 * Utilisateur connecté. Tant qu'aucun utilisateur n'est créé, l'application s'ouvre sans PIN
 * avec tous les droits (premier démarrage).
 */
object Session {
    var user by mutableStateOf<AppUser?>(null)
    var usersExist by mutableStateOf(false)

    val isAdmin: Boolean get() = user?.role == Roles.ADMIN || !usersExist
    fun can(key: String): Boolean {
        if (!usersExist) return true
        val u = user ?: return false
        return u.role == Roles.ADMIN || key in Perm.parse(u.permissions)
    }
    fun name(): String = user?.name.orEmpty()
}
