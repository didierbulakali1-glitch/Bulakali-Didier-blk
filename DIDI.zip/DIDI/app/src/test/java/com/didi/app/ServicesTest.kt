package com.didi.app

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.didi.app.data.Category
import com.didi.app.data.Customer
import com.didi.app.data.DidiDatabase
import com.didi.app.data.Product
import com.didi.app.data.SaleStatus
import com.didi.app.data.Supplier
import com.didi.app.data.UnitStatus
import com.didi.app.data.seedDefaultsIfNeeded
import com.didi.app.domain.AfterSaleService
import com.didi.app.domain.CartLine
import com.didi.app.domain.CheckoutRequest
import com.didi.app.domain.PurchaseLine
import com.didi.app.domain.PurchaseRequest
import com.didi.app.domain.PurchaseService
import com.didi.app.domain.ReturnLine
import com.didi.app.domain.SaleException
import com.didi.app.domain.SaleService
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

/** Montants en centimes : 1000 = 10,00. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ServicesTest {
    private lateinit var db: DidiDatabase
    private lateinit var sales: SaleService
    private lateinit var purchases: PurchaseService
    private lateinit var after: AfterSaleService
    private var supplierId = 0L
    private var accessoryCat = 0L
    private var phoneCat = 0L

    @Before
    fun setUp() = runBlocking<Unit> {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(ctx, DidiDatabase::class.java).allowMainThreadQueries().build()
        db.seedDefaultsIfNeeded()
        sales = SaleService(db); purchases = PurchaseService(db); after = AfterSaleService(db)
        supplierId = db.suppliers().insert(Supplier(name = "Fournisseur test"))
        accessoryCat = db.categories().insert(Category(name = "Test accessoires"))
        phoneCat = db.categories().insert(Category(name = "Test téléphones", isPhone = true))
    }

    @After
    fun tearDown() { db.close() }

    private suspend fun accessory(price: Long = 1000, cost: Long = 0, stock: Int = 0): Long =
        db.products().insert(Product(name = "Chargeur ${UUID.randomUUID()}", categoryId = accessoryCat, salePrice = price, costPrice = cost, stockQty = stock))

    private suspend fun phone(): Long =
        db.products().insert(Product(name = "Téléphone ${UUID.randomUUID()}", categoryId = phoneCat, salePrice = 10000, tracksImei = true))

    private suspend fun customer() = db.customers().insert(Customer(fullName = "Client test", phone = UUID.randomUUID().toString().take(9)))

    private fun buy(productId: Long, qty: Int, cost: Long, token: String = UUID.randomUUID().toString(), imeis: List<String> = emptyList(), fees: Long = 0, paid: Long = 0) =
        PurchaseRequest(token, supplierId, lines = listOf(PurchaseLine(productId, qty, cost, imeis)), extraFees = fees, paid = paid)

    private fun sell(lines: List<CartLine>, customerId: Long? = null, received: Long = Long.MAX_VALUE / 4, token: String = UUID.randomUUID().toString()) =
        CheckoutRequest(clientToken = token, lines = lines, customerId = customerId, amountReceived = received)

    @Test
    fun `un achat augmente le stock et calcule le cout moyen pondere`() = runBlocking<Unit> {
        val id = accessory()
        purchases.receive(buy(id, 10, 100))
        purchases.receive(buy(id, 10, 200))
        val p = db.products().get(id)!!
        assertEquals(20, p.stockQty)
        assertEquals(150L, p.costPrice)
    }

    @Test
    fun `le meme jeton d achat ne double pas le stock`() = runBlocking<Unit> {
        val id = accessory()
        val token = UUID.randomUUID().toString()
        purchases.receive(buy(id, 5, 100, token))
        purchases.receive(buy(id, 5, 100, token))
        assertEquals(5, db.products().get(id)!!.stockQty)
    }

    @Test
    fun `les frais supplementaires entrent dans le cout de revient`() = runBlocking<Unit> {
        val id = accessory()
        purchases.receive(buy(id, 10, 100, fees = 100))
        assertEquals(110L, db.products().get(id)!!.costPrice)
    }

    @Test
    fun `une vente paye en totalite diminue le stock`() = runBlocking<Unit> {
        val id = accessory(price = 1000, cost = 600, stock = 10)
        val s = sales.checkout(sell(listOf(CartLine(id, 3, 1000)), received = 3000))
        assertEquals(3000L, s.total)
        assertEquals(3000L, s.paidAmount)
        assertEquals(1800L, s.costTotal)
        assertEquals(7, db.products().get(id)!!.stockQty)
    }

    @Test
    fun `le meme jeton de vente ne cree qu une vente`() = runBlocking<Unit> {
        val id = accessory(stock = 10)
        val token = UUID.randomUUID().toString()
        val a = sales.checkout(sell(listOf(CartLine(id, 1, 1000)), received = 1000, token = token))
        val b = sales.checkout(sell(listOf(CartLine(id, 1, 1000)), received = 1000, token = token))
        assertEquals(a.id, b.id)
        assertEquals(9, db.products().get(id)!!.stockQty)
    }

    @Test
    fun `stock insuffisant refuse la vente et ne change rien`() = runBlocking<Unit> {
        val a = accessory(stock = 5)
        val b = accessory(stock = 1)
        val ex = assertThrows(SaleException::class.java) {
            runBlocking { sales.checkout(sell(listOf(CartLine(a, 2, 1000), CartLine(b, 2, 1000)), received = 4000)) }
        }
        assertTrue(ex.message!!.contains("Stock insuffisant"))
        assertEquals(5, db.products().get(a)!!.stockQty)   // la 1re ligne est annulee avec la transaction
        assertEquals(1, db.products().get(b)!!.stockQty)
    }

    @Test
    fun `vente a credit exige un client puis accepte des paiements partiels sans depasser le solde`() = runBlocking<Unit> {
        val id = accessory(stock = 10)
        assertThrows(SaleException::class.java) {
            runBlocking { sales.checkout(sell(listOf(CartLine(id, 1, 1000)), received = 400)) }
        }
        val c = customer()
        val s = sales.checkout(sell(listOf(CartLine(id, 1, 1000)), customerId = c, received = 400))
        assertEquals(400L, s.paidAmount)
        sales.payDebt(s.id, c, 300, "ESPECES")
        assertEquals(700L, db.sales().get(s.id)!!.paidAmount)
        assertThrows(SaleException::class.java) { runBlocking { sales.payDebt(s.id, c, 400, "ESPECES") } }
        sales.payDebt(s.id, c, 300, "ESPECES")
        assertEquals(1000L, db.sales().get(s.id)!!.paidAmount)
    }

    @Test
    fun `un montant recu superieur au total est refuse`() {
        runBlocking {
            val id = accessory(stock = 10)
            assertThrows(SaleException::class.java) {
                runBlocking { sales.checkout(sell(listOf(CartLine(id, 1, 1000)), received = 1500)) }
            }
        }
    }

    @Test
    fun `un telephone IMEI se vend une seule fois et l IMEI en double est refuse`() = runBlocking<Unit> {
        val pid = phone()
        val imei = "490154203237518"
        purchases.receive(buy(pid, 1, 5000, imeis = listOf(imei)))
        assertThrows(SaleException::class.java) { runBlocking { purchases.receive(buy(pid, 1, 5000, imeis = listOf(imei))) } }
        val unit = db.phoneUnits().findByImei(imei)!!
        sales.checkout(sell(listOf(CartLine(pid, 1, 10000, 0, unit.id)), received = 10000))
        assertEquals(UnitStatus.SOLD, db.phoneUnits().get(unit.id)!!.status)
        assertThrows(SaleException::class.java) {
            runBlocking { sales.checkout(sell(listOf(CartLine(pid, 1, 10000, 0, unit.id)), received = 10000)) }
        }
    }

    @Test
    fun `retour remet en stock ou non selon le choix et rembourse l argent`() = runBlocking<Unit> {
        val id = accessory(price = 1000, cost = 600, stock = 10)
        val s = sales.checkout(sell(listOf(CartLine(id, 4, 1000)), received = 4000))
        val item = db.sales().itemsOf(s.id).first()
        val r1 = after.returnItems(s.id, listOf(ReturnLine(item.id, 1, restock = true)), "Test")
        assertEquals(1000L, r1.amount)
        assertEquals(1000L, r1.refundAmount)
        assertEquals(7, db.products().get(id)!!.stockQty)
        after.returnItems(s.id, listOf(ReturnLine(item.id, 1, restock = false)), "Defectueux")
        assertEquals(7, db.products().get(id)!!.stockQty)           // defectueux : pas de remise en stock
        assertEquals(2000L, db.sales().get(s.id)!!.returnedAmount)
        assertThrows(SaleException::class.java) {
            runBlocking { after.returnItems(s.id, listOf(ReturnLine(item.id, 3, true)), "Trop") }
        }
    }

    @Test
    fun `annuler une vente remet le stock et rembourse`() = runBlocking<Unit> {
        val id = accessory(stock = 10)
        val s = sales.checkout(sell(listOf(CartLine(id, 2, 1000)), received = 2000))
        after.cancelSale(s.id, "Erreur de saisie")
        val after1 = db.sales().get(s.id)!!
        assertEquals(SaleStatus.CANCELLED, after1.status)
        assertEquals(10, db.products().get(id)!!.stockQty)
        assertThrows(SaleException::class.java) { runBlocking { after.cancelSale(s.id, "Encore") } }
    }

    @Test
    fun `paiement fournisseur refuse au dela du solde`() = runBlocking<Unit> {
        val id = accessory()
        val p = purchases.receive(buy(id, 10, 100, paid = 400))
        purchases.payPurchase(p.id, 600, "ESPECES")
        assertThrows(SaleException::class.java) { runBlocking { purchases.payPurchase(p.id, 1, "ESPECES") } }
    }
}
