package com.didi.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class FinanceCalculatorTest {

    @Test fun parseAcceptsCommaAndDot() {
        assertEquals(1250L, FinanceCalculator.parseToMinor("12,50"))
        assertEquals(1250L, FinanceCalculator.parseToMinor("12.5"))
        assertEquals(100000L, FinanceCalculator.parseToMinor("1 000"))
        assertNull(FinanceCalculator.parseToMinor("abc"))
        assertNull(FinanceCalculator.parseToMinor(""))
    }

    @Test fun formatMinor() {
        assertEquals("12.50", FinanceCalculator.formatMinor(1250))
        assertEquals("0.05", FinanceCalculator.formatMinor(5))
    }

    @Test fun lineTotalWithDiscount() {
        assertEquals(2500L, FinanceCalculator.lineTotal(1000, 3, 500))
        assertEquals(3000L, FinanceCalculator.lineTotal(1000, 3))
    }

    @Test fun lineTotalRejectsInvalid() {
        try { FinanceCalculator.lineTotal(1000, 1, 1001); fail() } catch (_: IllegalArgumentException) {}
        try { FinanceCalculator.lineTotal(1000, 0); fail() } catch (_: IllegalArgumentException) {}
    }

    @Test fun percentDiscountRounding() {
        assertEquals(1000L, FinanceCalculator.percentDiscount(10000, 10))
        assertEquals(33L, FinanceCalculator.percentDiscount(333, 10))   // 33,3 -> 33
        assertEquals(17L, FinanceCalculator.percentDiscount(335, 5))    // 16,75 -> 17
    }

    @Test fun profitIsNotRevenue() {
        val revenue = 100_000L
        val cogs = 70_000L
        val gross = FinanceCalculator.grossProfit(revenue, cogs)
        assertEquals(30_000L, gross)
        assertEquals(20_000L, FinanceCalculator.netProfit(gross, 10_000L))
    }

    @Test fun partialPaymentsAndDebt() {
        val total = 50_000L
        var paid = 20_000L
        assertEquals(30_000L, FinanceCalculator.balance(total, paid))
        assertTrue(FinanceCalculator.canApplyPayment(30_000L, 10_000L))
        assertFalse(FinanceCalculator.canApplyPayment(30_000L, 30_001L))
        paid += 30_000L
        assertEquals(0L, FinanceCalculator.balance(total, paid))
    }

    @Test fun currencyConversion() {
        val rate = 280_000L // 2 800,00 CDF pour 1 USD
        assertEquals(280_000L, FinanceCalculator.convert(100, Currency.USD, Currency.CDF, rate)) // 1,00 USD -> 2800,00 CDF
        assertEquals(100L, FinanceCalculator.convert(280_000L, Currency.CDF, Currency.USD, rate))
        assertEquals(500L, FinanceCalculator.convert(500, Currency.USD, Currency.USD, rate))
    }

    @Test fun stockValue() {
        assertEquals(30_000L, FinanceCalculator.stockValue(3, 10_000L))
    }

    @Test fun imeiLuhn() {
        assertTrue(FinanceCalculator.isValidImei("490154203237518"))
        assertFalse(FinanceCalculator.isValidImei("490154203237519"))
        assertFalse(FinanceCalculator.isValidImei("12345"))
    }
}
