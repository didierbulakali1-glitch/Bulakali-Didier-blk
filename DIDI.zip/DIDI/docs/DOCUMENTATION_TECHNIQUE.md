# Documentation technique

## Pile
Kotlin 2.0.21, Jetpack Compose (BOM 2024.10.01, Material 3), Room 2.6.1 (KSP), AGP 8.7.3, Gradle 8.9, minSdk 26, compileSdk/targetSdk 35. Aucune permission Android ; fichiers partagés par `FileProvider` (`${applicationId}.files`).

## Architecture
Une seule activité Compose. `DidiApp` fournit la base et les services. Couches : `data` (entités, DAO Room, Flow) → `domain` (services et calculs, sans Android sauf PDF/sauvegarde) → écrans Compose.

## Modèle de données (base `didi.db`, version 1)
categories, suppliers, products, phone_units, customers, sales, sale_items, payments, stock_movements, expense_categories, expenses, purchases, purchase_items, purchase_payments, sale_returns, sale_return_items, repairs, repair_events, users, app_settings.
Contraintes : clés étrangères (RESTRICT sur l'historique), index uniques sur `sales.clientToken`, `sales.number`, `purchases.clientToken`. Le schéma est exporté dans `app/schemas/`.

## Règles financières
- Montants en `Long` centièmes ; conversions et arrondis via `BigDecimal` HALF_UP (`FinanceCalculator`). Taux USD/CDF saisi à la main, stocké en centièmes (2800,00 → 280000).
- CA net = ventes − retours ; CMV = coût vendu − coût récupéré ; brut = CA net − CMV ; net = brut − dépenses ; trésorerie = paiements − remboursements (paiements négatifs).
- Dette ouverte = total − retourné − payé.
- Chaque vente garde la devise principale du moment et les noms d'articles copiés (l'historique ne change pas si on renomme).

## Intégrité
- Vente, retour, achat, paiement : une seule `withTransaction`.
- Anti-doublon : `clientToken` unique, généré à l'ouverture du panier.
- Stock : `decrementIfAvailable` atomique ; téléphone IMEI : `markSold` atomique EN_STOCK → VENDU.
- Paiements : `addToPaid` refuse tout dépassement du solde.

## Sécurité
PIN hachés PBKDF2WithHmacSHA256 (60 000 itérations, sel aléatoire). Droits par clé (CSV). Sans utilisateur : application ouverte, tous les droits. Verrouillage après 60 s en arrière-plan. Base **non chiffrée** sur l'appareil.

## Sauvegarde
Copie de `didi.db` après `wal_checkpoint(FULL)`. Restauration : contrôle d'en-tête SQLite, `integrity_check`, présence des tables clés, copie de sécurité, remplacement, redémarrage manuel.

## Exports
CSV séparateur `;` avec BOM (Excel). PDF via `PdfDocument`. Impression via `PrintManager`.

## Tests
`FinanceCalculatorTest` (calculs, Luhn) et `ServicesTest` (Robolectric, base en mémoire : stock, coût moyen, anti-doublon, rollback, crédit, IMEI, retours, annulation, paiement fournisseur). **Jamais exécutés à ce jour.** Non couverts : interface Compose, sauvegarde/restauration, PDF, PIN.

## Limites connues
Voir le README (frais de réparation hors CA, devise unique pour achats, sauvegarde non chiffrée sans photos, remise vendeur vérifiée à l'écran, pas de migration encore).
