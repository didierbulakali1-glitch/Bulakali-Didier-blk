# Guide d'installation

> Rappel : le projet n'a jamais été compilé. Suivez ce guide en gardant en tête que la première compilation peut signaler des erreurs.

## Option A — GitHub Actions (recommandée, rien à installer)

1. Créez un compte sur github.com, puis un nouveau dépôt (privé si vous voulez).
2. Envoyez tout le contenu du dossier DIDI, **y compris le dossier `.github`** (caché sous Linux/Mac : activez l'affichage des fichiers cachés avant de glisser-déposer).
3. Onglet **Actions** → **Compiler l'APK DIDI** → **Run workflow**.
4. Attendez 5 à 15 minutes. Si l'exécution est verte, téléchargez l'artefact **DIDI-debug-apk**, décompressez-le : vous obtenez `app-debug.apk`.
5. Sur le téléphone : copiez l'APK, ouvrez-le, autorisez « installer des applications inconnues » pour ce gestionnaire de fichiers, installez.

L'artefact **DIDI-rapport-tests** contient le résultat des tests (l'APK est produit même si un test échoue).

## Option B — Android Studio

1. Installez Android Studio (ordinateur ≥ 8 Go de RAM conseillé).
2. Ouvrez le dossier DIDI. Laissez Gradle se synchroniser (connexion Internet nécessaire la première fois).
3. Menu **Build → Build APK(s)**, ou branchez le téléphone (débogage USB) et appuyez sur **Run**.
4. L'APK est dans `app/build/outputs/apk/debug/`.

## Si la compilation échoue

Le journal GitHub Actions (clic sur l'étape rouge) ou la fenêtre « Build » d'Android Studio donne des lignes `e: ... .kt: (ligne, colonne): message`. Copiez ces lignes pour les faire corriger. Les causes probables : un import manquant, un type qui ne correspond pas, un nom de fonction qui diffère entre deux fichiers.

## Première ouverture

- L'application s'ouvre **sans code PIN** tant qu'aucun utilisateur n'existe. Allez dans **Réglages** (nom, devise, taux), puis **Utilisateurs** pour créer l'administrateur : la protection par PIN s'active alors.
- **Notez le PIN administrateur** : il n'existe aucun moyen de le récupérer sans effacer les données.

## Mise à jour et ancienne version

La base est en version 1 sans migration. Si une ancienne version de développement est installée, désinstallez-la avant (ses données seront perdues). Pour une vraie mise à jour future, faites d'abord une sauvegarde (voir `GUIDE_SAUVEGARDE.md`).

## Version de production

L'APK « debug » suffit pour votre usage. Pour publier sur le Play Store il faudrait un APK/AAB signé (`assembleRelease` + keystore) : non couvert ici.
