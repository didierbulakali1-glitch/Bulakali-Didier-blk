# Guide de modification

## Où est quoi (`app/src/main/java/com/didi/app/`)
| Je veux changer… | Fichier |
|---|---|
| Menu, navigation, thème, verrouillage | `MainActivity.kt` |
| Un écran | `<Nom>Screen.kt` (Dashboard, Pos, Products, Phones, Sales, Customers (+Dettes), Suppliers (+Achats), Expenses, Repairs, Reports, AdminScreens (catégories, utilisateurs, sauvegarde, fonctionnalités), Settings) |
| Composants communs | `Ui.kt`, `UiExtra.kt` |
| Tables et colonnes | `data/Entities.kt`, `data/DidiDatabase.kt` |
| Requêtes SQL | `data/Daos.kt` |
| Règles de vente / retours / achats | `domain/SaleService.kt`, `AfterSaleService.kt`, `PurchaseService.kt` |
| Calculs d'argent | `domain/FinanceCalculator.kt` |
| Définitions de bénéfice et périodes | `domain/Reports.kt` |
| Reçu PDF | `domain/ReceiptPdf.kt` |
| Droits et PIN | `domain/Security.kt` |
| Libellés des modes de paiement | `domain/Labels.kt` |

## Règles à respecter
- **Argent = `Long` en centièmes** (1000 = 10,00). Jamais de `Double`.
- Toute opération qui modifie plusieurs tables va dans `db.withTransaction { ... }`.
- Ne changez pas le sens d'un champ existant sans migration.

## Ajouter une colonne ou une table
1. Modifiez `Entities.kt` (et `@Database(entities=…)` si nouvelle table).
2. Passez `version = 1` à `2` dans `DidiDatabase.kt`.
3. Écrivez `val MIGRATION_1_2 = object : Migration(1, 2) { override fun migrate(db: SupportSQLiteDatabase) { db.execSQL("ALTER TABLE ... ADD COLUMN ...") } }` et ajoutez-la à `MIGRATIONS`.
4. **Sauvegardez** avant d'installer la nouvelle version. Les données restent.

## Ajouter un module optionnel
Ajoutez-le à `Dest`, au menu et à `OPTIONAL_FEATURES` (`MainActivity.kt`) et créez la clé de droit dans `Perm.ALL` (`Security.kt`).

## Changer le taux, les couleurs, le texte du reçu
Depuis **Réglages**, sans toucher au code. Couleurs d'accent : `MainActivity.kt`.

## Tests
`./gradlew :app:testDebugUnitTest`. Ajoutez un test dans `app/src/test/java/com/didi/app/` pour toute règle financière modifiée.
