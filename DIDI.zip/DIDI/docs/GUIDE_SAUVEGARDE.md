# Guide de sauvegarde et de restauration

## Principe
Une sauvegarde est une copie du fichier de base de données (`didi.db`). Elle contient produits, ventes, clients, dettes, utilisateurs (PIN hachés), réglages. Elle **n'est pas chiffrée** et **n'inclut pas les photos** (produits, justificatifs, logo).

## Sauvegarder
Menu **Sauvegarde → Créer une sauvegarde** → choisissez l'emplacement (mémoire, clé USB, Drive…). Le nom contient la date.
Habitudes recommandées : une sauvegarde **chaque soir** ; une copie **hors du téléphone** (ordinateur, clé USB) ; gardez les 7 dernières.
Le téléphone volé, cassé ou réinitialisé = données perdues si aucune sauvegarde n'existe ailleurs.

## Restaurer
Menu **Sauvegarde → Restaurer une sauvegarde** → choisissez le fichier. DIDI vérifie que c'est une base valide et intacte, puis demande confirmation. **Toutes les données actuelles sont remplacées.** Une copie de l'état avant restauration est gardée dans le stockage interne de l'application (`avant-restauration.db`). À la fin, **fermez DIDI complètement puis rouvrez-la**.

## Changer de téléphone
Sauvegarde sur l'ancien → copie du fichier → installez DIDI sur le nouveau → Restaurer. Recopiez les photos à la main si elles comptent (elles ne sont pas incluses).

## Sécurité
Le fichier contient toutes vos données commerciales : ne le partagez pas, ne le laissez pas sur un stockage public.
