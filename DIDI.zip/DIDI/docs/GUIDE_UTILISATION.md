# Guide d'utilisation

## Réglages de départ
Menu **Réglages** : nom de la boutique, téléphone, adresse, message du reçu, logo, devise principale (USD ou CDF), **taux de change** (combien de CDF pour 1 USD — à mettre à jour vous-même), remise maximale des vendeurs, thème et couleur.
Sans taux, vous ne pouvez pas encaisser dans l'autre devise.

## Préparer le catalogue
1. **Catégories** : modifiez, ajoutez, désactivez. Une catégorie « suivi par IMEI » rend ses produits traçables appareil par appareil.
2. **Produits** : créez le produit (nom, catégorie, prix de vente, stock minimum). Pour un téléphone, créez le **modèle** ; les appareils (IMEI) arrivent par un achat ou par « Téléphones → + ».
3. **Fournisseurs** puis **Achats** : réceptionnez la marchandise. Le stock augmente, le coût moyen est recalculé, les frais de transport sont répartis. Pour un téléphone, saisissez un IMEI (15 chiffres) par appareil.

## Vendre (Caisse)
Rechercher le produit → Ajouter (téléphone : choisir l'IMEI) → remise éventuelle → client (obligatoire à crédit) → mode de paiement, devise reçue, montant → **Valider la vente**. Un jeton interne empêche d'enregistrer deux fois la même vente si vous appuyez deux fois.
- Montant reçu < total : vente **à crédit** ; indiquez une échéance si besoin.
- Montant reçu > total : refusé (rendez la monnaie en saisissant le montant exact dû).
- Après la vente : **Reçu PDF / Partager** ; l'impression passe par la boîte d'impression d'Android (PDF ou imprimante détectée par le téléphone).

## Après la vente
- **Ventes** : détail, reçu, **retour** (par article, remise en stock ou « défectueux ») et **annulation** (réservés aux utilisateurs avec le droit « opérations sensibles »). Le retour diminue d'abord la dette du client, le reste est remboursé.
- **Dettes** : paiement partiel ou total par client (les plus anciennes dettes d'abord), relevé PDF, échéances en retard.
- **Réparations** : recevoir l'appareil, vérifier la garantie par IMEI, suivre les états. « Restitué » seulement après « Réparé » ou « Non réparable ».

## Comprendre les chiffres
- **Chiffre d'affaires net** = ventes − retours.
- **Coût des marchandises vendues** = coût des articles vendus − coût de ceux retournés en stock.
- **Bénéfice brut** = CA net − coût des marchandises. **Bénéfice net estimé** = bénéfice brut − dépenses.
- **Trésorerie** = paiements − remboursements : une vente à crédit compte dans le CA mais pas dans la trésorerie.
- Les achats de marchandises ne sont pas des dépenses (ils entrent dans le coût des marchandises vendues).

## Utilisateurs
Premier utilisateur = administrateur. Ensuite : Vendeur, Gestionnaire de stock ou droits personnalisés. L'application se verrouille après 60 s en arrière-plan. Le dernier administrateur actif ne peut pas être désactivé.

## Essai avant mise en service (indispensable)
Comme rien n'a été testé : faites 10 ventes réelles de petits montants, comparez avec vos calculs à la main (stock, total, dette, bénéfice), faites un retour et une annulation, créez une sauvegarde et restaurez-la sur un second téléphone. N'utilisez l'application seule qu'après ces vérifications.
